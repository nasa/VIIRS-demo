/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<<
   >>>>
   >>>> 	Main program for program to find the scans from a MODIS or NPP VIIRS data set that intersect 
   >>>>         a Landsat OLI or TM data set
   >>>>
   >>>>  Private:
   >>>> 	main(int argc, char **argv)
   >>>> 	usage()
   >>>> 	help()
   >>>>
   >>>>   Static:
   >>>>   Public:
   >>>>
   >>>>       Written: March 26, 2019 (based on simulate.cc)
   >>>> Modifications: April 5, 2019 - Upgraded to also work with MODIS data (no cloud mask with MODIS)
   >>>>
   >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<< */

#include "params/params.h"
#include "find_scans.h"
#include <iostream>

using namespace std;
using namespace NPP_VIIRS;

//Globals
Params params("Version 1.0, April 5, 2019");

// Forward function declarations
void usage();
void help();

int main(int argc, char *argv[])
{
  bool status = true;
  unsigned char return_value;

  GDALAllRegister();

  if (argc == 1)
  {
    usage();
    cout << "ERROR: Need parameter file as argument." << endl;
    status = false;
  }
  else if ((strncmp(argv[1],"-v",2) == 0) || (strncmp(argv[1],"-version",8) == 0))
  {
    params.print_version();
    cout << "For help information: find_scans -h or find_scans -help" << endl << endl;
    status = false;
  }
  else if ((strncmp(argv[1],"-h",2) == 0) || (strncmp(argv[1],"-help",5) == 0))
  {
    help();
    status = false;
  }
  else if (strncmp(argv[1],"-",1) == 0)
  {
    usage();
    cout << "The parameter file name cannot start with an \"-\"" << endl;
    status = false;
  }
  else
  {
    if (argc != 2)
    {
      usage();
      cout << "ERROR: Incorrect number of parameters on command line" << endl;
      status = false;
    }
    else
    {
      status = false;
      status = params.read(argv[1]);
      if (!status)
      {
        usage();
        cout << "ERROR: Error reading parameter file (read)" << endl;
        return EXIT_FAILURE;
      }
    }
  }

  if (status)
  {
    params.print();

    params.found_scans_fs.open(params.found_scans_file.c_str(),ios_base::out);

    int nbands = 1;
    GDALDataset *landsatOLIds;
    GDALRasterBand *rb;
    landsatOLIds = (GDALDataset *)GDALOpen(params.Landsat_OLI_mask_file.c_str(), GA_ReadOnly);
    if (!landsatOLIds)
    {
      cout << "ERROR: Could not open Landsat OLI mask file name = " << params.Landsat_OLI_mask_file << endl;
      return EXIT_FAILURE;
    }
    params.OLI_ncols = landsatOLIds->GetRasterXSize();
    params.OLI_nrows = landsatOLIds->GetRasterYSize();
    if (nbands != landsatOLIds->GetRasterCount())
      cout << "WARNING: Multiband Landsat OLI mask detected. Will use first band only." << endl;
    unsigned char      *OLI_mask;
    OLI_mask = new unsigned char[params.OLI_ncols*params.OLI_nrows];
    rb = landsatOLIds->GetRasterBand(1);
    if (rb->RasterIO(GF_Read, 0, 0, params.OLI_ncols, params.OLI_nrows, &OLI_mask[0], params.OLI_ncols, params.OLI_nrows, GDT_Byte, 0, 0)
        == CE_Failure)
    {
      cout << "ERROR: Could not read data from Landsat OLI image mask." << endl;
      return EXIT_FAILURE;
    }
    params.OLI_driver = landsatOLIds->GetDriver();
    string projection_type = landsatOLIds->GetProjectionRef();
    double imageGeoTransform[6];
    if ( landsatOLIds->GetGeoTransform( imageGeoTransform ) == CE_None )
    {
      params.OLI_X_offset = imageGeoTransform[0];
      params.OLI_Y_offset = imageGeoTransform[3];
      params.OLI_X_gsd = imageGeoTransform[1];
      params.OLI_Y_gsd = imageGeoTransform[5];
      if (params.OLI_X_gsd > 0.0)
      {
        params.min_OLI_X = params.OLI_X_offset;
        params.max_OLI_X = params.OLI_X_offset + params.OLI_X_gsd*params.OLI_ncols;
      }
      else
      {
        params.max_OLI_X = params.OLI_X_offset;
        params.min_OLI_X = params.OLI_X_offset + params.OLI_X_gsd*params.OLI_ncols;
      }
      if (params.OLI_Y_gsd > 0.0)
      {
        params.min_OLI_Y = params.OLI_Y_offset;
        params.max_OLI_Y = params.OLI_Y_offset + params.OLI_Y_gsd*params.OLI_nrows;
      }
      else
      {
        params.max_OLI_Y = params.OLI_Y_offset;
        params.min_OLI_Y = params.OLI_Y_offset + params.OLI_Y_gsd*params.OLI_nrows;
      }
      cout << "min OLI_UTM_X = " << params.min_OLI_X << " and max OLI_UTM_X = " << params.max_OLI_X << endl;
      cout << "min OLI_UTM_Y = " << params.min_OLI_Y << " and max OLI_UTM_Y = " << params.max_OLI_Y << endl;
    }
    else
    {
      cout << "ERROR: Could not obtain GeoTransform information from Landsat OLI image." << endl;
      return EXIT_FAILURE;
    }
    GDALClose( (GDALDatasetH) landsatOLIds);

    OGRSpatialReference landsatOLISpatialReference(projection_type.c_str());
    int north_flag;
    int UTM_zone = landsatOLISpatialReference.GetUTMZone(&north_flag);

    projPJ pj_utm, pj_latlong;
    string pj_utm_string, pj_latlong_string;
    if (north_flag)
      pj_utm_string = "+proj=utm +ellps=WGS84 +zone=" + stringify_int(UTM_zone);
    else
      pj_utm_string = "+proj=utm +ellps=WGS84 +south +zone=" + stringify_int(UTM_zone);
    pj_latlong_string = "+proj=latlong +ellps=WGS84";

    if (!(pj_utm = pj_init_plus(pj_utm_string.c_str())) )
      return EXIT_FAILURE;
    if (!(pj_latlong = pj_init_plus(pj_latlong_string.c_str())) )
      return EXIT_FAILURE;

    int input_ncols, input_nrows;
    GDALDataset *inputds, *latitudeds, *longitudeds;
#ifdef MODIS
    GDALDataset *scands, *trackds;
#else
    GDALDataset *cloud_maskds;
#endif
    GDALDataset *water_maskds;

  // Check input VIIRS or MODIS images
#ifdef MODIS
    inputds = (GDALDataset *)GDALOpen(params.MODIS_reflectance_image_file.c_str(), GA_ReadOnly);
#else
    inputds = (GDALDataset *)GDALOpen(params.VIIRS_radiance_image_file.c_str(), GA_ReadOnly);
#endif
    if (!inputds)
    {
#ifdef MODIS
      cout << "ERROR: Could not open MODIS reflectance file name = " << params.MODIS_reflectance_image_file << endl;
#else
      cout << "ERROR: Could not open VIIRS radiance file name = " << params.VIIRS_radiance_image_file << endl;
#endif
      return false;
    }
    input_ncols = inputds->GetRasterXSize();
    input_nrows = inputds->GetRasterYSize();
    if (nbands != inputds->GetRasterCount())
#ifdef MODIS
      cout << "WARNING: Multiband MODIS reflectance image detected. Will use first band only." << endl;
#else
      cout << "WARNING: Multiband VIIRS radiance image detected. Will use first band only." << endl;
#endif

    latitudeds = (GDALDataset *)GDALOpen(params.latitude_image_file.c_str(), GA_ReadOnly);
    if (!latitudeds)
    {
      cout << "ERROR: Could not open latitude file name = " << params.latitude_image_file << endl;
      return false;
    }
#ifdef MODIS
    if (SWATH_SIZE == 40)
    {
      if (((input_ncols/4) != latitudeds->GetRasterXSize()) || ((input_nrows/4) != latitudeds->GetRasterYSize()))
      {
        cout << "ERROR: Image size mismatch between MODIS reflectance and latitude image files." << endl;
        return false;
      }
    }
    else if (SWATH_SIZE == 20)
    {
      if (((input_ncols/2) != latitudeds->GetRasterXSize()) || ((input_nrows/2) != latitudeds->GetRasterYSize()))
      {
        cout << "ERROR: Image size mismatch between MODIS reflectance and latitude image files." << endl;
        return false;
      }
    }
    else
    {
      if ((input_ncols != latitudeds->GetRasterXSize()) || (input_nrows != latitudeds->GetRasterYSize()))
      {
        cout << "ERROR: Image size mismatch between MODIS reflectance and latitude image files." << endl;
        return false;
      }
    }
#else
    if ((input_ncols != latitudeds->GetRasterXSize()) || (input_nrows != latitudeds->GetRasterYSize()))
    {
      cout << "ERROR: Image size mismatch between VIIRS radiance and latitude image files." << endl;
      return false;
    }
#endif
    longitudeds = (GDALDataset *)GDALOpen(params.longitude_image_file.c_str(), GA_ReadOnly);
    if (!longitudeds)
    {
      cout << "ERROR: Could not open longitude file name = " << params.longitude_image_file << endl;
      return false;
    }
#ifdef MODIS
    if (SWATH_SIZE == 40)
    {
      if (((input_ncols/4) != longitudeds->GetRasterXSize()) || ((input_nrows/4) != longitudeds->GetRasterYSize()))
      {
        cout << "ERROR: Image size mismatch between MODIS reflectance and longitude image files." << endl;
        return false;
      }
    }
    else if (SWATH_SIZE == 20)
    {
      if (((input_ncols/2) != longitudeds->GetRasterXSize()) || ((input_nrows/2) != longitudeds->GetRasterYSize()))
      {
        cout << "ERROR: Image size mismatch between MODIS reflectance and longitude image files." << endl;
        return false;
      }
    }
    else
    {
      if ((input_ncols != longitudeds->GetRasterXSize()) || (input_nrows != longitudeds->GetRasterYSize()))
      {
        cout << "ERROR: Image size mismatch between MODIS reflectance and longitude image files." << endl;
        return false;
      }
    }
#else
    if ((input_ncols != longitudeds->GetRasterXSize()) || (input_nrows != longitudeds->GetRasterYSize()))
    {
      cout << "ERROR: Image size mismatch between VIIRS radiance and longitude image files." << endl;
      return false;
    }
#endif
#ifdef MODIS
    if (SWATH_SIZE == 10)
    {
      scands = NULL;
      trackds = NULL;
    }
    else
    {
      scands = (GDALDataset *)GDALOpen(params.scan_offset_image_file.c_str(), GA_ReadOnly);
      trackds = (GDALDataset *)GDALOpen(params.track_offset_image_file.c_str(), GA_ReadOnly);
      if (SWATH_SIZE == 40)
      {
        if (((input_ncols/2) != scands->GetRasterXSize()) || ((input_nrows/2) != scands->GetRasterYSize()))
        {
          cout << "ERROR: Image size mismatch between MODIS reflectance and scan offset image files." << endl;
          return false;
        }
        if (((input_ncols/2) != trackds->GetRasterXSize()) || ((input_nrows/2) != trackds->GetRasterYSize()))
        {
          cout << "ERROR: Image size mismatch between MODIS reflectance and track offset image files." << endl;
          return false;
        }
      }
      else if (SWATH_SIZE == 20)
      {
        if ((input_ncols != scands->GetRasterXSize()) || (input_nrows != scands->GetRasterYSize()))
        {
          cout << "ERROR: Image size mismatch between MODIS reflectance and scan offset image files." << endl;
          return false;
        }
        if ((input_ncols != trackds->GetRasterXSize()) || (input_nrows != trackds->GetRasterYSize()))
        {
          cout << "ERROR: Image size mismatch between MODIS reflectance and track offset image files." << endl;
          return false;
        }
      }
    }
#endif
    water_maskds = (GDALDataset *)GDALOpen(params.water_mask_file.c_str(), GA_ReadOnly);
    if (!water_maskds)
    {
      cout << "ERROR: Could not open water mask file name = " << params.water_mask_file << endl;
      return false;
    }
#ifdef MODIS
    if (SWATH_SIZE == 40)
    {
      if (((input_ncols/4) != water_maskds->GetRasterXSize()) || ((input_nrows/4) != water_maskds->GetRasterYSize()))
      {
        cout << "ERROR: Image size mismatch between MODIS reflectance and water mask image files." << endl;
        return false;
      }
    }
    else if (SWATH_SIZE == 20)
    {
      if (((input_ncols/2) != water_maskds->GetRasterXSize()) || ((input_nrows/2) != water_maskds->GetRasterYSize()))
      {
        cout << "ERROR: Image size mismatch between MODIS reflectance and water mask image files." << endl;
        return false;
      }
    }
    else
    {
      if ((input_ncols != water_maskds->GetRasterXSize()) || (input_nrows != water_maskds->GetRasterYSize()))
      {
        cout << "ERROR: Image size mismatch between MODIS reflectance and water mask image files." << endl;
        return false;
      }
    }
#else
    if ((input_ncols != water_maskds->GetRasterXSize()) || (input_nrows != water_maskds->GetRasterYSize()))
    {
      cout << "ERROR: Image size mismatch between radiance and water mask image files." << endl;
      return false;
    }
#endif
#ifndef MODIS
    if (params.cloud_mask_flag)
    {
      cloud_maskds = (GDALDataset *)GDALOpen(params.cloud_mask_file.c_str(), GA_ReadOnly);
      if (!cloud_maskds)
      {
        cout << "ERROR: Could not open cloud mask file name = " << params.cloud_mask_file << endl;
        return false;
      }
      if ((input_ncols != cloud_maskds->GetRasterXSize()) || (input_nrows != cloud_maskds->GetRasterYSize()))
      {
        cout << "ERROR: Image size mismatch between radiance and cloud mask image files." << endl;
        return false;
      }
    }
    else
      cloud_maskds = NULL;
#ifndef DNB
    int orig_nrows = params.nrows;
#endif
#endif

    int scan = params.starting_scan;
    bool continue_search_flag = true;
    bool found_scan_flag = false;
    bool overlap_flag;
    while (continue_search_flag)
    {
      params.row_offset = SWATH_SIZE*scan;
      if (params.row_offset >= input_nrows)
        break;
#ifndef MODIS
#ifndef DNB
      int orig_row_offset = params.row_offset;
#endif
#endif

#ifdef MODIS
      params.column_offset = 0;
      params.ncols = COLUMN_FACTOR*SWATH_SIZE;
#else
#ifdef DNB
      params.start_scan_flag = true;
#ifdef J1
      params.aggregation_zone = 27;
#else
      params.aggregation_zone = 32;
#endif
      params.find_column_offset();
#else
      params.column_offset = 0;
      params.find_aggregation_zone();
#endif
#endif
      overlap_flag = false;
      return_value = 0;
      while ((params.column_offset + params.ncols) < input_ncols)
      {
        bool continue_flag = true;
#ifndef MODIS
#ifndef DNB
        if (params.aggregation_zone_flag)
        {
      // Adjust for aggregation zone
          switch (params.aggregation_zone)
          {
#ifdef Mbands
            case 1:  params.nrows = orig_nrows - 4;
                     params.row_offset = orig_row_offset + 2;
                     break;
            case 2:  params.nrows = orig_nrows - 2;
                     params.row_offset = orig_row_offset + 1;
                     break;
#else
            case 1:  params.nrows = orig_nrows - 8;
                     params.row_offset = orig_row_offset + 4;
                     break;
            case 2:  params.nrows = orig_nrows - 4;
                     params.row_offset = orig_row_offset + 2;
                     break;
#endif
            case 3:  params.nrows = orig_nrows;
                     params.row_offset = orig_row_offset;
                     break;
            default: return false;
          }
#endif
#endif
          return_value = find_scans(inputds, latitudeds, longitudeds,
#ifdef MODIS
                                    scands, trackds,
                                    pj_latlong, pj_utm, water_maskds, OLI_mask);
#else
                                    pj_latlong, pj_utm, water_maskds, cloud_maskds, OLI_mask);
#endif
          if (return_value > 0)
          {
            overlap_flag = true;
            found_scan_flag = true;
          }
#ifndef MODIS
#ifndef DNB
        }
#endif
#endif
        if (return_value == 2)
          continue_flag = false;
        if ((overlap_flag) && (return_value == 0))
          continue_flag = false;

        if (continue_flag)
        {
#ifdef MODIS
          params.column_offset += 8;
#else
#ifdef DNB
          if (params.start_scan_flag)
            params.aggregation_zone -= 1;
          else
            params.aggregation_zone += 1;
          if (params.aggregation_zone == -1)
          {
            params.start_scan_flag = false;
            params.aggregation_zone = 0;
          }
#ifdef J1
          if (params.aggregation_zone < 32)
#else
          if (params.aggregation_zone < 33)
#endif
          {
            params.find_column_offset();
          }
          else
            params.column_offset = input_ncols;
#else
          params.column_offset += 8;
          params.find_aggregation_zone();
#endif
#endif
        }
        else
          params.column_offset = input_ncols;
      } //  while ((params.column_offset + params.ncols) <= input_ncols)

      if (return_value == 2)
        params.found_scans_fs << scan << endl;

      if ((!overlap_flag) && (found_scan_flag))
        continue_search_flag = false;
      scan++;
    } // while (continue_search_flag)

    GDALClose( (GDALDatasetH) inputds);
#ifdef MODIS
    if (SWATH_SIZE != 10)
    {
      GDALClose( (GDALDatasetH) scands);
      GDALClose( (GDALDatasetH) trackds);
    }
#endif
    GDALClose( (GDALDatasetH) latitudeds);
    GDALClose( (GDALDatasetH) longitudeds);
  } // if (status)

  params.found_scans_fs.close();

  if (status)
    return EXIT_SUCCESS;
  else
    return EXIT_FAILURE;
}

void usage() // Informs user of proper usage of program when mis-used.
{
    cout << endl << "Usage: " << endl << endl;
    cout << "find_scans parameter_file_name" << endl << endl;
    cout << "For help information: find_scans -h or find_scans -help" << endl;
    cout << "For version information: find_scans -v or find_scans -version" << endl;

    return ;
}

void help()
{
    cout << endl << "The find_scans progam is called as follows:" << endl;
    cout << endl << "find_scans parameter_file_name" << endl;
    cout << endl << "where \"parameter_file_name\" is the name of the input parameter" << endl;
    cout << "file. For contents see below." << endl;
    cout << endl << "For this help: find_scans -h or find_scans -help" << endl;
    cout << endl << "For version information: find_scans -v or find_scans -version" << endl;
    cout << endl << "The parameter file consists of entries of the form:" << endl << endl;
    cout << "-parameter_name parameter_value(s)" << endl;

    fprintf(stdout,"\nThe following parameters may be specified in the input parameter file:\n\n");
#ifdef MODIS
    fprintf(stdout,"-MODIS_reflectance_image (string)	Input MODIS reflectance image\n"
#else
    fprintf(stdout,"-VIIRS_radiance_image 	(string)	Input VIIRS radiance image\n"
#endif
"					(single band - required)\n"
"-latitude_image		(string)	Input latitude data image (required)\n"
"-longitude_image	(string)	Input longitude data image (required)\n"
#ifdef MODIS
"-water_mask		(string)	Input water mask image (required)\n");
#else
"-water_mask		(string)	Input water mask image (required)\n"
"-cloud_mask		(string)	Input cloud mask image (optional)\n");
#endif
#ifdef MODIS
    if (SWATH_SIZE != 10)
    {
      fprintf(stdout,"-scan_offset_image	(string)	Input Scan Offset image (required)\n"
"-track_offset_image	(string)	Input Track Offset image (required)\n"
"-starting_scan		(int)		Starting scan number for MODIS image\n"
"					(optional, default = 0)\n");
    }
    else
    {
      fprintf(stdout,"-starting_scan	(int)		Starting scan number for MODIS image\n"
"					(optional, default = 0)\n");
    }
#else // !MODIS
    fprintf(stdout,"-starting_scan		(int)		Starting scan number for VIIRS image\n"
"					(optional, default = 0)\n");
#endif // !MODIS
    fprintf(stdout,"-water_threshold	(float)		Water pixels threshold\n"
"					(optional, default = 0.2)\n"
#ifndef MODIS
"-cloud_threshold	(float)		Cloud pixels threshold\n"
"					(optional, default = 0.1)\n"
#endif
"-Landsat_OLI_mask	(string)	Input Landsat OLI image mask\n"
"					(required)\n"
"-found_scans		(string)	Output file for list of scans found\n"
"					to intersect the Landsat image\n"
"					(required)\n");
#ifdef MODIS
    if (SWATH_SIZE == 40)
    {
      cout << "NOTE: Compiled for MODIS 250m resolution reflectance subimages:" << endl;
    }
    else if (SWATH_SIZE == 20)
    {
      cout << "NOTE: Compiled for MODIS 500m resolution reflectance subimages:" << endl;
    }
    else
    {
      cout << "NOTE: Compiled for MODIS 1km resolution reflectance subimages:" << endl;
    }
#else
    if (SWATH_SIZE == 16)
    {
#ifdef DNB
#ifdef J1
      cout << "NOTE: Compiled for J1 VIIRS DNB radiance subimages:" << endl;
#else
      cout << "NOTE: Compiled for NPP VIIRS DNB radiance subimages:" << endl;
#endif
#else
      cout << "NOTE: Compiled for VIIRS M-band radiance subimages:" << endl;
#endif
    }
    else
    {
      cout << "NOTE: Compiled for VIIRS I-band radiance subimages:" << endl;
    }
#endif
    cout << "NOTE: If a multiband input image is provided, the first band will be used." << endl;

    return ;
}
