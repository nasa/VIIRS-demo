// find_scans.cc

#include "find_scans.h"
#include "params/params.h"
#include <iostream>
#include <cfloat>
#include <ogr_spatialref.h>

using namespace NPP_VIIRS;

// Externals
extern Params params;

namespace NPP_VIIRS
{
// Returns 0 for failure or subset not overlapping Landsat scene
// Returns 1 for subset that has too many water or cloud pixels
// Returns 2 for good subset
  unsigned char find_scans(GDALDataset *inputds, GDALDataset *latitudeds, GDALDataset *longitudeds,
#ifdef MODIS
                           GDALDataset *scands, GDALDataset *trackds,
                           const projPJ& pj_latlong, const projPJ& pj_utm, 
                           GDALDataset *water_maskds, unsigned char *OLI_mask)
#else
                           const projPJ& pj_latlong, const projPJ& pj_utm, 
                           GDALDataset *water_maskds, GDALDataset *cloud_maskds, unsigned char *OLI_mask)
#endif
  {
    GDALRasterBand *rb;

    int col, row, sub_col, sub_row, sub_index;
    float *input_image_subset;
    input_image_subset = new float[params.ncols*params.nrows];
    double UTM_X, UTM_Y;
    double *UTM_X_subset, *UTM_Y_subset, *input_latitude_subset, *input_longitude_subset;
    UTM_X_subset = new double[params.ncols*params.nrows];
    UTM_Y_subset = new double[params.ncols*params.nrows];
    input_latitude_subset = new double[params.ncols*params.nrows];
    input_longitude_subset = new double[params.ncols*params.nrows];
#ifdef MODIS
    int index;
    unsigned char *water_mask_subset;
    water_mask_subset = new unsigned char[params.ncols*params.nrows];
#else
    unsigned char *water_mask_subset, *cloud_mask_subset;
    water_mask_subset = new unsigned char[params.ncols*params.nrows];
    cloud_mask_subset = new unsigned char[params.ncols*params.nrows];
#endif

// Read in the input_image_subset
    rb = inputds->GetRasterBand(1);
    if (rb->RasterIO(GF_Read, params.column_offset, params.row_offset, params.ncols, params.nrows,
                     &input_image_subset[0], params.ncols, params.nrows, GDT_Float32, 0, 0)
        == CE_Failure)
    {
      cout << "ERROR: Could not read data from input_image_subset." << endl;
      return 0;
    }
#ifdef MODIS
    if (SWATH_SIZE == 10)
    {
// For this MODIS case, just read in the input_latitude_subset and input_longitude_subset
      rb = latitudeds->GetRasterBand(1);
      if (rb->RasterIO(GF_Read, params.column_offset, params.row_offset, params.ncols, params.nrows,
                       &input_latitude_subset[0], params.ncols, params.nrows, GDT_Float64, 0, 0)
          == CE_Failure)
      {
        cout << "ERROR: Could not read data from input_latitude_subset." << endl;
        return 0;
      }
      rb = longitudeds->GetRasterBand(1);
      if (rb->RasterIO(GF_Read, params.column_offset, params.row_offset, params.ncols, params.nrows,
                       &input_longitude_subset[0], params.ncols, params.nrows, GDT_Float64, 0, 0)
          == CE_Failure)
      {
        cout << "ERROR: Could not read data from input_longitude_subset." << endl;
        return 0;
      }
    }
    else
    {
  // For MODIS SWATH_SIZE > 10, need to construct the input_latitude_subset and input_longitude_subset
  // from the km_latitude_subset, km_longitude_subset, scan_offset and track_offset.
      int km_ncols, km_nrows, hkm_ncols, hkm_nrows;
      int km_col_offset, km_row_offset, hkm_col_offset, hkm_row_offset;
      if (SWATH_SIZE == 40)
      {
        km_ncols = (params.ncols/4) + 2;
        km_nrows = params.nrows/4;
        km_col_offset = params.column_offset/4;
        km_row_offset = params.row_offset/4;
        hkm_ncols = (params.ncols/2) + 1;
        hkm_nrows = params.nrows/2;
        hkm_col_offset = params.column_offset/2;
        hkm_row_offset = params.row_offset/2;
      }
      else if (SWATH_SIZE == 20)
      {
        km_ncols = (params.ncols/2) + 2;
        km_nrows = params.nrows/2;
        km_col_offset = params.column_offset/2;
        km_row_offset = params.row_offset/2;
        hkm_ncols = params.ncols + 1;
        hkm_nrows = params.nrows;
        hkm_col_offset = params.column_offset;
        hkm_row_offset = params.row_offset;
      }

      float *km_latitude_subset, *km_longitude_subset;
      double *hkm_latitude_subset, *hkm_longitude_subset;
      km_latitude_subset = new float[km_ncols*km_nrows];
      km_longitude_subset = new float[km_ncols*km_nrows];
      hkm_latitude_subset = new double[hkm_ncols*hkm_nrows];
      hkm_longitude_subset = new double[hkm_ncols*hkm_nrows];
      rb = latitudeds->GetRasterBand(1);
      if (rb->RasterIO(GF_Read, km_col_offset, km_row_offset, km_ncols, km_nrows,
                       &km_latitude_subset[0], km_ncols, km_nrows, GDT_Float32, 0, 0)
          == CE_Failure)
      {
        cout << "ERROR: Could not read data from input_latitude_subset." << endl;
        return 0;
      }

      rb = longitudeds->GetRasterBand(1);
      if (rb->RasterIO(GF_Read, km_col_offset, km_row_offset, km_ncols, km_nrows,
                       &km_longitude_subset[0], km_ncols, km_nrows, GDT_Float32, 0, 0)
          == CE_Failure)
      {
        cout << "ERROR: Could not read data from input_longitude_subset." << endl;
        return 0;
      }

      float *scan_offset, *track_offset;
      scan_offset = new float[hkm_ncols*hkm_nrows];
      track_offset = new float[hkm_ncols*hkm_nrows];
      rb = scands->GetRasterBand(1);
      if (rb->RasterIO(GF_Read, hkm_col_offset, hkm_row_offset, hkm_ncols, hkm_nrows,
                       &scan_offset[0], hkm_ncols, hkm_nrows, GDT_Float32, 0, 0)
          == CE_Failure)
      {
        cout << "ERROR: Could not read data from scan_offset subset." << endl;
        return 0;
      }
      rb = trackds->GetRasterBand(1);
      if (rb->RasterIO(GF_Read, hkm_col_offset, hkm_row_offset, hkm_ncols, hkm_nrows,
                       &track_offset[0], hkm_ncols, hkm_nrows, GDT_Float32, 0, 0)
          == CE_Failure)
      {
        cout << "ERROR: Could not read data from track_offset subset." << endl;
        return 0;
      }

      if (SWATH_SIZE == 40)
      {
        find_hkm_lat_long(km_latitude_subset,km_longitude_subset,scan_offset,track_offset,
                          km_ncols,km_nrows,hkm_ncols,hkm_nrows,
                          hkm_latitude_subset,hkm_longitude_subset);
        find_input_lat_long(hkm_latitude_subset,hkm_longitude_subset,
                            hkm_ncols,hkm_nrows,
                            input_latitude_subset,input_longitude_subset);
      }
      else
      {
        find_hkm_lat_long(km_latitude_subset,km_longitude_subset,scan_offset,track_offset,
                          km_ncols,km_nrows,hkm_ncols,hkm_nrows,
                          hkm_latitude_subset,hkm_longitude_subset);
        for (sub_row = 0; sub_row < params.nrows; sub_row++)
        {
          for (sub_col = 0; sub_col < params.ncols; sub_col++)
          {
            index = sub_col + sub_row*hkm_ncols;
            sub_index = sub_col + sub_row*params.ncols;
            input_latitude_subset[sub_index] = hkm_latitude_subset[index];
            input_longitude_subset[sub_index] = hkm_longitude_subset[index];
          }
        }
      }
    }
#else
// For VIIRS, just read in the input_latitude_subset and input_longitude_subset
    rb = latitudeds->GetRasterBand(1);
    if (rb->RasterIO(GF_Read, params.column_offset, params.row_offset, params.ncols, params.nrows,
                     &input_latitude_subset[0], params.ncols, params.nrows, GDT_Float64, 0, 0)
        == CE_Failure)
    {
      cout << "ERROR: Could not read data from input_latitude_subset." << endl;
      return 0;
    }

    rb = longitudeds->GetRasterBand(1);
    if (rb->RasterIO(GF_Read, params.column_offset, params.row_offset, params.ncols, params.nrows,
                     &input_longitude_subset[0], params.ncols, params.nrows, GDT_Float64, 0, 0)
        == CE_Failure)
    {
      cout << "ERROR: Could not read data from input_longitude_subset." << endl;
      return 0;
    }
#endif
// Populate the UTM_X_subset and UTM_Y_subset arrays
    for (sub_row = 0; sub_row < params.nrows; sub_row++)
      for (sub_col = 0; sub_col < params.ncols; sub_col++)
      {
        sub_index = sub_col + sub_row*params.ncols;
        lat_long_to_utm(pj_latlong,pj_utm,input_latitude_subset[sub_index],input_longitude_subset[sub_index],UTM_X,UTM_Y);
        UTM_X_subset[sub_index] = UTM_X;
        UTM_Y_subset[sub_index] = UTM_Y;
      }

    bool continue_flag = true;
    sub_row = 0; sub_col = 0;
    sub_index = sub_col + sub_row*params.ncols;
    if ((UTM_X_subset[sub_index] < params.min_OLI_X) || (UTM_X_subset[sub_index] > params.max_OLI_X))
      continue_flag = false;
    if ((UTM_Y_subset[sub_index] < params.min_OLI_Y) || (UTM_Y_subset[sub_index] > params.max_OLI_Y))
      continue_flag = false;
    sub_row = 0; sub_col = params.ncols-1;
    sub_index = sub_col + sub_row*params.ncols;
    if ((UTM_X_subset[sub_index] < params.min_OLI_X) || (UTM_X_subset[sub_index] > params.max_OLI_X))
      continue_flag = false;
    if ((UTM_Y_subset[sub_index] < params.min_OLI_Y) || (UTM_Y_subset[sub_index] > params.max_OLI_Y))
      continue_flag = false;
    sub_row = params.nrows-1; sub_col = 0;
    sub_index = sub_col + sub_row*params.ncols;
    if ((UTM_X_subset[sub_index] < params.min_OLI_X) || (UTM_X_subset[sub_index] > params.max_OLI_X))
      continue_flag = false;
    if ((UTM_Y_subset[sub_index] < params.min_OLI_Y) || (UTM_Y_subset[sub_index] > params.max_OLI_Y))
      continue_flag = false;
    sub_row = params.nrows-1; sub_col = params.ncols-1;
    sub_index = sub_col + sub_row*params.ncols;
    if ((UTM_X_subset[sub_index] < params.min_OLI_X) || (UTM_X_subset[sub_index] > params.max_OLI_X))
      continue_flag = false;
    if ((UTM_Y_subset[sub_index] < params.min_OLI_Y) || (UTM_Y_subset[sub_index] > params.max_OLI_Y))
      continue_flag = false;

    if (!continue_flag) 
      return 0;
/*
sub_row = 0; sub_col = 0;
sub_index = sub_col + sub_row*params.ncols;
cout << "UTM_X_subset(" << sub_col << "," << sub_row << ") = " << UTM_X_subset[sub_index] << endl;
cout << "UTM_Y_subset(" << sub_col << "," << sub_row << ") = " << UTM_Y_subset[sub_index] << endl;
sub_row = 0; sub_col = params.ncols-1;
sub_index = sub_col + sub_row*params.ncols;
cout << "UTM_X_subset(" << sub_col << "," << sub_row << ") = " << UTM_X_subset[sub_index] << endl;
cout << "UTM_Y_subset(" << sub_col << "," << sub_row << ") = " << UTM_Y_subset[sub_index] << endl;
sub_row = params.nrows-1; sub_col = 0;
sub_index = sub_col + sub_row*params.ncols;
cout << "UTM_X_subset(" << sub_col << "," << sub_row << ") = " << UTM_X_subset[sub_index] << endl;
cout << "UTM_Y_subset(" << sub_col << "," << sub_row << ") = " << UTM_Y_subset[sub_index] << endl;
sub_row = params.nrows-1; sub_col = params.ncols-1;
sub_index = sub_col + sub_row*params.ncols;
cout << "UTM_X_subset(" << sub_col << "," << sub_row << ") = " << UTM_X_subset[sub_index] << endl;
cout << "UTM_Y_subset(" << sub_col << "," << sub_row << ") = " << UTM_Y_subset[sub_index] << endl;
*/
  // Find scale_factor between input and OLI at middle of subset (must be odd numbers)
    double input_X_gsd, input_Y_gsd;
    sub_col = params.ncols/2;
    sub_row = params.nrows/2;
    sub_index = sub_col + sub_row*params.ncols;
    UTM_X = UTM_X_subset[sub_index];
    UTM_Y = UTM_Y_subset[sub_index];    
    sub_index = (sub_col+1) + sub_row*params.ncols;
    input_X_gsd = UTM_X_subset[sub_index];
    sub_index = sub_col + (sub_row+1)*params.ncols;
    input_Y_gsd = UTM_Y_subset[sub_index];
    input_X_gsd = input_X_gsd - UTM_X;
    input_Y_gsd = input_Y_gsd - UTM_Y;
    params.X_scale_factor = offset_for_rounding(abs(input_X_gsd/params.OLI_X_gsd));
    params.Y_scale_factor = offset_for_rounding(abs(input_Y_gsd/params.OLI_Y_gsd));
// If even, add 1
    if (params.X_scale_factor == 2*(params.X_scale_factor/2))
      params.X_scale_factor += 1;
    if (params.Y_scale_factor == 2*(params.Y_scale_factor/2))
      params.Y_scale_factor += 1;

// Create OLI image subset
    int row_offset, col_offset;
    col_offset = 0;
    row_offset = 0;
    int OLI_col, OLI_row, OLI_index;

    double X0, X[2];
    double Y0, Y[2];

  // First pixel
    sub_col = sub_row = 0;
    sub_index = sub_col + sub_row*params.ncols;
    X0 = UTM_X_subset[sub_index];
    Y0 = UTM_Y_subset[sub_index];
    sub_index = (sub_col+1) + sub_row*params.ncols;
    X[0] = (UTM_X_subset[sub_index] - X0)/params.X_scale_factor;
    Y[0] = (UTM_Y_subset[sub_index] - Y0)/params.Y_scale_factor;
    sub_index = sub_col + (sub_row+1)*params.ncols;
    X[1] = (UTM_X_subset[sub_index] - X0)/params.X_scale_factor;
    Y[1] = (UTM_Y_subset[sub_index] - Y0)/params.Y_scale_factor;
    sub_index = sub_col + sub_row*params.ncols;
    for (row = -(params.Y_scale_factor/2); row <= (params.Y_scale_factor/2); row++)
    {
      for (col = -(params.X_scale_factor/2); col <= (params.X_scale_factor/2); col++)
      {
//        X0 = UTM_X_subset[sub_index] + col*X[0] + row*Y[0];
//        Y0 = UTM_Y_subset[sub_index] + col*X[1] + row*Y[1];
        X0 = UTM_X_subset[sub_index] + (col+col_offset)*X[0] + (row+row_offset)*Y[0];
        Y0 = UTM_Y_subset[sub_index] + (col+col_offset)*X[1] + (row+row_offset)*Y[1];
        X0 = (X0 - params.OLI_X_offset)/params.OLI_X_gsd;
        Y0 = (Y0 - params.OLI_Y_offset)/params.OLI_Y_gsd;
        OLI_col = (int) offset_for_rounding(X0);
        OLI_row = (int) offset_for_rounding(Y0);
        if ((OLI_col < 0) || (OLI_row < 0) || (OLI_col >= params.OLI_ncols) || (OLI_row >= params.OLI_nrows))
          continue_flag = false;
        else
        {
          OLI_index = OLI_col + OLI_row*params.OLI_ncols;
          if (OLI_mask[OLI_index] == 0)
            continue_flag = false;
        }
      }
    }
    if (!continue_flag)
      return 0;

  // First row
    sub_row = 0;
    for (sub_col = 1; sub_col < params.ncols; sub_col++)
    {
      sub_index = sub_col + sub_row*params.ncols;
      X0 = UTM_X_subset[sub_index];
      Y0 = UTM_Y_subset[sub_index];
      sub_index = (sub_col-1) + sub_row*params.ncols;
      X[0] = (X0 - UTM_X_subset[sub_index])/params.X_scale_factor;
      Y[0] = (Y0 - UTM_Y_subset[sub_index])/params.Y_scale_factor;
      sub_index = sub_col + (sub_row+1)*params.ncols;
      X[1] = (UTM_X_subset[sub_index] - X0)/params.X_scale_factor;
      Y[1] = (UTM_Y_subset[sub_index] - Y0)/params.Y_scale_factor;
      sub_index = sub_col + sub_row*params.ncols;
      for (row = -(params.Y_scale_factor/2); row <= (params.Y_scale_factor/2); row++)
      {
        for (col = -(params.X_scale_factor/2); col <= (params.X_scale_factor/2); col++)
        {
//          X0 = UTM_X_subset[sub_index] + col*X[0] + row*Y[0];
//          Y0 = UTM_Y_subset[sub_index] + col*X[1] + row*Y[1];
          X0 = UTM_X_subset[sub_index] + (col+col_offset)*X[0] + (row+row_offset)*Y[0];
          Y0 = UTM_Y_subset[sub_index] + (col+col_offset)*X[1] + (row+row_offset)*Y[1];
          X0 = (X0 - params.OLI_X_offset)/params.OLI_X_gsd;
          Y0 = (Y0 - params.OLI_Y_offset)/params.OLI_Y_gsd;
          OLI_col = (int) offset_for_rounding(X0);
          OLI_row = (int) offset_for_rounding(Y0);
          if ((OLI_col < 0) || (OLI_row < 0) || (OLI_col >= params.OLI_ncols) || (OLI_row >= params.OLI_nrows))
            continue_flag = false;
          else
          {
            OLI_index = OLI_col + OLI_row*params.OLI_ncols;
            if (OLI_mask[OLI_index] == 0)
              continue_flag = false;
          }
        }
      }
    }
    if (!continue_flag)
      return 0;

  // First column
    sub_col = 0;
    for (sub_row = 1; sub_row < params.nrows; sub_row++)
    {
      sub_index = sub_col + sub_row*params.ncols;
      X0 = UTM_X_subset[sub_index];
      Y0 = UTM_Y_subset[sub_index];
      sub_index = (sub_col+1) + sub_row*params.ncols;
      X[0] = (UTM_X_subset[sub_index] - X0)/params.X_scale_factor;
      Y[0] = (UTM_Y_subset[sub_index] - Y0)/params.Y_scale_factor;
      sub_index = sub_col + (sub_row-1)*params.ncols;
      X[1] = (X0 - UTM_X_subset[sub_index])/params.X_scale_factor;
      Y[1] = (Y0 - UTM_Y_subset[sub_index])/params.Y_scale_factor;
      sub_index = sub_col + sub_row*params.ncols;
      for (row = -(params.Y_scale_factor/2); row <= (params.Y_scale_factor/2); row++)
      {
        for (col = -(params.X_scale_factor/2); col <= (params.X_scale_factor/2); col++)
        {
//          X0 = UTM_X_subset[sub_index] + col*X[0] + row*Y[0];
//          Y0 = UTM_Y_subset[sub_index] + col*X[1] + row*Y[1];
          X0 = UTM_X_subset[sub_index] + (col+col_offset)*X[0] + (row+row_offset)*Y[0];
          Y0 = UTM_Y_subset[sub_index] + (col+col_offset)*X[1] + (row+row_offset)*Y[1];
          X0 = (X0 - params.OLI_X_offset)/params.OLI_X_gsd;
          Y0 = (Y0 - params.OLI_Y_offset)/params.OLI_Y_gsd;
          OLI_col = (int) offset_for_rounding(X0);
          OLI_row = (int) offset_for_rounding(Y0);
          if ((OLI_col < 0) || (OLI_row < 0) || (OLI_col >= params.OLI_ncols) || (OLI_row >= params.OLI_nrows))
            continue_flag = false;
          else
          {
            OLI_index = OLI_col + OLI_row*params.OLI_ncols;
            if (OLI_mask[OLI_index] == 0)
              continue_flag = false;
          }
        }
      }
    }
    if (!continue_flag)
      return 0;

  // Rest of image
    for (sub_row = 1; sub_row < params.nrows; sub_row++)
    {
      for (sub_col = 1; sub_col < params.ncols; sub_col++)
      {
        sub_index = sub_col + sub_row*params.ncols;
        X0 = UTM_X_subset[sub_index];
        Y0 = UTM_Y_subset[sub_index];
        sub_index = (sub_col-1) + sub_row*params.ncols;
        X[0] = (X0 - UTM_X_subset[sub_index])/params.X_scale_factor;
        Y[0] = (Y0 - UTM_Y_subset[sub_index])/params.Y_scale_factor;
        sub_index = sub_col + (sub_row-1)*params.ncols;
        X[1] = (X0 - UTM_X_subset[sub_index])/params.X_scale_factor;
        Y[1] = (Y0 - UTM_Y_subset[sub_index])/params.Y_scale_factor;
        sub_index = sub_col + sub_row*params.ncols;
        for (row = -(params.Y_scale_factor/2); row <= (params.Y_scale_factor/2); row++)
        {
          for (col = -(params.X_scale_factor/2); col <= (params.X_scale_factor/2); col++)
          {
//            X0 = UTM_X_subset[sub_index] + col*X[0] + row*Y[0];
//            Y0 = UTM_Y_subset[sub_index] + col*X[1] + row*Y[1];
            X0 = UTM_X_subset[sub_index] + (col+col_offset)*X[0] + (row+row_offset)*Y[0];
            Y0 = UTM_Y_subset[sub_index] + (col+col_offset)*X[1] + (row+row_offset)*Y[1];
            X0 = (X0 - params.OLI_X_offset)/params.OLI_X_gsd;
            Y0 = (Y0 - params.OLI_Y_offset)/params.OLI_Y_gsd;
            OLI_col = (int) offset_for_rounding(X0);
            OLI_row = (int) offset_for_rounding(Y0);
            if ((OLI_col < 0) || (OLI_row < 0) || (OLI_col >= params.OLI_ncols) || (OLI_row >= params.OLI_nrows))
              continue_flag = false;
            else
            {
              OLI_index = OLI_col + OLI_row*params.OLI_ncols;
              if (OLI_mask[OLI_index] == 0)
                continue_flag = false;
            }
          }
        }
      }
    }

    if (!continue_flag)
      return 0;

// Read in the water_mask_subset
#ifdef MODIS
    rb = water_maskds->GetRasterBand(1);
    int ncols, nrows;
    unsigned char *water_mask;
    if (SWATH_SIZE == 40)
    {
     // Need to adjust resolution of water mask
      col_offset = params.column_offset/4;
      row_offset = params.row_offset/4;
      ncols = params.ncols/4;
      nrows = params.nrows/4;
      water_mask = new unsigned char[ncols*nrows];
      if (rb->RasterIO(GF_Read, col_offset, row_offset, ncols, nrows,
                       &water_mask[0], ncols, nrows, GDT_Byte, 0, 0)
          == CE_Failure)
      {
        cout << "ERROR: Could not read data from water_mask_subset." << endl;
        return 0;
      }
     // Use pixel replication to expand water mask to proper spatial resolution
      for (row = 0; row < nrows; row++)
        for (col = 0; col < ncols; col++)
        {
          index = col + row*ncols;
          for (sub_row = 0; sub_row < 4; sub_row++)
            for (sub_col = 0; sub_col < 4; sub_col++)
            {
              sub_index = (4*col + sub_col) + (4*row + sub_row)*params.ncols;
              water_mask_subset[sub_index] = water_mask[index];
            }
        }
    }
    else if (SWATH_SIZE == 20)
    {
     // Need to adjust resolution of water mask
      col_offset = params.column_offset/2;
      row_offset = params.row_offset/2;
      ncols = params.ncols/2;
      nrows = params.nrows/2;
      water_mask = new unsigned char[ncols*nrows];
      if (rb->RasterIO(GF_Read, col_offset, row_offset, ncols, nrows,
                       &water_mask[0], ncols, nrows, GDT_Byte, 0, 0)
          == CE_Failure)
      {
        cout << "ERROR: Could not read data from water_mask_subset." << endl;
        return 0;
      }
     // Use pixel replication to expand water mask to proper spatial resolution
      for (row = 0; row < nrows; row++)
        for (col = 0; col < ncols; col++)
        {
          index = col + row*ncols;
          for (sub_row = 0; sub_row < 2; sub_row++)
            for (sub_col = 0; sub_col < 2; sub_col++)
            {
              sub_index = (2*col + sub_col) + (2*row + sub_row)*params.ncols;
              water_mask_subset[sub_index] = water_mask[index];
            }
        }
    }
    else
    {
     // water mask is at correct resolution - just read it directly
      if (rb->RasterIO(GF_Read, params.column_offset, params.row_offset, params.ncols, params.nrows,
                       &water_mask_subset[0], params.ncols, params.nrows, GDT_Byte, 0, 0)
          == CE_Failure)
      {
        cout << "ERROR: Could not read data from water_mask_subset." << endl;
        return 0;
      }
    }
#else
    rb = water_maskds->GetRasterBand(1);
    if (rb->RasterIO(GF_Read, params.column_offset, params.row_offset, params.ncols, params.nrows,
                     &water_mask_subset[0], params.ncols, params.nrows, GDT_Byte, 0, 0)
        == CE_Failure)
    {
      cout << "ERROR: Could not read data from water_mask_subset." << endl;
      return 0;
    }
#endif
// Check water mask
    float npixels = 0.0;
    float nwaterpixels = 0.0;
    for (sub_row = 0; sub_row < params.nrows; sub_row++)
      for (sub_col = 0; sub_col < params.ncols; sub_col++)
      {
        sub_index = sub_col + sub_row*params.ncols;
        npixels += 1.0;
        if (!water_mask_subset[sub_index])
          nwaterpixels += 1.0;
      }
    if ((nwaterpixels/npixels) > params.water_threshold)
      return 1;

#ifndef MODIS
    if (params.cloud_mask_flag)
    {
  // Read in the cloud_mask_subset
      rb = cloud_maskds->GetRasterBand(1);
      if (rb->RasterIO(GF_Read, params.column_offset, params.row_offset, params.ncols, params.nrows,
                       &cloud_mask_subset[0], params.ncols, params.nrows, GDT_Byte, 0, 0)
          == CE_Failure)
      {
        cout << "ERROR: Could not read data from cloud_mask_subset." << endl;
        return 0;
      }
  // Check cloud mask
      float ncloudpixels = 0.0;
      for (sub_row = 0; sub_row < params.nrows; sub_row++)
        for (sub_col = 0; sub_col < params.ncols; sub_col++)
        {
          sub_index = sub_col + sub_row*params.ncols;
          if (!cloud_mask_subset[sub_index])
            ncloudpixels += 1.0;
        }
      if ((ncloudpixels/npixels) > params.cloud_threshold)
        return 1;
    }
#endif

    return 2;
  }

  void lat_long_to_utm(const projPJ& pj_latlong, const projPJ& pj_utm, 
                       const double& latitude, const double& longitude,
                       double& UTM_X, double& UTM_Y)
  {
    double x, y;

    x = longitude*DEG_TO_RAD;
    y = latitude*DEG_TO_RAD;
    pj_transform(pj_latlong, pj_utm, 1, 1, &x, &y, NULL );
    UTM_X = x;
    UTM_Y = y;

    return;
  }

  void utm_to_lat_long(const projPJ& pj_latlong, const projPJ& pj_utm, 
                       const double& UTM_X, const double& UTM_Y,
                       double& latitude, double& longitude)
  {
    double x, y;

    x = UTM_X;
    y = UTM_Y;
    pj_transform(pj_utm, pj_latlong, 1, 1, &x, &y, NULL );
    longitude = x/DEG_TO_RAD;
    latitude = y/DEG_TO_RAD;

    return;
  }

  void utm_x_y_to_col_row(const double& UTM_X, const double& UTM_Y, 
                          const double& X_offset, const double& Y_offset,
                          const double& X_gsd, const double& Y_gsd,
                          int& col, int& row)
  {
    double X,Y;

    X = (UTM_X - X_offset)/X_gsd;
    Y = (UTM_Y - Y_offset)/Y_gsd;
    col = (int) offset_for_rounding(X);
    row = (int) offset_for_rounding(Y);

    return;
  }

  void utm_col_row_to_x_y(const int& col, const int& row, 
                          const double& X_offset, const double& Y_offset,
                          const double& X_gsd, const double& Y_gsd,
                          double& UTM_X, double& UTM_Y)
  {
    UTM_X = X_offset + col*X_gsd;
    UTM_Y = Y_offset + row*Y_gsd;
    
    return;
  }

  double offset_for_rounding(const double& value)
  {
     if (value >= -0.5)
       return (value + 0.5);
     else
       return (value - 0.5);
  }

#ifdef MODIS
  void find_hkm_lat_long(float *km_latitude, float *km_longitude,
                         float *scan_offset, float *track_offset,
                         const int& km_ncols, const int& km_nrows,
                         const int& hkm_ncols, const int& hkm_nrows,
                         double *hkm_latitude, double *hkm_longitude)
  {
    int h_col, h_row, h_index;
    double *scan_delta, *track_delta;
    scan_delta = new double[hkm_ncols*hkm_nrows];
    track_delta = new double[hkm_ncols*hkm_nrows];

// Convert the unsigned char scan_offset and track_offset values to signed char and scale
// and initialize scan_delta and track_delta
    for (h_row = 0; h_row < hkm_nrows; h_row++)
    {
      for (h_col = 0; h_col < hkm_ncols; h_col++)
      {
        h_index = h_col + h_row*hkm_ncols;
        if (scan_offset[h_index] > 128.0)
          scan_offset[h_index] = scan_offset[h_index] - 256.0;
        if (track_offset[h_index] > 128.0)
          track_offset[h_index] = track_offset[h_index] - 256.0;
        if (scan_offset[h_index] == -127.0)
          scan_offset[h_index] = 0.0;
        if (track_offset[h_index] == -127.0)
          track_offset[h_index] = 0.0;
        scan_offset[h_index] *= 0.006;
        track_offset[h_index] *= 0.006;
        scan_delta[h_index] = 0.0;
        track_delta[h_index] = 0.0;
      }
    }

// Establish track_delta
  // First row
    h_row = 0;
    for (h_col = 0; h_col < hkm_ncols; h_col++)
    {
      h_index = h_col + h_row*hkm_ncols;
      track_delta[h_index] = -0.25 + track_offset[h_index];
    }
  // Interior rows
    for (h_row = 1; h_row < (hkm_nrows-1); h_row += 2)
    {
      for (h_col = 0; h_col < hkm_ncols; h_col++)
      {
        h_index = h_col + h_row*hkm_ncols;
        track_delta[h_index] = 0.25 + track_offset[h_index];
        h_index = h_col + (h_row+1)*hkm_ncols;
        track_delta[h_index] = 0.75 + track_offset[h_index];
      }
    }
  // Last row
    h_row = hkm_nrows - 1;
    for (h_col = 0; h_col < hkm_ncols; h_col++)
    {
      h_index = h_col + h_row*hkm_ncols;
      track_delta[h_index] = 1.25 + track_offset[h_index];
    }

// Establish scan_delta
  // All but last column
    for (h_col = 0; h_col < (hkm_ncols-1); h_col += 2)
    {
      for (h_row = 0; h_row < hkm_nrows; h_row++)
      {
        h_index = h_col + h_row*hkm_ncols;
        scan_delta[h_index] = 0.0 + scan_offset[h_index];
      }
      for (h_row = 0; h_row < hkm_nrows; h_row++)
      {
        h_index = (h_col+1) + h_row*hkm_ncols;
        scan_delta[h_index] = 0.5 + scan_offset[h_index];
      }
    }
  // Last column
    h_col = hkm_ncols - 1;
    for (h_row = 0; h_row < hkm_nrows; h_row++)
    {
      h_index = h_col + h_row*hkm_ncols;
      scan_delta[h_index] = 0.0 + scan_offset[h_index];
    }

// Compute hkm_latitude and hkm_longitude
    int col, row, index_a, index_b, index_c, index_d;
  // First hkm row (except last column)
    row = 0;
    h_row = 0;
    for (col = 0; col < (km_ncols-2); col++)
    {
      index_a = col + row*km_ncols;
      index_b = (col + 1) + row*km_ncols;
      index_c = col + (row + 1)*km_ncols;
      index_d = (col + 1) + (row + 1)*km_ncols;
      h_col = 2*col;
      h_index = h_col + h_row*hkm_ncols;
      hkm_latitude[h_index] = km_latitude[index_a]*(1.0-track_delta[h_index])*(1.0-scan_delta[h_index]) +
                              km_latitude[index_b]*(1.0-track_delta[h_index])*scan_delta[h_index] +
                              km_latitude[index_c]*track_delta[h_index]*(1.0-scan_delta[h_index]) +
                              km_latitude[index_d]*track_delta[h_index]*scan_delta[h_index];
      hkm_longitude[h_index] = km_longitude[index_a]*(1.0-track_delta[h_index])*(1.0-scan_delta[h_index]) +
                               km_longitude[index_b]*(1.0-track_delta[h_index])*scan_delta[h_index] +
                               km_longitude[index_c]*track_delta[h_index]*(1.0-scan_delta[h_index]) +
                               km_longitude[index_d]*track_delta[h_index]*scan_delta[h_index];
      h_index = (h_col+1) + h_row*hkm_ncols;
      hkm_latitude[h_index] = km_latitude[index_a]*(1.0-track_delta[h_index])*(1.0-scan_delta[h_index]) +
                              km_latitude[index_b]*(1.0-track_delta[h_index])*scan_delta[h_index] +
                              km_latitude[index_c]*track_delta[h_index]*(1.0-scan_delta[h_index]) +
                              km_latitude[index_d]*track_delta[h_index]*scan_delta[h_index];
      hkm_longitude[h_index] = km_longitude[index_a]*(1.0-track_delta[h_index])*(1.0-scan_delta[h_index]) +
                               km_longitude[index_b]*(1.0-track_delta[h_index])*scan_delta[h_index] +
                               km_longitude[index_c]*track_delta[h_index]*(1.0-scan_delta[h_index]) +
                               km_longitude[index_d]*track_delta[h_index]*scan_delta[h_index];
    }
  // Last column for first hkm row
    col = km_ncols - 2;
    index_a = col + row*km_ncols;
    index_b = (col + 1) + row*km_ncols;
    index_c = col + (row + 1)*km_ncols;
    index_d = (col + 1) + (row + 1)*km_ncols;
    h_col = 2*col;
    h_index = h_col + h_row*hkm_ncols;
    hkm_latitude[h_index] = km_latitude[index_a]*(1.0-track_delta[h_index])*(1.0-scan_delta[h_index]) +
                            km_latitude[index_b]*(1.0-track_delta[h_index])*scan_delta[h_index] +
                            km_latitude[index_c]*track_delta[h_index]*(1.0-scan_delta[h_index]) +
                            km_latitude[index_d]*track_delta[h_index]*scan_delta[h_index];
    hkm_longitude[h_index] = km_longitude[index_a]*(1.0-track_delta[h_index])*(1.0-scan_delta[h_index]) +
                             km_longitude[index_b]*(1.0-track_delta[h_index])*scan_delta[h_index] +
                             km_longitude[index_c]*track_delta[h_index]*(1.0-scan_delta[h_index]) +
                             km_longitude[index_d]*track_delta[h_index]*scan_delta[h_index];

  // Interior hkm rows (except last column)
    for (row = 0; row < (km_nrows-1); row++)
    {
      h_row = 2*row + 1;
      for (col = 0; col < (km_ncols-2); col++)
      {
        index_a = col + row*km_ncols;
        index_b = (col + 1) + row*km_ncols;
        index_c = col + (row + 1)*km_ncols;
        index_d = (col + 1) + (row + 1)*km_ncols;
        h_col = 2*col;
        h_index = h_col + h_row*hkm_ncols;
        hkm_latitude[h_index] = km_latitude[index_a]*(1.0-track_delta[h_index])*(1.0-scan_delta[h_index]) +
                                km_latitude[index_b]*(1.0-track_delta[h_index])*scan_delta[h_index] +
                                km_latitude[index_c]*track_delta[h_index]*(1.0-scan_delta[h_index]) +
                                km_latitude[index_d]*track_delta[h_index]*scan_delta[h_index];
        hkm_longitude[h_index] = km_longitude[index_a]*(1.0-track_delta[h_index])*(1.0-scan_delta[h_index]) +
                                 km_longitude[index_b]*(1.0-track_delta[h_index])*scan_delta[h_index] +
                                 km_longitude[index_c]*track_delta[h_index]*(1.0-scan_delta[h_index]) +
                                 km_longitude[index_d]*track_delta[h_index]*scan_delta[h_index];
        h_index = (h_col+1) + h_row*hkm_ncols;
        hkm_latitude[h_index] = km_latitude[index_a]*(1.0-track_delta[h_index])*(1.0-scan_delta[h_index]) +
                                km_latitude[index_b]*(1.0-track_delta[h_index])*scan_delta[h_index] +
                                km_latitude[index_c]*track_delta[h_index]*(1.0-scan_delta[h_index]) +
                                km_latitude[index_d]*track_delta[h_index]*scan_delta[h_index];
        hkm_longitude[h_index] = km_longitude[index_a]*(1.0-track_delta[h_index])*(1.0-scan_delta[h_index]) +
                                 km_longitude[index_b]*(1.0-track_delta[h_index])*scan_delta[h_index] +
                                 km_longitude[index_c]*track_delta[h_index]*(1.0-scan_delta[h_index]) +
                                 km_longitude[index_d]*track_delta[h_index]*scan_delta[h_index];
        h_index = h_col + (h_row+1)*hkm_ncols;
        hkm_latitude[h_index] = km_latitude[index_a]*(1.0-track_delta[h_index])*(1.0-scan_delta[h_index]) +
                                km_latitude[index_b]*(1.0-track_delta[h_index])*scan_delta[h_index] +
                                km_latitude[index_c]*track_delta[h_index]*(1.0-scan_delta[h_index]) +
                                km_latitude[index_d]*track_delta[h_index]*scan_delta[h_index];
        hkm_longitude[h_index] = km_longitude[index_a]*(1.0-track_delta[h_index])*(1.0-scan_delta[h_index]) +
                                 km_longitude[index_b]*(1.0-track_delta[h_index])*scan_delta[h_index] +
                                 km_longitude[index_c]*track_delta[h_index]*(1.0-scan_delta[h_index]) +
                                 km_longitude[index_d]*track_delta[h_index]*scan_delta[h_index];
        h_index = (h_col+1) + (h_row+1)*hkm_ncols;
        hkm_latitude[h_index] = km_latitude[index_a]*(1.0-track_delta[h_index])*(1.0-scan_delta[h_index]) +
                                km_latitude[index_b]*(1.0-track_delta[h_index])*scan_delta[h_index] +
                                km_latitude[index_c]*track_delta[h_index]*(1.0-scan_delta[h_index]) +
                                km_latitude[index_d]*track_delta[h_index]*scan_delta[h_index];
        hkm_longitude[h_index] = km_longitude[index_a]*(1.0-track_delta[h_index])*(1.0-scan_delta[h_index]) +
                                 km_longitude[index_b]*(1.0-track_delta[h_index])*scan_delta[h_index] +
                                 km_longitude[index_c]*track_delta[h_index]*(1.0-scan_delta[h_index]) +
                                 km_longitude[index_d]*track_delta[h_index]*scan_delta[h_index];
      }
  // Last column interior hkm rows
      col = km_ncols - 2;
      index_a = col + row*km_ncols;
      index_b = (col + 1) + row*km_ncols;
      index_c = col + (row + 1)*km_ncols;
      index_d = (col + 1) + (row + 1)*km_ncols;
      h_col = 2*col;
      h_index = h_col + h_row*hkm_ncols;
      hkm_latitude[h_index] = km_latitude[index_a]*(1.0-track_delta[h_index])*(1.0-scan_delta[h_index]) +
                              km_latitude[index_b]*(1.0-track_delta[h_index])*scan_delta[h_index] +
                              km_latitude[index_c]*track_delta[h_index]*(1.0-scan_delta[h_index]) +
                              km_latitude[index_d]*track_delta[h_index]*scan_delta[h_index];
      hkm_longitude[h_index] = km_longitude[index_a]*(1.0-track_delta[h_index])*(1.0-scan_delta[h_index]) +
                               km_longitude[index_b]*(1.0-track_delta[h_index])*scan_delta[h_index] +
                               km_longitude[index_c]*track_delta[h_index]*(1.0-scan_delta[h_index]) +
                               km_longitude[index_d]*track_delta[h_index]*scan_delta[h_index];
      h_index = h_col + (h_row+1)*hkm_ncols;
      hkm_latitude[h_index] = km_latitude[index_a]*(1.0-track_delta[h_index])*(1.0-scan_delta[h_index]) +
                              km_latitude[index_b]*(1.0-track_delta[h_index])*scan_delta[h_index] +
                              km_latitude[index_c]*track_delta[h_index]*(1.0-scan_delta[h_index]) +
                              km_latitude[index_d]*track_delta[h_index]*scan_delta[h_index];
      hkm_longitude[h_index] = km_longitude[index_a]*(1.0-track_delta[h_index])*(1.0-scan_delta[h_index]) +
                               km_longitude[index_b]*(1.0-track_delta[h_index])*scan_delta[h_index] +
                               km_longitude[index_c]*track_delta[h_index]*(1.0-scan_delta[h_index]) +
                               km_longitude[index_d]*track_delta[h_index]*scan_delta[h_index];
    }
  // Last hkm row (except last column)
    row = km_nrows - 2;
    h_row = hkm_nrows - 1;
    for (col = 0; col < (km_ncols-2); col++)
    {
      index_a = col + row*km_ncols;
      index_b = (col + 1) + row*km_ncols;
      index_c = col + (row + 1)*km_ncols;
      index_d = (col + 1) + (row + 1)*km_ncols;
      h_col = 2*col;
      h_index = h_col + h_row*hkm_ncols;
      hkm_latitude[h_index] = km_latitude[index_a]*(1.0-track_delta[h_index])*(1.0-scan_delta[h_index]) +
                              km_latitude[index_b]*(1.0-track_delta[h_index])*scan_delta[h_index] +
                              km_latitude[index_c]*track_delta[h_index]*(1.0-scan_delta[h_index]) +
                              km_latitude[index_d]*track_delta[h_index]*scan_delta[h_index];
      hkm_longitude[h_index] = km_longitude[index_a]*(1.0-track_delta[h_index])*(1.0-scan_delta[h_index]) +
                               km_longitude[index_b]*(1.0-track_delta[h_index])*scan_delta[h_index] +
                               km_longitude[index_c]*track_delta[h_index]*(1.0-scan_delta[h_index]) +
                               km_longitude[index_d]*track_delta[h_index]*scan_delta[h_index];
      h_index = (h_col+1) + h_row*hkm_ncols;
      hkm_latitude[h_index] = km_latitude[index_a]*(1.0-track_delta[h_index])*(1.0-scan_delta[h_index]) +
                              km_latitude[index_b]*(1.0-track_delta[h_index])*scan_delta[h_index] +
                              km_latitude[index_c]*track_delta[h_index]*(1.0-scan_delta[h_index]) +
                              km_latitude[index_d]*track_delta[h_index]*scan_delta[h_index];
      hkm_longitude[h_index] = km_longitude[index_a]*(1.0-track_delta[h_index])*(1.0-scan_delta[h_index]) +
                               km_longitude[index_b]*(1.0-track_delta[h_index])*scan_delta[h_index] +
                               km_longitude[index_c]*track_delta[h_index]*(1.0-scan_delta[h_index]) +
                               km_longitude[index_d]*track_delta[h_index]*scan_delta[h_index];
    }
  // Last column for last hkm row
    col = km_ncols - 2;
    index_a = col + row*km_ncols;
    index_b = (col + 1) + row*km_ncols;
    index_c = col + (row + 1)*km_ncols;
    index_d = (col + 1) + (row + 1)*km_ncols;
    h_col = 2*col;
    h_index = h_col + h_row*hkm_ncols;
    hkm_latitude[h_index] = km_latitude[index_a]*(1.0-track_delta[h_index])*(1.0-scan_delta[h_index]) +
                            km_latitude[index_b]*(1.0-track_delta[h_index])*scan_delta[h_index] +
                            km_latitude[index_c]*track_delta[h_index]*(1.0-scan_delta[h_index]) +
                            km_latitude[index_d]*track_delta[h_index]*scan_delta[h_index];
    hkm_longitude[h_index] = km_longitude[index_a]*(1.0-track_delta[h_index])*(1.0-scan_delta[h_index]) +
                             km_longitude[index_b]*(1.0-track_delta[h_index])*scan_delta[h_index] +
                             km_longitude[index_c]*track_delta[h_index]*(1.0-scan_delta[h_index]) +
                             km_longitude[index_d]*track_delta[h_index]*scan_delta[h_index];

    return;
  }

  void find_input_lat_long(double *hkm_latitude, double *hkm_longitude,
                           const int& hkm_ncols, const int& hkm_nrows,
                           double *input_latitude, double *input_longitude)
  {
    int q_col, q_row, q_index;
    double *scan_delta, *track_delta;
    scan_delta = new double[params.ncols*params.nrows];
    track_delta = new double[params.ncols*params.nrows];

    for (q_row = 0; q_row < params.nrows; q_row++)
    {
      for (q_col = 0; q_col < params.ncols; q_col++)
      {
        q_index = q_col + q_row*hkm_ncols;
        scan_delta[q_index] = 0.0;
        track_delta[q_index] = 0.0;
      }
    }

// Establish track_delta
  // First row
    q_row = 0;
    for (q_col = 0; q_col < params.ncols; q_col++)
    {
      q_index = q_col + q_row*params.ncols;
      track_delta[q_index] = -0.25;
    }
  // Interior rows
    for (q_row = 1; q_row < (params.nrows - 1); q_row += 2)
    {
      for (q_col = 0; q_col < params.ncols; q_col++)
      {
        q_index = q_col + q_row*params.ncols;
        track_delta[q_index] = 0.25;
        q_index = q_col + (q_row+1)*params.ncols;
        track_delta[q_index] = 0.75;
      }
    }
  // Last row
    q_row = params.nrows - 1;
    for (q_col = 0; q_col < params.ncols; q_col++)
    {
      q_index = q_col + q_row*params.ncols;
      track_delta[q_index] = 1.25;
    }

// Establish scan_delta
  // All columns
    for (q_col = 0; q_col < params.ncols; q_col += 2)
    {
      for (q_row = 0; q_row < params.nrows; q_row++)
      {
        q_index = q_col + q_row*params.ncols;
        scan_delta[q_index] = 0.0;
      }
      for (q_row = 0; q_row < params.nrows; q_row++)
      {
        q_index = (q_col+1) + q_row*params.ncols;
        scan_delta[q_index] = 0.5;
      }
    }

// Compute input_latitude and input_longitude
    int h_col, h_row, h_index_a, h_index_b, h_index_c, h_index_d;
  // First qkm row
    h_row = 0;
    q_row = 0;
    for (h_col = 0; h_col < (hkm_ncols-1); h_col++)
    {
      h_index_a = h_col + h_row*hkm_ncols;
      h_index_b = (h_col + 1) + h_row*hkm_ncols;
      h_index_c = h_col + (h_row + 1)*hkm_ncols;
      h_index_d = (h_col + 1) + (h_row + 1)*hkm_ncols;
      q_col = 2*h_col;
      q_index = q_col + q_row*params.ncols;
      input_latitude[q_index] = hkm_latitude[h_index_a]*(1.0-track_delta[q_index])*(1.0-scan_delta[q_index]) +
                                hkm_latitude[h_index_b]*(1.0-track_delta[q_index])*scan_delta[q_index] +
                                hkm_latitude[h_index_c]*track_delta[q_index]*(1.0-scan_delta[q_index]) +
                                hkm_latitude[h_index_d]*track_delta[q_index]*scan_delta[q_index];
      input_longitude[q_index] = hkm_longitude[h_index_a]*(1.0-track_delta[q_index])*(1.0-scan_delta[q_index]) +
                                 hkm_longitude[h_index_b]*(1.0-track_delta[q_index])*scan_delta[q_index] +
                                 hkm_longitude[h_index_c]*track_delta[q_index]*(1.0-scan_delta[q_index]) +
                                 hkm_longitude[h_index_d]*track_delta[q_index]*scan_delta[q_index];
      q_index = (q_col+1) + q_row*params.ncols;
      input_latitude[q_index] = hkm_latitude[h_index_a]*(1.0-track_delta[q_index])*(1.0-scan_delta[q_index]) +
                                hkm_latitude[h_index_b]*(1.0-track_delta[q_index])*scan_delta[q_index] +
                                hkm_latitude[h_index_c]*track_delta[q_index]*(1.0-scan_delta[q_index]) +
                                hkm_latitude[h_index_d]*track_delta[q_index]*scan_delta[q_index];
      input_longitude[q_index] = hkm_longitude[h_index_a]*(1.0-track_delta[q_index])*(1.0-scan_delta[q_index]) +
                                 hkm_longitude[h_index_b]*(1.0-track_delta[q_index])*scan_delta[q_index] +
                                 hkm_longitude[h_index_c]*track_delta[q_index]*(1.0-scan_delta[q_index]) +
                                 hkm_longitude[h_index_d]*track_delta[q_index]*scan_delta[q_index];
    }
  // Interior qkm rows
    for (h_row = 0; h_row < (hkm_nrows-1); h_row++)
    {
      q_row = 2*h_row + 1;
      for (h_col = 0; h_col < (hkm_ncols-1); h_col++)
      {
        h_index_a = h_col + h_row*hkm_ncols;
        h_index_b = (h_col + 1) + h_row*hkm_ncols;
        h_index_c = h_col + (h_row + 1)*hkm_ncols;
        h_index_d = (h_col + 1) + (h_row + 1)*hkm_ncols;
        q_col = 2*h_col;
        q_index = q_col + q_row*params.ncols;
        input_latitude[q_index] = hkm_latitude[h_index_a]*(1.0-track_delta[q_index])*(1.0-scan_delta[q_index]) +
                                  hkm_latitude[h_index_b]*(1.0-track_delta[q_index])*scan_delta[q_index] +
                                  hkm_latitude[h_index_c]*track_delta[q_index]*(1.0-scan_delta[q_index]) +
                                  hkm_latitude[h_index_d]*track_delta[q_index]*scan_delta[q_index];
        input_longitude[q_index] = hkm_longitude[h_index_a]*(1.0-track_delta[q_index])*(1.0-scan_delta[q_index]) +
                                   hkm_longitude[h_index_b]*(1.0-track_delta[q_index])*scan_delta[q_index] +
                                   hkm_longitude[h_index_c]*track_delta[q_index]*(1.0-scan_delta[q_index]) +
                                   hkm_longitude[h_index_d]*track_delta[q_index]*scan_delta[q_index];
        q_index = (q_col+1) + q_row*params.ncols;
        input_latitude[q_index] = hkm_latitude[h_index_a]*(1.0-track_delta[q_index])*(1.0-scan_delta[q_index]) +
                                  hkm_latitude[h_index_b]*(1.0-track_delta[q_index])*scan_delta[q_index] +
                                  hkm_latitude[h_index_c]*track_delta[q_index]*(1.0-scan_delta[q_index]) +
                                  hkm_latitude[h_index_d]*track_delta[q_index]*scan_delta[q_index];
        input_longitude[q_index] = hkm_longitude[h_index_a]*(1.0-track_delta[q_index])*(1.0-scan_delta[q_index]) +
                                   hkm_longitude[h_index_b]*(1.0-track_delta[q_index])*scan_delta[q_index] +
                                   hkm_longitude[h_index_c]*track_delta[q_index]*(1.0-scan_delta[q_index]) +
                                   hkm_longitude[h_index_d]*track_delta[q_index]*scan_delta[q_index];
        q_index = q_col + (q_row+1)*params.ncols;
        input_latitude[q_index] = hkm_latitude[h_index_a]*(1.0-track_delta[q_index])*(1.0-scan_delta[q_index]) +
                                  hkm_latitude[h_index_b]*(1.0-track_delta[q_index])*scan_delta[q_index] +
                                  hkm_latitude[h_index_c]*track_delta[q_index]*(1.0-scan_delta[q_index]) +
                                  hkm_latitude[h_index_d]*track_delta[q_index]*scan_delta[q_index];
        input_longitude[q_index] = hkm_longitude[h_index_a]*(1.0-track_delta[q_index])*(1.0-scan_delta[q_index]) +
                                   hkm_longitude[h_index_b]*(1.0-track_delta[q_index])*scan_delta[q_index] +
                                   hkm_longitude[h_index_c]*track_delta[q_index]*(1.0-scan_delta[q_index]) +
                                   hkm_longitude[h_index_d]*track_delta[q_index]*scan_delta[q_index];
        q_index = (q_col+1) + (q_row+1)*params.ncols;
        input_latitude[q_index] = hkm_latitude[h_index_a]*(1.0-track_delta[q_index])*(1.0-scan_delta[q_index]) +
                                  hkm_latitude[h_index_b]*(1.0-track_delta[q_index])*scan_delta[q_index] +
                                  hkm_latitude[h_index_c]*track_delta[q_index]*(1.0-scan_delta[q_index]) +
                                  hkm_latitude[h_index_d]*track_delta[q_index]*scan_delta[q_index];
        input_longitude[q_index] = hkm_longitude[h_index_a]*(1.0-track_delta[q_index])*(1.0-scan_delta[q_index]) +
                                   hkm_longitude[h_index_b]*(1.0-track_delta[q_index])*scan_delta[q_index] +
                                   hkm_longitude[h_index_c]*track_delta[q_index]*(1.0-scan_delta[q_index]) +
                                   hkm_longitude[h_index_d]*track_delta[q_index]*scan_delta[q_index];
      }
    }
  // Last qkm row
    h_row = hkm_nrows - 2;
    q_row = params.nrows - 1;
    for (h_col = 0; h_col < (hkm_ncols-1); h_col++)
    {
      h_index_a = h_col + h_row*hkm_ncols;
      h_index_b = (h_col + 1) + h_row*hkm_ncols;
      h_index_c = h_col + (h_row + 1)*hkm_ncols;
      h_index_d = (h_col + 1) + (h_row + 1)*hkm_ncols;
      q_col = 2*h_col;
      q_index = q_col + q_row*params.ncols;
      input_latitude[q_index] = hkm_latitude[h_index_a]*(1.0-track_delta[q_index])*(1.0-scan_delta[q_index]) +
                                hkm_latitude[h_index_b]*(1.0-track_delta[q_index])*scan_delta[q_index] +
                                hkm_latitude[h_index_c]*track_delta[q_index]*(1.0-scan_delta[q_index]) +
                                hkm_latitude[h_index_d]*track_delta[q_index]*scan_delta[q_index];
      input_longitude[q_index] = hkm_longitude[h_index_a]*(1.0-track_delta[q_index])*(1.0-scan_delta[q_index]) +
                                 hkm_longitude[h_index_b]*(1.0-track_delta[q_index])*scan_delta[q_index] +
                                 hkm_longitude[h_index_c]*track_delta[q_index]*(1.0-scan_delta[q_index]) +
                                 hkm_longitude[h_index_d]*track_delta[q_index]*scan_delta[q_index];
      q_index = (q_col+1) + q_row*params.ncols;
      input_latitude[q_index] = hkm_latitude[h_index_a]*(1.0-track_delta[q_index])*(1.0-scan_delta[q_index]) +
                                hkm_latitude[h_index_b]*(1.0-track_delta[q_index])*scan_delta[q_index] +
                                hkm_latitude[h_index_c]*track_delta[q_index]*(1.0-scan_delta[q_index]) +
                                hkm_latitude[h_index_d]*track_delta[q_index]*scan_delta[q_index];
      input_longitude[q_index] = hkm_longitude[h_index_a]*(1.0-track_delta[q_index])*(1.0-scan_delta[q_index]) +
                                 hkm_longitude[h_index_b]*(1.0-track_delta[q_index])*scan_delta[q_index] +
                                 hkm_longitude[h_index_c]*track_delta[q_index]*(1.0-scan_delta[q_index]) +
                                 hkm_longitude[h_index_d]*track_delta[q_index]*scan_delta[q_index];
    }

    return;
  }
#endif
} // NPP_VIIRS
