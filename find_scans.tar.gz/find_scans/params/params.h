#ifndef PARAMS_H
#define PARAMS_H

#include <defines.h>
#include <string>
#include <fstream>
#include <gdal_priv.h>

using namespace std;

namespace NPP_VIIRS
{

  class Params 
  {
    public:
    // Constructor and Destructor
      Params(const string& value);
      virtual ~Params();

    // Member functions
      void print_version();
      bool read(const char *param_file);
#ifndef MODIS
#ifdef DNB
      void find_column_offset();
#else
      void find_aggregation_zone();
#endif
#endif
      void print();

    // Member variables (public)
      string version;			     /* -- PROGRAM PARAMETER --*/

#ifdef MODIS
    /*-- Input single band MODIS reflectance image file (required) --*/
      string   MODIS_reflectance_image_file; /*-- INPUT IMAGE FILE NAME --*/
#else
    /*-- Input single band VIIRS radiance image file (required) --*/
      string   VIIRS_radiance_image_file;    /*-- INPUT IMAGE FILE NAME --*/
#endif

    /*-- Input latitude image data file (required) --*/
      string   latitude_image_file;	     /*-- INPUT IMAGE FILE NAME--*/

    /*-- Input longitude image data file (required) --*/
      string   longitude_image_file;	     /*-- INPUT IMAGE FILE NAME--*/

#ifdef MODIS
    /*-- Input scan offset image file (required) -- */
      string   scan_offset_image_file;       /*-- INPUT IMAGE FILE NAME--*/

    /*-- Input track offset image file (required) -- */
      string   track_offset_image_file;      /*-- INPUT IMAGE FILE NAME--*/
#endif
    /*-- Input water mask image data file (required) --*/
      string   water_mask_file;		     /*-- INPUT IMAGE FILE NAME--*/

#ifndef MODIS
    /*-- Input cloud_mask image data file (optional) --*/
      string   cloud_mask_file;		     /*-- INPUT IMAGE FILE NAME--*/
      bool     cloud_mask_flag;              /*-- EXISTANCE FLAG --*/
#endif

    /*-- Starting scan number for VIIRS or MODIS image search (optional) --*/
      int starting_scan;                     /*-- USER INPUT PARAMETER --*/
      bool starting_scan_flag;               /*-- EXISTANCE FLAG --*/
      int column_offset;                     /*-- PROGRAM PARAMETER --*/
      int row_offset;                        /*-- PROGRAM PARAMETER --*/

    /*-- Water pixel ratio threshold (optional, default provided) --*/
      float water_threshold;                 /*-- USER INPUT PARAMETER --*/

#ifndef MODIS
    /*-- Cloud pixel ratio threshold (optional, default provided) --*/
      float cloud_threshold;                 /*-- USER INPUT PARAMETER --*/
#endif

    /*-- Number of columns for VIIRS or MODIS image subset simulated (defaulted) --*/
      int ncols;                             /*-- DEFAULTED PROGRAM PARAMETER --*/

    /*-- Number of rows for VIIRS or MODIS image subset simulated (defaulted) --*/
      int nrows;                             /*-- DEFAULTED PROGRAM PARAMETER --*/

#ifndef MODIS
    /*-- VIIRS aggregation zone for selected image subset (optional for DNB, defaulted otherwise) --*/
      int aggregation_zone;                  /*-- USER INPUT PARAMETER (for DNB) or PROGRAM PARAMETER (otherwise) --*/
      bool aggregation_zone_flag;	     /*-- EXISTENCE FLAG --*/
      int best_aggregation_zone;             /*-- PROGRAM PARAMETER --*/
#ifdef DNB
    /*-- Start scan flag for VIIRS DNB image subset (optional) --*/
      bool start_scan_flag;                  /*-- USER INPUT PARAMETER --*/
      bool best_start_scan_flag;             /*-- PROGRAM PARAMETER --*/
#endif
#endif

    /*-- Scale factors --*/
      int      X_scale_factor;               /*-- PROGRAM PARAMETER --*/
      int      Y_scale_factor;               /*-- PROGRAM PARAMETER --*/

    /*-- Input single band Landsat OLI image mask file (required) --*/
      string   Landsat_OLI_mask_file;	     /*-- INPUT IMAGE MASK FILE NAME--*/

    /*-- Landsat OLI program parameters --*/
      int      OLI_ncols, OLI_nrows;         /*-- PROGRAM PARAMETERS --*/
      double   OLI_X_offset, OLI_Y_offset;   /*-- PROGRAM PARAMETERS --*/
      double   OLI_X_gsd, OLI_Y_gsd;         /*-- PROGRAM PARAMETERS --*/
      double   min_OLI_X, max_OLI_X;         /*-- PROGRAM PARAMETERS --*/
      double   min_OLI_Y, max_OLI_Y;         /*-- PROGRAM PARAMETERS --*/
      GDALDataType OLI_data_type;            /*-- PROGRAM PARAMETER --*/
      GDALDriver *OLI_driver;                /*-- PROGRAM PARAMETER --*/

    /*-- Output file for list of scans found to intersect the Landsat image (required) --*/
      string   found_scans_file;             /*-- USER INPUT PARAMETER --*/
      fstream  found_scans_fs;               /*-- ASSOCIATED FILE STREAM --*/

#ifndef MODIS
#ifdef DNB
      int DNB_Zones[33];  // Aggregation Zone 1 (index = 0) is split into two zones - giving an extra aggregation zone
#else
      int Agg_Zones[5];
#endif
#endif

    protected:

    private:
  };

  string process_line(const string& line, const bool& list_flag);

} // NPP_VIIRS

#endif /* PARAMS_H */
