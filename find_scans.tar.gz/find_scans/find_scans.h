#ifndef FIND_SCANS_H
#define FIND_SCANS_H

#include <defines.h>
#include <string>
#include <sstream>
#include <stdexcept>
#include <gdal_priv.h>
#include <proj_api.h>
#include <ogr_spatialref.h>


using namespace std;

namespace NPP_VIIRS
{

  unsigned char find_scans(GDALDataset *inputds, GDALDataset *latitudeds, GDALDataset *longitudeds,
#ifdef MODIS
                           GDALDataset *scands, GDALDataset *trackds,
                           const projPJ& pj_latlong, const projPJ& pj_utm, 
                           GDALDataset *water_maskds, unsigned char *OLI_mask);
#else
                           const projPJ& pj_latlong, const projPJ& pj_utm, 
                           GDALDataset *water_maskds, GDALDataset *cloud_maskds, unsigned char *OLI_mask);
#endif

  class BadConversion : public std::runtime_error
  {
    public:
      BadConversion(const std::string& s)
        : std::runtime_error(s)
        { }
  };

  inline std::string stringify_int(int x)
  {
    std::ostringstream o;
    if (!(o << x))
      throw BadConversion("stringify_int(int)");
    return o.str();
  }

  void lat_long_to_utm(const projPJ& pj_latlong, const projPJ& pj_utm, 
                       const double& latitude, const double& longitude,
                       double& UTM_X, double& UTM_Y);
  void utm_to_lat_long(const projPJ& pj_latlong, const projPJ& pj_utm, 
                       const double& UTM_X, const double& UTM_Y,
                       double& latitude, double& longitude);

  void utm_x_y_to_col_row(const double& UTM_X, const double& UTM_Y, 
                          const double& X_offset, const double& Y_offset,
                          const double& X_gsd, const double& Y_gsd,
                          int& col, int& row);
  void utm_col_row_to_x_y(const int& col, const int& row,
                          const double& X_offset, const double& Y_offset,
                          const double& X_gsd, const double& Y_gsd,
                          double& UTM_X, double& UTM_Y);

  double offset_for_rounding(const double& value);

#ifdef MODIS
  void find_hkm_lat_long(float *km_latitude, float *km_longitude,
                         float *scan_offset, float *track_offset,
                         const int& km_ncols, const int& km_nrows,
                         const int& hkm_ncols, const int& hkm_nrows,
                         double *hkm_latitude, double *hkm_longitude);

  void find_input_lat_long(double *hkm_latitude, double *hkm_longitude,
                           const int& hkm_ncols, const int& hkm_nrows,
                           double *input_latitude, double *input_longitude);
#endif

} // NPP_VIIRS

#endif // FIND_SCANS_H
