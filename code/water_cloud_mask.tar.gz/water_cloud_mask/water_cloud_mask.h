#ifndef WATER_CLOUD_MASK_H
#define WATER_CLOUD_MASK_H

#include <string>
#include <sstream>
#include <stdexcept>

#define COL_FACTOR   2   // Ratio of ncols to nrows in scan chip (integer >= 1).
#define NMI
//#undef NMI  // Leave NMI defined if Normalized Mutual Information is to be used
//#define NBINS 16 // Number quantization bins for Mutual Information step - 16 => 4-bits
//#define NBINS_SQRD 256 // NBINS squared
//#define NBINS 32 // Number quantization bins for Mutual Information step - 32 => 5-bits
//#define NBINS_SQRD 1024 // NBINS squared
#define NBINS 64 // Number quantization bins for Mutual Information step - 64 => 6-bits
#define NBINS_SQRD 4096 // NBINS squared
//#define NBINS 128 // Number quantization bins for Mutual Information step - 128 => 7-bits
//#define NBINS_SQRD 16384 // NBINS squared
//#define NBINS 256 // Number quantization bins for Mutual Information step - 256 => 8-bits
//#define NBINS_SQRD 65536 // NBINS squared
//#define NBINS 512 // Number quantization bins for Mutual Information step - 512 => 9-bits
//#define NBINS_SQRD 262144 // NBINS squared

using namespace std;

namespace NPP_VIIRS
{

  bool water_cloud_mask();

  string find_shortname(const string& input_filename);
  string find_filename(const string& input_filename, const string& subdataset_name);
  bool parse_line(string& line, unsigned int& scan, unsigned int& column, int& agg_zone, int& count); 

  class BadConversion : public std::runtime_error
  {
    public:
      BadConversion(const std::string& s)
        : std::runtime_error(s)
        { }
  };

  inline std::string stringify_int(int x)
  {
    std::ostringstream o;
    if (!(o << x))
      throw BadConversion("stringify_int(int)");
    return o.str();
  }

} // NPP_VIIRS

#endif // WATER_CLOUD_MASK_H

