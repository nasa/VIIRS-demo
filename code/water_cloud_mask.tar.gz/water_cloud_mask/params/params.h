/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<<
   >>>>
   >>>>       Purpose:  Provides the Params class, which is a class 
   >>>>                 holding program parameters.
   >>>>
   >>>>    Written By:  James C. Tilton, MC 606.3, NASA's GSFC, Greenbelt, MD 20771
   >>>>                 e-mail:  James.C.Tilton@nasa.gov
   >>>>          Date:  October 17, 2019
   >>>> Modifications:  
   >>>>
   >>>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<< */
#ifndef PARAMS_H
#define PARAMS_H

#include <defines.h>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

namespace NPP_VIIRS
{

  class Params 
  {
    public:
    // Constructor and Destructor
      Params(const string& value);
      virtual ~Params();

    // Member functions
      void print_version();
      bool read(const char *param_file);
      void print();

    // Member variables (public)
      string version;			 /* -- PROGRAM PARAMETER --*/

    /*-- Input VXX02IMG or VXX02MOD HDF5 (netCDF) file name for fixed image input (required) --*/
      string input_VXX02;          /*-- USER INPUT PARAMETER --*/

    /*-- Input VXX03IMG or VXX03MOD HDF5 (netCDF) file name for fixed land water mask input (required) --*/
      string input_VXX03;          /*-- USER INPUT PARAMETER --*/

    /*-- Fixed subdataset (required) --*/
      string subdataset;           /*-- USER INPUT PARAMETER --*/

    /*-- The detector mask (created from optional USER INPUT bad_detectors) --*/
      vector<unsigned short int> bad_detectors; /*-- USER INPUT PARAMETERS --*/

    /*-- Input CLDMSK_L2_VIIRS HDF5 (netCDF) file name for Cloud Mask (SNPP VIIRS) --*/
      string input_CLDMSK;               /*-- USER INPUT PARAMETER --*/
      bool   input_CLDMSK_flag;          /*-- EXISTENCE FLAG --*/

    /*-- Input VJ135_L2 HDF4 file name for Cloud Mask (J1 VIIRS) --*/
      string input_VJ135;                /*-- USER INPUT PARAMETER --*/
      bool   input_VJ135_flag;           /*-- EXISTENCE FLAG --*/

    /*-- Cloud threshold (optional, default provided) --*/
      float cloud_threshold;             /*-- USER INPUT PARAMETER --*/

    /*-- Water threshold (optional, default provided) --*/
      float water_threshold;             /*-- USER INPUT PARAMETER --*/

    /*-- Output log file (required) --*/
      string  log_file;                  /*-- USER INPUT FILENAME --*/
      fstream log_fs;                    /*-- ASSOCIATED FILE STREAM --*/

    /*-- Output no data mask file name (optional) --*/
      string output_no_data_mask;	 /*-- USER INPUT PARAMETER --*/
      bool   output_no_data_mask_flag;   /*-- EXISTENCE FLAG --*/

    /*-- Output cloud mask file name (optional) --*/
      string output_cloud_mask;		 /*-- USER INPUT PARAMETER --*/
      bool   output_cloud_mask_flag;     /*-- EXISTENCE FLAG --*/

    /*-- Output water mask file name (optional) --*/
      string output_water_mask;		 /*-- USER INPUT PARAMETER --*/
      bool   output_water_mask_flag;     /*-- EXISTENCE FLAG --*/

    /*-- Output image file name for image from subdataset (optional) --*/
      string output_image;		 /*-- USER INPUT PARAMETER --*/
      bool   output_image_flag;           /*-- EXISTENCE FLAG --*/
      bool   input_image_type;           /*-- Image type: TRUE -> I-band; FALSE -> M-band --*/

    /*-- Output image format (optional, default = GTiff) --*/
      string output_format;		 /*-- USER INPUT PARAMETER --*/

    protected:

    private:
  };

  string process_line(const string& line, const bool& list_flag);

} // NPP_VIIRS

#endif /* PARAMS_H */
