// params.cc

#include "params.h"
#include "../water_cloud_mask.h"
#include <iostream>
#include <cstdlib>

namespace NPP_VIIRS
{

 // Constructor
  Params::Params(const string& value)
  {
    version = value;

    input_CLDMSK_flag = false;
    input_VJ135_flag = false;
    cloud_threshold = 0.05;
    water_threshold = 0.75;
    output_no_data_mask_flag = false;
    output_cloud_mask_flag = false;
    output_water_mask_flag = false;
    output_image_flag = false;
    input_image_type = false;
    output_format = "GTiff";

    return;
  }

 // Destructor...
  Params::~Params() 
  {
    return;
  }

 // Print version
  void Params::print_version( )
  {

    cout << endl << version << endl << endl;

   return;
  }

 // Read parameters
  bool Params::read(const char *param_file)
  {
//    cout << endl << "Parameters to be read from file " << param_file << endl << endl;
    ifstream param_fs(param_file);
    if (!param_fs.is_open())
    {
      cout << "Cannot open input file " << param_file << endl;
      return false;
    }

  // Read initial parameters from parameter file until End-of-File reached
    bool input_VXX02_flag = false;
    bool input_VXX03_flag = false;
    bool subdataset_flag = false;
    bool log_flag = false;
    int sub_pos;
    string line, sub_string;
    while (!param_fs.eof())
    {
      getline(param_fs,line);
      sub_pos = line.find("-");
      while ((!param_fs.eof()) && (sub_pos != 0))
      {
        getline(param_fs,line);
        sub_pos = line.find("-");
      }
      if (line.find("-input_VXX02") != string::npos)
      {
        input_VXX02 = process_line(line,false);
        input_VXX02_flag = true;
      }
      if (line.find("-input_VXX03") != string::npos)
      {
        input_VXX03 = process_line(line,false);
        input_VXX03_flag = true;
      }
      if (line.find("-subdataset") != string::npos)
      {
        subdataset = process_line(line,false);
        subdataset_flag = true;
      }
      if (line.find("-bad_detectors") != string::npos)
      {
        line = process_line(line,true);
        while (line.size() > 0)
        {
          sub_pos = line.find_first_of(",");
          if (sub_pos != (int) string::npos)
          {
            sub_string = line.substr(0,sub_pos);
            line = line.substr(sub_pos+1);
          }
          else
          {
            sub_string = line;
            line = "";
          }
          bad_detectors.push_back(atoi(sub_string.c_str()));
        }
      }
      if (line.find("-input_CLDMSK_L2") != string::npos)
      {
        input_CLDMSK = process_line(line,false);
        input_CLDMSK_flag = true;
      }
      if (line.find("-input_VJ135_L2") != string::npos)
      {
        input_VJ135 = process_line(line,false);
        input_VJ135_flag = true;
      }
      if (line.find("-cloud_threshold") != string::npos)
      {
        sub_string = process_line(line,false);
        cloud_threshold = atof(sub_string.c_str());
      }
      if (line.find("-water_threshold") != string::npos)
      {
        sub_string = process_line(line,false);
        water_threshold = atof(sub_string.c_str());
      }
      if (line.find("-log") != string::npos)
      {
        log_file = process_line(line,false);
        log_flag = true;
      }
      if (line.find("-output_no_data_mask") != string::npos)
      {
        output_no_data_mask = process_line(line,false);
        output_no_data_mask_flag = true;
      }
      if (line.find("-output_cloud_mask") != string::npos)
      {
        output_cloud_mask = process_line(line,false);
        output_cloud_mask_flag = true;
      }
      if (line.find("-output_water_mask") != string::npos)
      {
        output_water_mask = process_line(line,false);
        output_water_mask_flag = true;
      }
      if (line.find("-output_image") != string::npos)
      {
        output_image = process_line(line,false);
        output_image_flag = true;
      }
      if (line.find("-output_format") != string::npos)
      {
        output_format = process_line(line,false);
      }
    }
    param_fs.close();

// Exit with false status if a required parameter is not set, or an improper parameter
// setting is detected.
    if (!input_VXX02_flag)
    {
      cout << "ERROR: -input_VXX02 (Input VXX02IMG or VXX02MOD HDF5 file name for image) is required" << endl;
      return false;
    }
    if (!input_VXX03_flag)
    {
      cout << "ERROR: -input_VXX03 (Input VXX03IMG or VXX03MOD HDF5 file name for image) is required" << endl;
      return false;
    }
    if (!subdataset_flag)
    {
      cout << "ERROR: -subdataset (SUBDATASET NAME for fixed image) is required" << endl;
      return false;
    }
    if ((!input_CLDMSK_flag) && (!input_VJ135_flag))
    {
      cout << "WARNING: -input_CLDMSK_L2 (Input CLDMSK_L2 SNPP VIIRS HDF5 (netcdf) file name) or" << endl;
      cout << "WARNING: -input_VJ135_L2 (Input VJ135_L2 J1 VIIRS HDF4 file name) is normally required" << endl;
      cout << "Program will continue to generate water mask" << endl;
    }
    if (!log_flag)
    {
      cout << "ERROR: -log (Output log file) is required" << endl;
      return false; 
    }

    return true;
  }

 // Print parameters
  void Params::print()
  {
  // Print version
      log_fs << "This is " << version << endl << endl;

  // Print parameters
      log_fs << "Input VXX02IMG or VXX02MOD HDF5 file name for input image = " << input_VXX02 << endl;
      log_fs << "Input VXX03IMG or VXX03MOD HDF5 file name for input image = " << input_VXX03 << endl;
      log_fs << "Subdataset name = " << subdataset << endl;
      if (bad_detectors.size() > 0)
      {
        log_fs << "Bad Detectors: ";
        for (unsigned int i = 0; i < bad_detectors.size(); i++)
          log_fs << bad_detectors[i] << ", ";
        log_fs << endl;
      }
      if (input_CLDMSK_flag)
        log_fs << "Input CLDMSK_L2 SNPP VIIRS HDF5 (netcdf) file name = " << input_CLDMSK << endl;
      if (input_VJ135_flag)
        log_fs << "Input VJ135_L2 J1 VIIRS HDF4 file name = " << input_VJ135 << endl;
      log_fs << "Maximum ratio of cloud pixels = " << cloud_threshold << endl;
      log_fs << "Maximum ratio of water pixels = " << water_threshold << endl;
      if (output_no_data_mask_flag)
        log_fs << "Output no data mask file name = " << output_no_data_mask << endl;
      if (output_cloud_mask_flag)
        log_fs << "Output cloud mask file name = " << output_cloud_mask << endl;
      if (output_water_mask_flag)
        log_fs << "Output water mask file name = " << output_water_mask << endl;
      if (output_image_flag)
        log_fs << "Output image file name for image from subdataset = " << output_image << endl;
      if ((output_no_data_mask_flag) || (output_cloud_mask_flag) || (output_water_mask_flag))
        log_fs << "Output image format = " << output_format << endl;

      return;
  }

  string process_line(const string& line, const bool& list_flag)
  {
    int sub_pos, sub_pos_space, sub_pos_tab;
    string sub_string;

    sub_pos_space = line.find_first_of(" ");
    sub_pos_tab = line.find_first_of("\t");
    sub_pos = sub_pos_space;
    if (sub_pos ==  (int) string::npos)
      sub_pos = sub_pos_tab;
    if (sub_pos ==  (int) string::npos)
      return " ";

    sub_string = line.substr(sub_pos);
    while ((sub_string.substr(0,1) == "\t") || (sub_string.substr(0,1) == " "))
      sub_string = line.substr(++sub_pos);
#ifndef WINDOWS
    if (list_flag)
      return sub_string;

    sub_pos = sub_string.find_first_of(" ");
    if (sub_pos !=  (int) string::npos)
      sub_string = sub_string.substr(0,sub_pos);
    sub_pos = sub_string.find_first_of("\t");
    if (sub_pos !=  (int) string::npos)
      sub_string = sub_string.substr(0,sub_pos);
    sub_pos = sub_string.find_first_of("\r");
    if (sub_pos !=  (int) string::npos)
      sub_string = sub_string.substr(0,sub_pos);
#endif
    return sub_string;
  }

} // namespace NPP_VIIRS
