/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<<
   >>>>
   >>>> 	Main program for an NPP VIIRS Water and Cloud Mask generation program.
   >>>>
   >>>>  Private:
   >>>> 	main(int argc, char **argv)
   >>>> 	usage()
   >>>> 	help()
   >>>>
   >>>>   Static:
   >>>>   Public:
   >>>>
   >>>>       Written: October 17, 2019 - Based on bbrv1.7 (stripping out proprietary code)
   >>>> Modifications: 
   >>>>
   >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<< */

#include "water_cloud_mask.h"
#include "params/params.h"
#include <gdal_priv.h>
#include <cpl_conv.h>
#include <iostream>

using namespace std;
using namespace NPP_VIIRS;

//Globals
Params params("Version 1.0, October 17, 2019");

// Forward function declarations
void usage();
void help();

int main(int argc, char *argv[])
{
  bool status = true;

  GDALAllRegister();

  if (argc == 1)
  {
    usage();
    cout << "ERROR: Need parameter file as argument." << endl;
    status = false;
  }
  else if ((strncmp(argv[1],"-v",2) == 0) || (strncmp(argv[1],"-version",8) == 0))
  {
    params.print_version();
    cout << "For help information: water_cloud_mask -h or water_cloud_mask -help" << endl << endl;
    exit(EXIT_SUCCESS);
  }
  else if ((strncmp(argv[1],"-h",2) == 0) || (strncmp(argv[1],"-help",5) == 0))
  {
    help();
    exit(EXIT_SUCCESS);
  }
  else if (strncmp(argv[1],"-",1) == 0)
  {
    usage();
    cout << "The parameter file name cannot start with an \"-\"" << endl;
    status = false;
  }
  else
  {
    if (argc != 2)
    {
      usage();
      cout << "ERROR: Incorrect number of parameters on command line" << endl;
      status = false;
    }
    else
    {
      status = params.read(argv[1]);
      if (!status)
      {
        usage();
        cout << "ERROR: Error reading parameter file (read)" << endl;
        exit(EXIT_FAILURE);
      }
    }
  }

  if (status)
  {
// Open log file
    params.log_fs.open(params.log_file.c_str(),ios_base::out);
    status = params.log_fs.is_open();
  }

  if (status)
  {
// Print program parameters
    params.print();

// Call water_cloud_mask function
    status = water_cloud_mask();
  }
  else
  {
    usage();
    cout << "ERROR: Error opening log file: " << params.log_file << endl;
    exit(EXIT_FAILURE);
  }

  if (params.log_fs.is_open())
    params.log_fs.close( );

  if (status)
  {
//    cout << endl << "Successful completion of water_cloud_mask program" << endl;
    exit(EXIT_SUCCESS);
  }
  else
  {
//    cout << endl << "The water_cloud_mask program terminated improperly." << endl;
    exit(EXIT_FAILURE);
  }
}

void usage() // Informs user of proper usage of program when mis-used.
{
    cout << endl << "Usage: " << endl << endl;
    cout << "water_cloud_mask parameter_file_name" << endl << endl;
    cout << "For help information: water_cloud_mask -h or water_cloud_mask -help" << endl;
    cout << "For version information: water_cloud_mask -v or water_cloud_mask -version" << endl;

    return ;
}

void help()
{
    cout << endl << "The water_cloud_mask progam is called as follows:" << endl;
    cout << endl << "water_cloud_mask parameter_file_name" << endl;
    cout << endl << "where \"parameter_file_name\" is the name of the input parameter" << endl;
    cout << "file. For contents see below." << endl;
    cout << endl << "For this help: water_cloud_mask -h or water_cloud_mask -help" << endl;
    cout << endl << "For version information: water_cloud_mask -v or water_cloud_mask -version" << endl;
    cout << endl << "The parameter file consists of entries of the form:" << endl << endl;
    cout << "-parameter_name parameter_value(s)" << endl;

  fprintf(stdout,"\nThe following parameters may be specified in the input parameter file:\n\n");
  fprintf(stdout,"Input parameters:\n"
"-input_VXX02		(string)	Input VNP02IMG, VNP02MOD or\n"
"					VNP02DNB (for SNPP) or\n"
"					VJ102IMG, VJ102MOD or VJ102DNB\n"
"					(for J1) file name from which\n"
"					the input subdataset is\n"
"					extracted (required)\n"
"-input_VXX03		(string)	Input VNP03IMG, VNP03MOD or\n"
"					VNP03DNB (for SNPP) or\n"
"					VJ103IMG, VJ103MOD or VJ103DNB\n"
"					(for J1) file name from which\n"
"					the land_water_mask is extracted\n"
"					(required)\n"
"-subdataset		(string)	Subdataset (required)\n" 
"-bad_detectors		(int)		Bad detectors (Row numbers)\n"
"					(a comma delimited list - optional\n"
"					 default: an empty list)\n\n"
"One of the following two forms of Cloud Masks are required:\n"
"-input_CLDMSK_L2	(string)	Input CLDMSK_L2_VIIRS HDF file name\n"
"					for cloud_mask\n"
"-input_VJ135_L2		(string)	Input VJ135_L2 HDF4 file name\n"
"					for cloud_mask\n"
"-cloud_threshold	(float)		Maximum ratio of cloud pixels in chip\n"
"					for chip to be used int water_cloud_mask correlation\n"
"					(optional, default = 0.05)\n"
"-water_threshold	(float)		Maximum ratio of water pixels in chip\n"
"					for chip to be used int water_cloud_mask correlation\n"
"					(optional, default = 0.75)\n"
"-log			(string)	Output log file (no default)\n\n");
  fprintf(stdout,"\nOutput parameters:\n"
"-output_no_data_mask	(string)	Output no data mask file name\n"
"					(optional, no default)\n"
"-output_cloud_mask	(string)	Output cloud mask file name\n"
"					(optional, no default)\n"
"-output_water_mask	(string)	Output water mask file name\n"
"					(optional, no default)\n"
"-output_image		(string)	Output image file name for\n"
"					image from subdataset\n"
"					(optional, no default)\n");

  fprintf(stdout,"\nThe following parameter may also be specified:\n"
"-output_format		(string)	Format for output image(s) (optional,\n"
"					 default = GTiff (for GeoTIFF), must\n"
"					 be a format recognized by GDAL)\n");

  fprintf(stdout,"\nWorks with SNPP VIIRS Archive Set 5110 and J1 VIIRS Archive Set 3194\n");

    return;
}
