// water_cloud_mask.cc

#include "water_cloud_mask.h"
#include "params/params.h"
#include <gdal_priv.h>
#include <cpl_conv.h>
#include <iostream>
#include <cfloat>
#include <algorithm>

// Externals
extern NPP_VIIRS::Params params;

namespace NPP_VIIRS
{
  bool water_cloud_mask()
  {
    string input_shortname, input_filename;
    string CLDMSK_filename, QF1_filename, QF2_filename, QF6_filename, LWM_filename;

    input_shortname = find_shortname(params.input_VXX02.c_str());
    params.input_image_type = ((strcmp(input_shortname.c_str(),"VNP02IMG") == 0)||
                               (strcmp(input_shortname.c_str(),"VJ102IMG") == 0));
    if (params.input_image_type)
    {
      params.log_fs << "Input image is of type I-band" << endl;
    }
    else
    {
      params.log_fs << "Input image is of type M-band" << endl;
    }
    input_filename = find_filename(params.input_VXX02.c_str(), params.subdataset.c_str());
    if (input_filename.size() == 0)
    {
      cout << "Could not find subdataset name = " << params.subdataset << endl;
      cout << "in input_VXX02 file = " << params.input_VXX02 << endl; 
      return false;
    }

    string subdataset_name = "//geolocation_data/land_water_mask";
    LWM_filename = find_filename(params.input_VXX03.c_str(), subdataset_name);
    if (params.input_CLDMSK_flag)
    {
      subdataset_name = "//geophysical_data/Cloud_Mask";
      CLDMSK_filename = find_filename(params.input_CLDMSK.c_str(), subdataset_name);
    }
    if (params.input_VJ135_flag)
    {
      string subdataset_name = "QF1_VIIRSCMIP";
      QF1_filename = find_filename(params.input_VJ135.c_str(), subdataset_name);
      subdataset_name = "QF2_VIIRSCMIP";
      QF2_filename = find_filename(params.input_VJ135.c_str(), subdataset_name);
      subdataset_name = "QF6_VIIRSCMIP";
      QF6_filename = find_filename(params.input_VJ135.c_str(), subdataset_name);
    }

    params.log_fs << "Input Image = " << input_filename << endl;
    if (params.input_CLDMSK_flag)
      params.log_fs << "Input Cloud Mask Image = " << CLDMSK_filename << endl;
    if (params.input_VJ135_flag)
    {
      params.log_fs << "QF1_VIIRSCMIP = " << QF1_filename << endl;
      params.log_fs << "QF2_VIIRSCMIP = " << QF2_filename << endl;
      params.log_fs << "QF6_VIIRSCMIP = " << QF6_filename << endl;
    }
    params.log_fs << "Land Water Mask Image = " << LWM_filename << endl;

    GDALDataset *input_Dataset = (GDALDataset *)GDALOpen(input_filename.c_str(), GA_ReadOnly);
    if (!input_Dataset)
    {
      cout << "Could not open SUBDATASET name = " << input_filename << endl;
      return false;
    }
    GDALDataset *CLDMSK_Dataset = NULL;
    if (params.input_CLDMSK_flag)
    {
      CLDMSK_Dataset = (GDALDataset *)GDALOpen(CLDMSK_filename.c_str(), GA_ReadOnly);
      if (!CLDMSK_Dataset)
      {
        cout << "Could not open SUBDATASET name = " << CLDMSK_filename << endl;
        GDALClose(input_Dataset);
        return false;
      }
    }
    GDALDataset *QF1_Dataset = NULL;
    GDALDataset *QF2_Dataset = NULL;
    GDALDataset *QF6_Dataset = NULL;
    if (params.input_VJ135_flag)
    {
      QF1_Dataset = (GDALDataset *)GDALOpen(QF1_filename.c_str(), GA_ReadOnly);
      if (!QF1_Dataset)
      {
        cout << "Could not open SUBDATASET name = " << QF1_filename << endl;
        GDALClose(input_Dataset);
        return false;
      }
      QF2_Dataset = (GDALDataset *)GDALOpen(QF2_filename.c_str(), GA_ReadOnly);
      if (!QF2_Dataset)
      {
        cout << "Could not open SUBDATASET name = " << QF2_filename << endl;
        GDALClose(QF1_Dataset);
        GDALClose(input_Dataset);
        return false;
      }
      QF6_Dataset = (GDALDataset *)GDALOpen(QF6_filename.c_str(), GA_ReadOnly);
      if (!QF6_Dataset)
      {
        cout << "Could not open SUBDATASET name = " << QF6_filename << endl;
        GDALClose(QF2_Dataset);
        GDALClose(QF1_Dataset);
        GDALClose(input_Dataset);
        return false;
      }
    }
    GDALDataset *LWM_Dataset = (GDALDataset *)GDALOpen(LWM_filename.c_str(), GA_ReadOnly);
    if (!LWM_Dataset)
    {
      cout << "Could not open SUBDATASET name = " << LWM_filename << endl;
      if (params.input_VJ135_flag)
      {
        GDALClose(QF6_Dataset);
        GDALClose(QF2_Dataset);
        GDALClose(QF1_Dataset);
      }
      GDALClose(input_Dataset);
      return false;
    }

  // Check input image size
    unsigned int input_ncols = input_Dataset->GetRasterXSize();
    unsigned int input_nrows = input_Dataset->GetRasterYSize();

  // Read input image into a data buffer
    float *input_data = new float[input_ncols*input_nrows];
    GDALRasterBand *input_rb = input_Dataset->GetRasterBand(1);
    if (CE_Failure == input_rb->RasterIO(GF_Read, 0, 0, input_ncols, input_nrows, input_data, input_ncols, input_nrows, GDT_Float32, 0, 0))
    {
      cout << endl << "ERROR reading data in input_data" << endl;
      return false;
    }

    unsigned int nb_scans, input_scan_nrows = 16;
    if (params.input_image_type)
      input_scan_nrows = 32;
    nb_scans = input_nrows/input_scan_nrows;
    params.log_fs << "There are " << nb_scans << " scans in these data sets with input_scan_nrows = " << input_scan_nrows;

// Establish bad_detector_mask
    unsigned int scan_row, index;
    vector<bool> bad_detector_mask;
    for (scan_row = 0; scan_row < input_scan_nrows; scan_row++)
      bad_detector_mask.push_back(false);
    for (index = 0; index < params.bad_detectors.size(); index++)
      bad_detector_mask[params.bad_detectors[index]-1] = true;

  // Create no data mask at input image resolution
  // Include masking out bad detectors - treat as no data
    unsigned int col, row;
    unsigned char no_data_value;
    unsigned char *no_data_mask = new unsigned char[input_ncols*input_nrows];
    scan_row = 0;
    for (row = 0; row < input_nrows; row++)
    {
      for (col = 0; col < input_ncols; col++)
      {
        index = col + row*input_ncols;
        no_data_value = 1;
        if ((input_data[index] > 65525) || (input_data[index] < -990.0) || bad_detector_mask[scan_row])
        {
          no_data_value = 0;
          input_data[index] = -999.0;
        }
        no_data_mask[index] = no_data_value;
      }
      scan_row++;
      if (scan_row >= input_scan_nrows)
        scan_row = 0;
    }

    if (params.output_image_flag)
    {
      GDALDriver *driver = GetGDALDriverManager()->GetDriverByName(params.output_format.c_str());
      char **papszOptions = NULL;
      GDALDataset *output_image_Dataset = driver->Create(params.output_image.c_str(), input_ncols, input_nrows, 1, GDT_Float32, papszOptions);
      char **metadata = input_Dataset->GetMetadata("");
      output_image_Dataset->SetMetadata(metadata,"");
      GDALRasterBand *input_rb = NULL;
      input_rb = output_image_Dataset->GetRasterBand(1);
      input_rb->SetNoDataValue(-999.0);
      if (CE_Failure == input_rb->RasterIO(GF_Write, 0, 0, input_ncols, input_nrows, input_data, input_ncols, input_nrows, GDT_Float32, 0, 0))
      {
        cout << endl << "ERROR writing output_image" << endl;
        return false;
      }
      GDALClose(output_image_Dataset);
    }

    if (params.output_no_data_mask_flag)
    {
      GDALDriver *driver = GetGDALDriverManager()->GetDriverByName(params.output_format.c_str());
      char **papszOptions = NULL;
      GDALDataset *no_data_Dataset = driver->Create(params.output_no_data_mask.c_str(), input_ncols, input_nrows, 1, GDT_Byte, papszOptions);
      char **metadata = input_Dataset->GetMetadata("");
      no_data_Dataset->SetMetadata(metadata,"");
      GDALRasterBand *no_data_rb = NULL;
      no_data_rb = no_data_Dataset->GetRasterBand(1);
      no_data_rb->SetNoDataValue(0.0);
      if (CE_Failure == no_data_rb->RasterIO(GF_Write, 0, 0, input_ncols, input_nrows, no_data_mask, input_ncols, input_nrows, GDT_Byte, 0, 0))
      {
        cout << endl << "ERROR writing data no_data_mask" << endl;
        return false;
      }
      GDALClose(no_data_Dataset);
    }

  // Create Water Mask - Water mask is at the spatial resolution of the input image
    unsigned int water_ncols = LWM_Dataset->GetRasterXSize();
    unsigned int water_nrows = LWM_Dataset->GetRasterYSize();
    if ((water_ncols != input_ncols) || (water_nrows != input_nrows))
    {
      cout << endl << "ERROR: The size of the input_VXX03 data set is different" << endl;
      cout << "than the size of the input_VXX02 data set." << endl;
      GDALClose(LWM_Dataset);
      if (params.input_CLDMSK_flag)
        GDALClose(CLDMSK_Dataset);
      if (params.input_VJ135_flag)
      {
        GDALClose(QF6_Dataset);
        GDALClose(QF2_Dataset);
        GDALClose(QF1_Dataset);
      }
      GDALClose(input_Dataset);
      return false;
    }

    unsigned char *LWM_data = new unsigned char[water_ncols*water_nrows];
    GDALRasterBand *LWM_rb = LWM_Dataset->GetRasterBand(1);
    if (CE_Failure == LWM_rb->RasterIO(GF_Read, 0, 0, water_ncols, water_nrows, LWM_data, water_ncols, water_nrows, GDT_Byte, 0, 0))
    {
      cout << endl << "ERROR reading LWM_data" << endl;
      return false;
    }

    unsigned char water_mask_value;
    unsigned char *water_mask = new unsigned char[water_ncols*water_nrows];
    unsigned int offset, water_index;
    for (row = 0; row < water_nrows; row++)
      for (col = 0; col < water_ncols; col++)
      {
        index = col + row*water_ncols;
        water_index = index;
        offset = 0;
        while (LWM_data[water_index] == 255)
        {
      // If the water mask tests is not available, need to find nearest row where it is available.
          offset++;
          water_index = index - offset*water_ncols;
          if (water_index < 0)
            water_index = index;
          if (LWM_data[water_index] == 255)
            water_index = index + offset*water_ncols;
          if (water_index >= water_ncols*water_nrows)
            water_index = index;
        }
        water_mask_value = 1;
        if ((LWM_data[water_index]==0) || (LWM_data[water_index]==3) || (LWM_data[water_index]==5) ||
            (LWM_data[water_index]==6) || (LWM_data[water_index]==7))
          water_mask_value = 0;
        if (LWM_data[water_index] == 255)
          water_mask_value = 0;
        water_mask[index] = water_mask_value;
      }

    if (params.output_water_mask_flag)
    {
      GDALDriver *driver = GetGDALDriverManager()->GetDriverByName(params.output_format.c_str());
      char **papszOptions = NULL;
      GDALDataset *water_Dataset = driver->Create(params.output_water_mask.c_str(), water_ncols, water_nrows, 1, GDT_Byte, papszOptions);
      char **metadata = LWM_Dataset->GetMetadata("");
      water_Dataset->SetMetadata(metadata,"");
      GDALRasterBand *water_rb = NULL;
      water_rb = water_Dataset->GetRasterBand(1);
      water_rb->SetNoDataValue(0.0);
      if (CE_Failure == water_rb->RasterIO(GF_Write, 0, 0, water_ncols, water_nrows, water_mask, water_ncols, water_nrows, GDT_Byte, 0, 0))
      {
        cout << endl << "ERROR writing water_mask" << endl;
        return false;
      }
      GDALClose(water_Dataset);
    }

    if ((!params.input_CLDMSK_flag) && (!params.input_VJ135_flag))
    {
      cout << endl << "Exiting program because input cloud mask was not provided" << endl; 
      return false;
    }

  // Create Cloud Mask - Cloud mask is always at M-band spatial resolution
    unsigned int cloud_ncols, cloud_nrows;
    if (params.input_CLDMSK_flag)
    {
      cloud_ncols = CLDMSK_Dataset->GetRasterXSize();
      cloud_nrows = CLDMSK_Dataset->GetRasterYSize();
    }
    else
    {
      cloud_ncols = QF1_Dataset->GetRasterXSize();
      cloud_nrows = QF1_Dataset->GetRasterYSize();
    }
    unsigned char *CLDMSK_data = NULL;
    GDALRasterBand *CLDMSK_rb;
    unsigned char *QF1_data = NULL;
    unsigned char *QF2_data = NULL;
    unsigned char *QF6_data = NULL;
    GDALRasterBand *QF1_rb, *QF2_rb, *QF6_rb;
    if (params.input_CLDMSK_flag)
    {
      CLDMSK_data = new unsigned char[cloud_ncols*cloud_nrows];
      CLDMSK_rb = CLDMSK_Dataset->GetRasterBand(1);
      if (CE_Failure == CLDMSK_rb->RasterIO(GF_Read, 0, 0, cloud_ncols, cloud_nrows, CLDMSK_data, cloud_ncols, cloud_nrows, GDT_Byte, 0, 0))
      {
        cout << endl << "ERROR reading CLDMSK_data" << endl;
        return false;
      }
    }
    else
    {
      QF1_data = new unsigned char[cloud_ncols*cloud_nrows];
      QF2_data = new unsigned char[cloud_ncols*cloud_nrows];
      QF6_data = new unsigned char[cloud_ncols*cloud_nrows];
      QF1_rb = QF1_Dataset->GetRasterBand(1);
      QF2_rb = QF2_Dataset->GetRasterBand(1);
      QF6_rb = QF6_Dataset->GetRasterBand(1);
      if (CE_Failure == QF1_rb->RasterIO(GF_Read, 0, 0, cloud_ncols, cloud_nrows, QF1_data, cloud_ncols, cloud_nrows, GDT_Byte, 0, 0))
      {
        cout << endl << "ERROR reading QF1_data" << endl;
        return false;
      }
      if (CE_Failure == QF2_rb->RasterIO(GF_Read, 0, 0, cloud_ncols, cloud_nrows, QF2_data, cloud_ncols, cloud_nrows, GDT_Byte, 0, 0))
      {
        cout << endl << "ERROR reading QF2_data" << endl;
        return false;
      }
      if (CE_Failure == QF6_rb->RasterIO(GF_Read, 0, 0, cloud_ncols, cloud_nrows, QF6_data, cloud_ncols, cloud_nrows, GDT_Byte, 0, 0))
      {
        cout << endl << "ERROR reading QF6_data" << endl;
        return false;
      }
    }

    int determined_index;
    int QF6_index;
    int cloud_npixels = cloud_nrows*cloud_ncols;
    unsigned char cloud_mask_value;
    unsigned char *cloud_mask = new unsigned char[input_ncols*input_nrows];
    unsigned char *determined_mask = new unsigned char[input_ncols*input_nrows];
    if (params.input_CLDMSK_flag)
    {
      for (row = 0; row < cloud_nrows; row++)
        for (col = 0; col < cloud_ncols; col++)
        {
          index = col + row*cloud_ncols;
          determined_mask[index] = (((CLDMSK_data[index]/2)*2) != CLDMSK_data[index]);
        }
      for (row = 0; row < cloud_nrows; row++)
        for (col = 0; col < cloud_ncols; col++)
        {
          index = col + row*cloud_ncols;
          determined_index = index;
          offset = 0;
          while (determined_mask[determined_index] == 0)
          {
        // If the cloud mask tests were not done, need to find nearest row where they were done.
            offset++;
            determined_index = index - offset*cloud_ncols;
            if (determined_index < 0)
              determined_index = index;
            if (determined_mask[determined_index] == 0)
              determined_index = index + offset*cloud_ncols;
            if (determined_index >= cloud_npixels)
              determined_index = index;
          }
          cloud_mask_value = 1;
       // Restrict to probable and confident cloudy for water, land, desert or coastal pixels that are not snow/ice during the day
          if ((CLDMSK_data[determined_index] == 57) || (CLDMSK_data[determined_index] == 59) || 
              (CLDMSK_data[determined_index] == 121) || (CLDMSK_data[determined_index] == 123) || 
              (CLDMSK_data[determined_index] == 185) || (CLDMSK_data[determined_index] == 187) || 
              (CLDMSK_data[determined_index] == 249) || (CLDMSK_data[determined_index] == 251))
            cloud_mask_value = 0;
          cloud_mask[index] = cloud_mask_value;
        }
    }
    else
    {
      for (row = 0; row < cloud_nrows; row++)
        for (col = 0; col < cloud_ncols; col++)
        {
          index = col + row*cloud_ncols;
          QF6_index = index;
          offset = 0;
          while (QF6_data[QF6_index] == 0)
          {
        // If the cloud mask tests were not done, need to find nearest row where they were done.
            offset++;
            QF6_index = index - offset*cloud_ncols;
            if (QF6_index < 0)
              QF6_index = index;
            if (QF6_data[QF6_index] == 0)
              QF6_index = index + offset*cloud_ncols;
            if (QF6_index >= cloud_npixels)
              QF6_index = index;
          }
          cloud_mask_value = 1;
       // Remove Sun Glint Flags
          if (QF1_data[QF6_index] > 191)
            QF1_data[QF6_index] -= 192;
          if (QF1_data[QF6_index] > 127)
            QF1_data[QF6_index] -= 128;
          if (QF1_data[QF6_index] > 63)
            QF1_data[QF6_index] -= 64;
       // Restrict to probable and confident cloudy for medium and high quality cloud mask
          if ((QF1_data[QF6_index] == 10) || (QF1_data[QF6_index] == 11) || 
              (QF1_data[QF6_index] == 14) || (QF1_data[QF6_index] == 15) || 
              (QF1_data[QF6_index] == 26) || (QF1_data[QF6_index] == 27) || 
              (QF1_data[QF6_index] == 30) || (QF1_data[QF6_index] == 31) || 
              (QF1_data[QF6_index] == 42) || (QF1_data[QF6_index] == 43) || 
              (QF1_data[QF6_index] == 46) || (QF1_data[QF6_index] == 47) || 
              (QF1_data[QF6_index] == 58) || (QF1_data[QF6_index] == 59) || 
              (QF1_data[QF6_index] == 62) || (QF1_data[QF6_index] == 63))
            cloud_mask_value = 0;
/* Gives too many false positives */
/*
          if ((QF2_data[QF6_index] > 7) && (QF2_data[QF6_index] < 32)) 
            cloud_mask_value = 0;
*/
          cloud_mask[index] = cloud_mask_value;
        }
    }

    if (params.input_image_type)
    {
     // Since the input image is at I-band resolution, need the cloud mask at I-band resolution
      unsigned char *temp_mask = new unsigned char[cloud_ncols*cloud_nrows];
      for (row = 0; row < cloud_nrows; row++)
        for (col = 0; col < cloud_ncols; col++)
        {
          index = col + row*cloud_ncols;
          temp_mask[index] = cloud_mask[index];
        }
      int cloud_index;
      for (row = 0; row < input_nrows; row++)
        for (col = 0; col < input_ncols; col++)
        {
          index = col + row*input_ncols;
          cloud_index = (col/2) + (row/2)*cloud_ncols;
          cloud_mask[index] = temp_mask[cloud_index];
        }
      cloud_ncols = input_ncols;
      cloud_nrows = input_nrows;
//      delete [] temp_mask;
    }

    if (params.output_cloud_mask_flag)
    {
      GDALDriver *driver = GetGDALDriverManager()->GetDriverByName(params.output_format.c_str());
      char **papszOptions = NULL;
      GDALDataset *cloud_Dataset = driver->Create(params.output_cloud_mask.c_str(), cloud_ncols, cloud_nrows, 1, GDT_Byte, papszOptions);
      char **metadata;
      if (params.input_CLDMSK_flag)
        metadata = CLDMSK_Dataset->GetMetadata("");
      else
        metadata = QF1_Dataset->GetMetadata("");
      cloud_Dataset->SetMetadata(metadata,"");
      GDALRasterBand *cloud_rb = NULL;
      cloud_rb = cloud_Dataset->GetRasterBand(1);
      cloud_rb->SetNoDataValue(0.0);
      if (CE_Failure == cloud_rb->RasterIO(GF_Write, 0, 0, cloud_ncols, cloud_nrows, cloud_mask, cloud_ncols, cloud_nrows, GDT_Byte, 0, 0))
      {
        cout << endl << "ERROR writing cloud_mask data" << endl;
        return false;
      }
      GDALClose(cloud_Dataset);
    }

    GDALClose(input_Dataset);
    if (params.input_CLDMSK_flag)
      GDALClose(CLDMSK_Dataset);
    else
    {
      GDALClose(QF6_Dataset);
      GDALClose(QF2_Dataset);
      GDALClose(QF1_Dataset);
    }
    GDALClose(LWM_Dataset);

/*
    delete [] CLDMSK_data;
    delete [] LWM_data;
*/
    params.log_fs << "water_cloud_mask program successfully completed." << endl;

    return true;
  }

  string find_shortname(const string& input_filename)
  {
    string shortname = "";

    GDALDataset *input_Dataset = (GDALDataset *)GDALOpen(input_filename.c_str(), GA_ReadOnly);
    if (!input_Dataset)
    {
      cout << "Could not open input file name = " << input_filename << endl;
      return shortname;
    }

    char **metadata = input_Dataset->GetMetadata();
    if (metadata) 
    {
      for (char **meta = metadata; *meta; meta++) 
      {
	const char *name = strstr(*meta, "ShortName=");
	if (name)
        { 
          const char *equal = strstr(*meta, "=");
          shortname = (equal + 1);
        }
      }
    }
    GDALClose(input_Dataset);

    return shortname;
  }

  string find_filename(const string& input_filename, const string& subdataset_name)
  {
    string filename = "";

    GDALDataset *input_Dataset = (GDALDataset *)GDALOpen(input_filename.c_str(), GA_ReadOnly);
    if (!input_Dataset)
    {
      cout << "Could not open input file name = " << input_filename << endl;
      return filename;
    }

    bool found_flag;
    char **metadata = input_Dataset->GetMetadata("SUBDATASETS");
    if (metadata) 
    {
      // need to skip SUBDATASET_?_DESC;
      // we only need SUBDATASET_?_NAME here
      for (char **meta = metadata; *meta; meta += 2) 
      {
        found_flag = false;
	const char *name = strstr(*meta, "=");
	if (!name)
        {
          cout << "Could not find SUBDATASET_#_NAME " << endl;
          return filename;
        }
	else
        { 
          const char *subdataset_filename = (name + 1);
          const char *match = strstr(subdataset_filename,subdataset_name.c_str());
          if (match)
            found_flag = true;
          if (found_flag)
          {
            filename = subdataset_filename;
          }
        }
        if (found_flag)
          break;
      }
    }
    GDALClose(input_Dataset);

    return filename;
  }

  bool parse_line(string& line, unsigned int& scan, unsigned int& column, int& agg_zone, int& count)
  {
    int sub_pos;
    string sub_string;

    sub_pos = line.find_first_of(",");
    if (sub_pos != (int) string::npos)
    {
      sub_string = line.substr(0,sub_pos);
      line = line.substr(sub_pos+1);
      scan = atoi(sub_string.c_str()); // Actually data_set - but data_set value not needed!
    }
    else
    {
      cout << "Error reading input log file" << endl;
      return false;
    }
    sub_pos = line.find_first_of(",");
    if (sub_pos != (int) string::npos)
    {
      sub_string = line.substr(0,sub_pos);
      line = line.substr(sub_pos+1);
      scan = atoi(sub_string.c_str());
    }
    else
    {
      cout << "Error reading input log file" << endl;
      return false;
    }
    sub_pos = line.find_first_of(",");
    if (sub_pos != (int) string::npos)
    {
      sub_string = line.substr(0,sub_pos);
      line = line.substr(sub_pos+1);
      column = atoi(sub_string.c_str());
    }
    else
    {
      cout << "Error reading input log file" << endl;
      return false;
    }
    sub_pos = line.find_first_of(",");
    if (sub_pos != (int) string::npos)
    {
      sub_string = line.substr(0,sub_pos);
      line = line.substr(sub_pos+1);
      agg_zone = atoi(sub_string.c_str());
    }
    else
    {
      cout << "Error reading input log file" << endl;
      return false;
    }
    count = atoi(line.c_str());

    return true;
  }

} // NPP_VIIRS
