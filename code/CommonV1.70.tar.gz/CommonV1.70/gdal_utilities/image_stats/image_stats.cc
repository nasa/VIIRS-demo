// image_stats.cc

#include "image_stats.h"
#include "params/params.h"
#include <gdal_priv.h>
#include <iostream>
#include <float.h>
#include <algorithm>

// Externals
extern CommonTilton::Params params;

namespace CommonTilton
{
  bool image_stats()
  {
    int col, row, band, index, has_fill = false;
    int ncols, nrows, nbands, mask_nbands = 0;
    double fill_value = 0.0;
    GDALDataset *inDataset, *maskDataset;
    GDALRasterBand *rb, *mrb;

  // Check input image
    inDataset = (GDALDataset *)GDALOpen(params.input_image_file.c_str(), GA_ReadOnly);
    if (!inDataset)
    {
      cout << "Could not open input_image file name = " << params.input_image_file << endl;
      return false;
    }
    ncols = inDataset->GetRasterXSize();
    nrows = inDataset->GetRasterYSize();
    nbands = inDataset->GetRasterCount();
    cout << "Performing Statistical Analysis on input image " << params.input_image_file << endl;
    cout << "with ncols = " << ncols << ", nrows = " << nrows << " and nbands = " << nbands << endl;

  // Handle masking
    unsigned char *mask = new unsigned char[ncols*nrows];
    int mask_has_fill = false;
    unsigned char mask_fill_value = params.mask_value;
    if (params.mask_flag)
    {
      maskDataset = (GDALDataset *)GDALOpen(params.mask_file.c_str(), GA_ReadOnly);
      if (!maskDataset)
      {
        cout << "ERROR: Could not open mask file name = " << params.mask_file << endl;
        return false;
      }
      if ((maskDataset->GetRasterXSize() != ncols) ||
          (maskDataset->GetRasterYSize() != nrows))
      {
        cout << "ERROR: mask image " << params.mask_file << " does not match input_image in size." << endl;
        return false;
      }
      mask_nbands = maskDataset->GetRasterCount();
      if ((mask_nbands > 1) && (mask_nbands != nbands))
      {
        cout << "ERROR: multispectral mask image " << params.mask_file << " does not match input_image number of bands." << endl;
        return false;
      }
      mrb = maskDataset->GetRasterBand(1);
      mask_has_fill = false;
      mask_fill_value = mrb->GetNoDataValue(&mask_has_fill);
      if (!mask_has_fill)
        mask_fill_value = params.mask_value;
    }
    else
    {
      maskDataset = NULL;
      rb = inDataset->GetRasterBand(1);
      has_fill = false;
      fill_value = rb->GetNoDataValue(&has_fill);
      if (has_fill)
        mask_nbands = nbands;
      else
        mask_nbands = 0;
    }
    bool one_mask_band = ((params.mask_flag) && (mask_nbands == 1));
    if (one_mask_band)
    {
      mrb = maskDataset->GetRasterBand(1);
      if (mrb->RasterIO(GF_Read, 0, 0, ncols, nrows, &mask[0], ncols, nrows, GDT_Byte, 0, 0)
          == CE_Failure)
      {
        cout << "ERROR: Could not read mask data" << endl;
        return false;
      }
    }
    else
    {
      for (row = 0; row < nrows; row++)
        for (col = 0; col < ncols; col++)
        {
          index = col + row*ncols;
          mask[index] = mask_fill_value + 1;
        }
     // Takes care of case of no masking
      if (mask_nbands == 0)
      {
        mask_nbands = 1;
        one_mask_band = true;
      }
    }

    float *input_image = new float[ncols*nrows];
    int non_zero_npix; 
    double dnpix, dsum, dsumsq, min_value, max_value, mean_value, std_dev_value;
    for (band = 0; band < nbands; band++)
    {
      rb = inDataset->GetRasterBand((band+1));
      if (rb->RasterIO(GF_Read, 0, 0, ncols, nrows, &input_image[0], ncols, nrows, GDT_Float32, 0, 0)
          == CE_Failure)
      {
        cout << "ERROR: Could not read input_image data" << endl;
        return false;
      }

      if (!one_mask_band)
      {
        if (params.mask_flag)
        {
          mrb = maskDataset->GetRasterBand((band+1));
          if (mrb->RasterIO(GF_Read, 0, 0, ncols, nrows, &mask[0], ncols, nrows, GDT_Byte, 0, 0)
              == CE_Failure)
          {
            cout << "ERROR: Could not read mask data" << endl;
            return false;
          }
        }
        else
        {
          for (row = 0; row < nrows; row++)
            for (col = 0; col < ncols; col++)
            {
              index = col + row*ncols;
              if (input_image[index] == fill_value)
                mask[index] = mask_fill_value;
              else
                mask[index] = mask_fill_value + 1;
            }
        }
      }
      non_zero_npix = 0;
      min_value = FLT_MAX;
      max_value = dnpix = dsum = dsumsq = 0.0;
      for (row = 0; row < nrows; row++)
      {
        for (col = 0; col < ncols; col++)
        {
          index = col + row*ncols;
          if (mask[index] != mask_fill_value)
          {
            if (input_image[index] != 0.0)
              non_zero_npix++;
            if (input_image[index] < min_value)
              min_value = input_image[index];
            if (input_image[index] > max_value)
              max_value = input_image[index];
            dnpix += 1.0;
            dsum += input_image[index];
            dsumsq += input_image[index]*input_image[index];
          }
        }
      }
     
      if (dnpix > 0.0)
        mean_value = dsum/dnpix;
      else
        mean_value = 0.0;

      if (dnpix > 1.0)
        std_dev_value = (dsumsq - ((dsum*dsum)/dnpix))/(dnpix-1.0);
      else if (dnpix == 1.0)
        std_dev_value = 0.0;
      else
        std_dev_value = -1.0;  // Negative value flags invalid result
               
      if (std_dev_value > 0.0)
        std_dev_value = sqrt(std_dev_value);

      cout.precision(10);
      cout << "For band " << band << ", number of non-zero pixels = " << non_zero_npix;
      cout << ", number of valid pixels = " << (int) dnpix << ", minimum = " << min_value << endl;
      cout << "            maximum = " << max_value << ", mean = " << mean_value << " and std_dev = " << std_dev_value << endl;
      
    } // for (band = 0; band < nbands; band++)

    GDALClose( (GDALDatasetH) inDataset);
    if (params.mask_flag)
      GDALClose( (GDALDatasetH) maskDataset);

    return true;
  }

} // CommonTilton

