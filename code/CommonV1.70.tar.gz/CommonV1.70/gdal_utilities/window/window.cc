// window.cc

#include "window.h"
#include "params/params.h"
#include <gdal_priv.h>
#include <iostream>
#include <float.h>
#include <algorithm>

// Externals
extern CommonTilton::Params params;

namespace CommonTilton
{
  bool window()
  {
    int col, row, band, index, has_fill = false;
    int ncols, nrows, nbands, mask_nbands = 0;
    double fill_value = 0.0;
    GDALDataset *inDataset, *maskDataset, *outDataset, *outmaskDataset;
    GDALDriver *driver;
    GDALRasterBand *rb, *mrb, *wb, *mwb;

  // Check input image
    inDataset = (GDALDataset *)GDALOpen(params.input_image_file.c_str(), GA_ReadOnly);
    if (!inDataset)
    {
      cout << "Could not open input_image file name = " << params.input_image_file << endl;
      return false;
    }
    ncols = inDataset->GetRasterXSize();
    nrows = inDataset->GetRasterYSize();
    nbands = inDataset->GetRasterCount();
    driver = inDataset->GetDriver();
    cout << "Performing Window Analysis on input image " << params.input_image_file << endl;
    cout << "with ncols = " << ncols << ", nrows = " << nrows << " and nbands = " << nbands << endl;

  // Handle masking
    unsigned char *mask = new unsigned char[ncols*nrows];
    int mask_has_fill = false;
    unsigned char mask_fill_value = params.mask_value;
    if (params.mask_flag)
    {
      maskDataset = (GDALDataset *)GDALOpen(params.mask_file.c_str(), GA_ReadOnly);
      if (!maskDataset)
      {
        cout << "ERROR: Could not open mask file name = " << params.mask_file << endl;
        return false;
      }
      if ((maskDataset->GetRasterXSize() != ncols) ||
          (maskDataset->GetRasterYSize() != nrows))
      {
        cout << "ERROR: mask image " << params.mask_file << " does not match input_image in size." << endl;
        return false;
      }
      mask_nbands = maskDataset->GetRasterCount();
      if ((mask_nbands > 1) && (mask_nbands != nbands))
      {
        cout << "ERROR: multispectral mask image " << params.mask_file << " does not match input_image number of bands." << endl;
        return false;
      }
      mrb = maskDataset->GetRasterBand(1);
      mask_has_fill = false;
      mask_fill_value = mrb->GetNoDataValue(&mask_has_fill);
      if (!mask_has_fill)
        mask_fill_value = params.mask_value;
    }
    else
    {
      maskDataset = NULL;
      rb = inDataset->GetRasterBand(1);
      has_fill = false;
      fill_value = rb->GetNoDataValue(&has_fill);
      if (has_fill)
        mask_nbands = nbands;
      else
        mask_nbands = 0;
    }
    bool one_mask_band = ((params.mask_flag) && (mask_nbands == 1));
    if (one_mask_band)
    {
      mrb = maskDataset->GetRasterBand(1);
      if (mrb->RasterIO(GF_Read, 0, 0, ncols, nrows, &mask[0], ncols, nrows, GDT_Byte, 0, 0)
          == CE_Failure)
      {
        cout << "ERROR: Could not read mask data" << endl;
        return false;
      }
    }
    else
    {
      for (row = 0; row < nrows; row++)
        for (col = 0; col < ncols; col++)
        {
          index = col + row*ncols;
          mask[index] = mask_fill_value + 1;
        }
     // Takes care of case of no masking
      if (mask_nbands == 0)
      {
        mask_nbands = 1;
        one_mask_band = true;
      }
    }

   // Create output window image and output window mask
    char **papszOptions = NULL;
    outDataset = driver->Create(params.output_image_file.c_str(), ncols, nrows, nbands, GDT_Float32, papszOptions);
    outmaskDataset = driver->Create(params.output_mask_image_file.c_str(), ncols, nrows, 1, GDT_Byte, papszOptions);
    string projection_type = inDataset->GetProjectionRef();
    if ((projection_type != "") && ((projection_type.find("Unknown") == string::npos) || (projection_type.size() > 10)))
    {
      outDataset->SetProjection( projection_type.c_str());
      outmaskDataset->SetProjection( projection_type.c_str());
    }
    double imageGeoTransform[6];
    if ( inDataset->GetGeoTransform( imageGeoTransform ) == CE_None )
    {
      outDataset->SetGeoTransform( imageGeoTransform);
      outmaskDataset->SetGeoTransform( imageGeoTransform);
    }
    const char *pszGCPProj = inDataset->GetGCPProjection();
    if ((pszGCPProj != NULL) && (strlen(pszGCPProj) > 0))
    {
      int nGCPs = inDataset->GetGCPCount();
      const GDAL_GCP *psGCP;
      psGCP = inDataset->GetGCPs();
      if (nGCPs > 0)
      {
        outDataset->SetGCPs(nGCPs,psGCP,pszGCPProj);
        outmaskDataset->SetGCPs(nGCPs,psGCP,pszGCPProj);
      }
    }

    float *input_image = new float[ncols*nrows];
    float *out_image = new float[ncols*nrows];
    unsigned char *out_mask_image = new unsigned char[ncols*nrows];
    unsigned char *temp_out_mask_image = new unsigned char[ncols*nrows];
    for (row = 0; row < nrows; row++)
      for (col = 0; col < ncols; col++)
      {
        index = col + row*ncols;
        out_image[index] = 0.0;
        out_mask_image[index] = 1;
      }
    for (band = 0; band < nbands; band++)
    {
      rb = inDataset->GetRasterBand((band+1));
      if (rb->RasterIO(GF_Read, 0, 0, ncols, nrows, &input_image[0], ncols, nrows, GDT_Float32, 0, 0)
          == CE_Failure)
      {
        cout << "ERROR: Could not read input_image data" << endl;
        return false;
      }
      if (!one_mask_band)
      {
        if (params.mask_flag)
        {
          mrb = maskDataset->GetRasterBand((band+1));
          if (mrb->RasterIO(GF_Read, 0, 0, ncols, nrows, &mask[0], ncols, nrows, GDT_Byte, 0, 0)
              == CE_Failure)
          {
            cout << "ERROR: Could not read mask data" << endl;
            return false;
          }
        }
        else
        {
          for (row = 0; row < nrows; row++)
            for (col = 0; col < ncols; col++)
            {
              index = col + row*ncols;
              if (input_image[index] == fill_value)
                mask[index] = mask_fill_value;
              else
                mask[index] = mask_fill_value + 1;
            }
        }
      }
      window(ncols,nrows,input_image,mask,mask_fill_value,out_image,temp_out_mask_image);
      for (row = 0; row < nrows; row++)
        for (col = 0; col < ncols; col++)
        {
          index = col + row*ncols;
          if (temp_out_mask_image[index] == 0)
            out_mask_image[index] = 0;
        }
      wb = outDataset->GetRasterBand((band+1));
      if (wb->RasterIO(GF_Write, 0, 0, ncols, nrows, out_image, ncols, nrows, GDT_Float32, 0, 0)
          == CE_Failure)
      {
        cout << "ERROR: Could not write output_image data" << endl;
        return false;
      }
    } // for (band = 0; band < nbands; band++)
    mwb = outmaskDataset->GetRasterBand((1));
    if (mwb->RasterIO(GF_Write, 0, 0, ncols, nrows, out_mask_image, ncols, nrows, GDT_Byte, 0, 0)
        == CE_Failure)
    {
      cout << "ERROR: Could not write output_mask data" << endl;
      return false;
    }


    GDALClose( (GDALDatasetH) inDataset);
    if (params.mask_flag)
      GDALClose( (GDALDatasetH) maskDataset);
    GDALClose( (GDALDatasetH) outDataset);
    GDALClose( (GDALDatasetH) outmaskDataset);

    return true;
  }

  bool window(int &ncols, int &nrows, float *input_image, unsigned char *mask_data, unsigned char &mask_fill_value,
             float *operation_values, unsigned char *operation_mask)
  {
    int col, row, local_col, local_row, index, window_col, window_row, window_index;
    double *window = new double[params.window_size*params.window_size];
    unsigned char *window_mask = new unsigned char[params.window_size*params.window_size];
    float operation_value;
    int window_range = params.window_size/2;
    bool valid_flag;

    for (row = 0; row < nrows; row++)
    {
      for (col = 0; col < ncols; col++)
      {
        for (window_row = 0; window_row < params.window_size; window_row++)
        {
          for (window_col = 0; window_col < params.window_size; window_col++)
          {
            window_index = window_col + window_row*params.window_size;
            local_row = row - window_range + window_row;
            local_col = col - window_range + window_col;
            if ((local_row >= 0) && (local_row < nrows) && 
                (local_col >= 0) && (local_col < ncols))
            {
              window_mask[window_index] = 1;
              index = local_col + local_row*ncols;
              if (mask_data[index] != mask_fill_value)
              {
                window_mask[window_index] = 1;
                window[window_index] = input_image[index];
              }
              else
              {
                window_mask[window_index] = 0;
              }
            }
            else
            {
              window_mask[window_index] = 0;
            }
          } // for (window_col = 0; window_col < params.window_size; window_col++)
        } // for (window_row = 0; window_row < params.window_size; window_row++)
        switch (params.operation)
        {
         // Window Average
          case 1:  operation_value = (float) window_average(window,window_mask,valid_flag);
                   break;
         // Window Maximum
          case 2:  operation_value = (float) window_maximum(window,window_mask,valid_flag);
                   break;
         // Window Minimum
          case 3:  operation_value = (float) window_minimum(window,window_mask,valid_flag);
                   break;
         // Window Median
          case 4:  operation_value = (float) window_median(window,window_mask,valid_flag);
                   break;
         // Invalid
          default: operation_value = 0.0;
                   valid_flag = false;
                   break;
        }
        index = col + row*ncols;
        operation_values[index] = operation_value;
        operation_mask[index] = 0;
        if (valid_flag)
          operation_mask[index] = 1;
      } // for (col = 0; col < ncols; col++)
    } // for (row = 0; row < nrows; row++)

    return true;
  }

  double window_average(double *window, unsigned char *window_mask, bool& valid_flag)
  {
    int col, row, index;
    double dnpix, dsum, window_value;

    dnpix = 0.0;
    dsum = 0.0;
    for (row = 0; row < params.window_size; row++)
    {
      for (col = 0; col < params.window_size; col++)
      {
        index = col + row*params.window_size;
        if (window_mask[index] == 1)
        {
          dnpix += 1.0;
          dsum += window[index];
        }
      }
    }

    if (dnpix > 0.0)
    {
      window_value = dsum/dnpix;
      valid_flag = true;
    }
    else
    {
      window_value = 0.0;
      valid_flag = false;
    }

    return window_value;
  }

  double window_maximum(double *window, unsigned char *window_mask, bool& valid_flag)
  {
    int col, row, index, npix;
    double window_value;

    npix = 0;
    window_value = -FLT_MAX;
    for (row = 0; row < params.window_size; row++)
    {
      for (col = 0; col < params.window_size; col++)
      {
        index = col + row*params.window_size;
        if (window_mask[index] == 1)
        {
          npix++;
          if (window[index] > window_value)
            window_value = window[index];
        }
      }
    }

    if (npix > 0)
      valid_flag = true;
    else
      valid_flag = false;

    return window_value;
  }

  double window_minimum(double *window, unsigned char *window_mask, bool& valid_flag)
  {
    int col, row, index, npix;
    double window_value;

    npix = 0;
    window_value = FLT_MAX;
    for (row = 0; row < params.window_size; row++)
    {
      for (col = 0; col < params.window_size; col++)
      {
        index = col + row*params.window_size;
        if (window_mask[index] == 1)
        {
          npix++;
          if (window[index] < window_value)
            window_value = window[index];
        }
      }
    }

    if (npix > 0)
      valid_flag = true;
    else
      valid_flag = false;

    return window_value;
  }

  double window_median(double *window, unsigned char *window_mask, bool& valid_flag)
  {
    int col, row, index, npix, mid_index;
    double window_value;
    vector<double> data_vector;

    npix = 0;
    for (row = 0; row < params.window_size; row++)
    {
      for (col = 0; col < params.window_size; col++)
      {
        index = col + row*params.window_size;
        if (window_mask[index] == 1)
        {
          npix++;
          data_vector.push_back(window[index]);
        }
      }
    }

    if (npix > 0)
    {
      valid_flag = true;
      sort(data_vector.begin(),data_vector.end());
      mid_index = npix/2;
      window_value = data_vector[mid_index];
    }
    else
    {
      valid_flag = false;
      window_value = 0.0;
    }

    return window_value;
  }

} // CommonTilton

