#ifndef WINDOW_H
#define WINDOW_H

using namespace std;

namespace CommonTilton
{

  bool window();
  bool window(int &ncols, int &nrows, float *input_image, unsigned char *mask_data, unsigned char &mask_fill_value,
              float *operation_values, unsigned char *operation_mask);
  double window_average(double *window, unsigned char *window_mask, bool& valid_flag);
  double window_maximum(double *window, unsigned char *window_mask, bool& valid_flag);
  double window_minimum(double *window, unsigned char *window_mask, bool& valid_flag);
  double window_median(double *window, unsigned char *window_mask, bool& valid_flag);

} // CommonTilton

#endif // WINDOW_H

