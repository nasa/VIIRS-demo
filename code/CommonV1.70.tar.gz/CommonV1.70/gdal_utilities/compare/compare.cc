// compare.cc

#include "compare.h"
#include "params/params.h"
#include <gdal_priv.h>
#include <iostream>
#include <float.h>

// Externals
extern CommonTilton::Params params;

namespace CommonTilton
{
  bool compare()
  {
    int col, row, band, index;
    int ncols, nrows, nbands;
    GDALDataset *in1Dataset, *in2Dataset = NULL, *outDataset;
    GDALDataType datatype;
    GDALDriver *driver;
    GDALRasterBand *rb, *wb;

  // Check input image(s)
    in1Dataset = (GDALDataset *)GDALOpen(params.input_image1_file.c_str(), GA_ReadOnly);
    if (!in1Dataset)
    {
      cout << "Could not open first input_image file, name = " << params.input_image1_file << endl;
      return false;
    }
    ncols = in1Dataset->GetRasterXSize();
    nrows = in1Dataset->GetRasterYSize();
    nbands = in1Dataset->GetRasterCount();
    datatype = in1Dataset->GetRasterBand(1)->GetRasterDataType();
    driver = in1Dataset->GetDriver();
    if (params.input_image2_flag)
    {
      in2Dataset = (GDALDataset *)GDALOpen(params.input_image2_file.c_str(), GA_ReadOnly);
      if (!in2Dataset)
      {
        cout << "Could not open second input_image file, name = " << params.input_image2_file << endl;
        return false;
      }
      if ((ncols != in2Dataset->GetRasterXSize()) || 
          (nrows != in2Dataset->GetRasterYSize()) ||
          (nbands != in2Dataset->GetRasterCount()))
      {
        cout << "ERROR: Size mismatch between first and second input images." << endl;
        return false;
      }
    }

   // Create output compare image
    char **papszOptions = NULL;
    outDataset = driver->Create(params.output_image_file.c_str(), ncols, nrows, nbands, datatype, papszOptions);
    const char *pszProj = in1Dataset->GetProjectionRef();
    if ((pszProj != NULL) && (strlen(pszProj) > 0))
    {
      outDataset->SetProjection(pszProj);
    }
    double imageGeoTransform[6];
    if ( in1Dataset->GetGeoTransform( imageGeoTransform ) == CE_None )
    {
      outDataset->SetGeoTransform( imageGeoTransform);
    }
    const char *pszGCPProj = in1Dataset->GetGCPProjection();
    if ((pszGCPProj != NULL) && (strlen(pszGCPProj) > 0))
    {
      int nGCPs = in1Dataset->GetGCPCount();
      const GDAL_GCP *psGCP;
      psGCP = in1Dataset->GetGCPs();
      if (nGCPs > 0)
      {
        outDataset->SetGCPs(nGCPs,psGCP,pszGCPProj);
      }
    }

    float *input_image1 = new float[ncols*nrows];
    float *input_image2 = NULL;
    if (params.input_image2_flag)
      input_image2 = new float[ncols*nrows];
    unsigned char *output_image = new unsigned char[ncols*nrows];
    for (band = 0; band < nbands; band++)
    {
      rb = in1Dataset->GetRasterBand((band+1));
      if (rb->RasterIO(GF_Read, 0, 0, ncols, nrows, &input_image1[0], ncols, nrows, GDT_Float32, 0, 0)
          == CE_Failure)
      {
        cout << "ERROR: Could not read input_image1 data" << endl;
        return false;
      }

      if (params.input_image2_flag)
      {
        rb = in2Dataset->GetRasterBand((band+1));
        if (rb->RasterIO(GF_Read, 0, 0, ncols, nrows, &input_image2[0], ncols, nrows, GDT_Float32, 0, 0)
            == CE_Failure)
        {
          cout << "ERROR: Could not read input_image2 data" << endl;
          return false;
        }
      }

      for (row = 0; row < nrows; row++)
      {
        for (col = 0; col < ncols; col++)
        {
          index = col + row*ncols;
          output_image[index] = 0;
          switch (params.compare_type)
          {
              case Equal:     if (params.input_image2_flag)
                                output_image[index] = (input_image1[index] == input_image2[index]);
                              else
                                output_image[index] = (input_image1[index] == params.compare_value);
                              break;
              case LessThan:  if (params.input_image2_flag)
                                output_image[index] = (input_image1[index] < input_image2[index]);
                              else
                                output_image[index] = (input_image1[index] < params.compare_value);
                              break;
              case MoreThan:  if (params.input_image2_flag)
                                output_image[index] = (input_image1[index] > input_image2[index]);
                              else
                                output_image[index] = (input_image1[index] > params.compare_value);
                              break;
              case NotEqual:  if (params.input_image2_flag)
                                output_image[index] = (input_image1[index] != input_image2[index]);
                              else
                                output_image[index] = (input_image1[index] != params.compare_value);
                              break;
              default:        cout << "ERROR: Invalid opearation\n" << endl;
                                return false;
                              break;
          }
          if (output_image[index])
            output_image[index] = params.output_value;
        }
      }
      wb = outDataset->GetRasterBand((band+1));
      if (wb->RasterIO(GF_Write, 0, 0, ncols, nrows, output_image, ncols, nrows, GDT_Byte, 0, 0)
          == CE_Failure)
      {
        cout << "ERROR: Could not write output_image data" << endl;
        return false;
      }
    }

    GDALClose( (GDALDatasetH) in1Dataset);
    if (params.input_image2_flag)
      GDALClose( (GDALDatasetH) in2Dataset);
    GDALClose( (GDALDatasetH) outDataset);

    return true;
  }

} // CommonTilton

