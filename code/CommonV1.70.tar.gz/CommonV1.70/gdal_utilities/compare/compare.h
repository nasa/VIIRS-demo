#ifndef COMPARE_H
#define COMPARE_H

using namespace std;

namespace CommonTilton
{
  bool compare();

} // CommonTilton

#endif // COMPARE_H

