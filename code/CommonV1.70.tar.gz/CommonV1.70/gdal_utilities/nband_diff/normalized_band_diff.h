#ifndef NBANDDIFF_H
#define NBANDDIFF_H

#include <string>
#include <cstring>

using namespace std;

  bool normalized_band_diff(string input_image_file, string output_image_file);

#endif // NBANDDIFF_H

