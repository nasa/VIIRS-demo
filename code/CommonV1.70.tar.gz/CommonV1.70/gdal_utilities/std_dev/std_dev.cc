// std_dev.cc

#include "std_dev.h"
#include "params/params.h"
#include <gdal_priv.h>
#include <iostream>
#include <float.h>
#include <algorithm>

// Externals
extern CommonTilton::Params params;

namespace CommonTilton
{
  bool std_dev()
  {
    int col, row, band, index, has_fill = false;
    int ncols, nrows, nbands, mask_nbands = 0;
    double fill_value = 0.0;
    GDALDataset *inDataset, *maskDataset, *outDataset, *outmaskDataset;
    GDALDriver *driver;
    GDALRasterBand *rb, *mrb, *wb, *mwb;

  // Check input image
    inDataset = (GDALDataset *)GDALOpen(params.input_image_file.c_str(), GA_ReadOnly);
    if (!inDataset)
    {
      cout << "Could not open input_image file name = " << params.input_image_file << endl;
      return false;
    }
    ncols = inDataset->GetRasterXSize();
    nrows = inDataset->GetRasterYSize();
    nbands = inDataset->GetRasterCount();
    driver = inDataset->GetDriver();
    cout << "Performing Standard Deviation Analysis on input image " << params.input_image_file << endl;
    cout << "with ncols = " << ncols << ", nrows = " << nrows << " and nbands = " << nbands << endl;

  // Handle masking
    unsigned char *mask = new unsigned char[ncols*nrows];
    int mask_has_fill = false;
    unsigned char mask_fill_value = params.mask_value;
    if (params.mask_flag)
    {
      maskDataset = (GDALDataset *)GDALOpen(params.mask_file.c_str(), GA_ReadOnly);
      if (!maskDataset)
      {
        cout << "ERROR: Could not open mask file name = " << params.mask_file << endl;
        return false;
      }
      if ((maskDataset->GetRasterXSize() != ncols) ||
          (maskDataset->GetRasterYSize() != nrows))
      {
        cout << "ERROR: mask image " << params.mask_file << " does not match input_image in size." << endl;
        return false;
      }
      mask_nbands = maskDataset->GetRasterCount();
      if ((mask_nbands > 1) && (mask_nbands != nbands))
      {
        cout << "ERROR: multispectral mask image " << params.mask_file << " does not match input_image number of bands." << endl;
        return false;
      }
      mrb = maskDataset->GetRasterBand(1);
      mask_has_fill = false;
      mask_fill_value = mrb->GetNoDataValue(&mask_has_fill);
      if (!mask_has_fill)
        mask_fill_value = params.mask_value;
    }
    else
    {
      maskDataset = NULL;
      rb = inDataset->GetRasterBand(1);
      has_fill = false;
      fill_value = rb->GetNoDataValue(&has_fill);
      if (has_fill)
        mask_nbands = nbands;
      else
        mask_nbands = 0;
    }
    bool one_mask_band = ((params.mask_flag) && (mask_nbands == 1));
    if (one_mask_band)
    {
      mrb = maskDataset->GetRasterBand(1);
      if (mrb->RasterIO(GF_Read, 0, 0, ncols, nrows, &mask[0], ncols, nrows, GDT_Byte, 0, 0)
          == CE_Failure)
      {
        cout << "ERROR: Could not read mask data" << endl;
        return false;
      }
    }
    else
    {
      for (row = 0; row < nrows; row++)
        for (col = 0; col < ncols; col++)
        {
          index = col + row*ncols;
          mask[index] = mask_fill_value + 1;
        }
     // Takes care of case of no masking
      if (mask_nbands == 0)
      {
        mask_nbands = 1;
        one_mask_band = true;
      }
    }

   // Create output std_dev image and output std_dev mask
    int out_nbands = 1;
    char **papszOptions = NULL;
    if (params.output_type == 1)
      out_nbands = nbands;
    outDataset = driver->Create(params.output_image_file.c_str(), ncols, nrows, out_nbands, GDT_Float32, papszOptions);
    outmaskDataset = driver->Create(params.output_mask_image_file.c_str(), ncols, nrows, out_nbands, GDT_Byte, papszOptions);
    string projection_type = inDataset->GetProjectionRef();
    if ((projection_type != "") && ((projection_type.find("Unknown") == string::npos) || (projection_type.size() > 10)))
    {
      outDataset->SetProjection( projection_type.c_str());
      outmaskDataset->SetProjection( projection_type.c_str());
    }
    double imageGeoTransform[6];
    if ( inDataset->GetGeoTransform( imageGeoTransform ) == CE_None )
    {
      outDataset->SetGeoTransform( imageGeoTransform);
      outmaskDataset->SetGeoTransform( imageGeoTransform);
    }
    const char *pszGCPProj = inDataset->GetGCPProjection();
    if ((pszGCPProj != NULL) && (strlen(pszGCPProj) > 0))
    {
      int nGCPs = inDataset->GetGCPCount();
      const GDAL_GCP *psGCP;
      psGCP = inDataset->GetGCPs();
      if (nGCPs > 0)
      {
        outDataset->SetGCPs(nGCPs,psGCP,pszGCPProj);
        outmaskDataset->SetGCPs(nGCPs,psGCP,pszGCPProj);
      }
    }

    float *input_image = new float[ncols*nrows];
    float *out_image, *temp_out_image = NULL;
    out_image = new float[ncols*nrows];
    unsigned char *out_mask_image, *temp_out_mask_image = NULL;
    out_mask_image = new unsigned char[ncols*nrows];
    if (params.output_type != 1)
    {
      if (params.output_type == 5)
        temp_out_image = new float[nbands*ncols*nrows];
      else
        temp_out_image = new float[ncols*nrows];
      temp_out_mask_image = new unsigned char[ncols*nrows];
      for (row = 0; row < nrows; row++)
        for (col = 0; col < ncols; col++)
        {
          index = col + row*ncols;
          out_image[index] = 0.0;
          if (params.output_type == 3)
            out_image[index] = -FLT_MAX;
          if (params.output_type == 4)
            out_image[index] = FLT_MAX;
          out_mask_image[index] = 1;
        }
    } // if (params.output_type != 1)
    for (band = 0; band < nbands; band++)
    {
      rb = inDataset->GetRasterBand((band+1));
      if (rb->RasterIO(GF_Read, 0, 0, ncols, nrows, &input_image[0], ncols, nrows, GDT_Float32, 0, 0)
          == CE_Failure)
      {
        cout << "ERROR: Could not read input_image data" << endl;
        return false;
      }

      if (!one_mask_band)
      {
        if (params.mask_flag)
        {
          mrb = maskDataset->GetRasterBand((band+1));
          if (mrb->RasterIO(GF_Read, 0, 0, ncols, nrows, &mask[0], ncols, nrows, GDT_Byte, 0, 0)
              == CE_Failure)
          {
            cout << "ERROR: Could not read mask data" << endl;
            return false;
          }

        }
        else
        {
          for (row = 0; row < nrows; row++)
            for (col = 0; col < ncols; col++)
            {
              index = col + row*ncols;
              if (input_image[index] == fill_value)
                mask[index] = mask_fill_value;
              else
                mask[index] = mask_fill_value + 1;
            }
        }
      }
      if (params.output_type == 1)
      {
        std_dev(ncols,nrows,input_image,mask,mask_fill_value,out_image,out_mask_image);
        wb = outDataset->GetRasterBand((band+1));
        if (wb->RasterIO(GF_Write, 0, 0, ncols, nrows, out_image, ncols, nrows, GDT_Float32, 0, 0)
            == CE_Failure)
        {
          cout << "ERROR: Could not write output_image data" << endl;
          return false;
        }

        mwb = outmaskDataset->GetRasterBand((band+1));
        if (mwb->RasterIO(GF_Write, 0, 0, ncols, nrows, out_mask_image, ncols, nrows, GDT_Byte, 0, 0)
            == CE_Failure)
        {
          cout << "ERROR: Could not write output_mask data" << endl;
          return false;
        }

      } // if (params.output_type == 1)
      else
      {
        if (params.output_type == 5)
          std_dev(ncols,nrows,input_image,mask,mask_fill_value,&temp_out_image[band*ncols*nrows],temp_out_mask_image);
        else
          std_dev(ncols,nrows,input_image,mask,mask_fill_value,temp_out_image,temp_out_mask_image);
        for (row = 0; row < nrows; row++)
          for (col = 0; col < ncols; col++)
          {
            index = col + row*ncols;
            if (params.output_type == 2)
              out_image[index] += temp_out_image[index];
            if (params.output_type == 3)
              if (temp_out_image[index] > out_image[index])
                out_image[index] = temp_out_image[index];
            if (params.output_type == 4)
              if (temp_out_image[index] < out_image[index])
                out_image[index] = temp_out_image[index];
            if (temp_out_mask_image[index] == 0)
              out_mask_image[index] = 0;
          }
      } // else if (params.output_type != 1)
    } // for (band = 0; band < nbands; band++)
    if (params.output_type != 1)
    {
      if (params.output_type == 2)
      {
        for (row = 0; row < nrows; row++)
          for (col = 0; col < ncols; col++)
          {
            index = col + row*ncols;
            out_image[index] /= nbands;
          }
      }
      if (params.output_type == 5)
      {
       // Find median at each pixel
        vector<float> data_vector(nbands);
        int mid_band = nbands/2;
        for (row = 0; row < nrows; row++)
          for (col = 0; col < ncols; col++)
          {
            index = col + row*ncols;
            if (out_mask_image[index] != 0)
            {
              for (band = 0; band < nbands; band++)
              {
                index = col + row*ncols + band*nrows*ncols;
                data_vector[band] = temp_out_image[index];
              }
              sort(data_vector.begin(),data_vector.end());
              index = col + row*ncols;
              out_image[index] = data_vector[mid_band];
            }
            else
              out_image[index] = 0.0;
          }
      }
      wb = outDataset->GetRasterBand((1));
      if (wb->RasterIO(GF_Write, 0, 0, ncols, nrows, out_image, ncols, nrows, GDT_Float32, 0, 0)
          == CE_Failure)
      {
        cout << "ERROR: Could not write output_image data" << endl;
        return false;
      }

      mwb = outmaskDataset->GetRasterBand((1));
      if (mwb->RasterIO(GF_Write, 0, 0, ncols, nrows, out_mask_image, ncols, nrows, GDT_Byte, 0, 0)
          == CE_Failure)
      {
        cout << "ERROR: Could not write output_mask_image data" << endl;
        return false;
      }

    }

    GDALClose( (GDALDatasetH) inDataset);
    if (params.mask_flag)
      GDALClose( (GDALDatasetH) maskDataset);
    GDALClose( (GDALDatasetH) outDataset);
    GDALClose( (GDALDatasetH) outmaskDataset);

    return true;
  }

  bool std_dev(int &ncols, int &nrows, float *input_image, unsigned char *mask_data, unsigned char &mask_fill_value,
               float *std_dev_values, unsigned char *std_dev_mask)
  {
    int col, row, local_col, local_row, index, window_col, window_row, window_index;
    double *window = new double[params.window_size*params.window_size];
    unsigned char *window_mask = new unsigned char[params.window_size*params.window_size];
    float std_dev_value;
    int window_range = params.window_size/2;

    for (row = 0; row < nrows; row++)
    {
      for (col = 0; col < ncols; col++)
      {
        for (window_row = 0; window_row < params.window_size; window_row++)
        {
          local_row = row - window_range + window_row;
          if ((local_row >= 0) && (local_row < nrows))
          {
            for (window_col = 0; window_col < params.window_size; window_col++)
            {
              window_index = window_col + window_row*params.window_size;
              local_col = col - window_range + window_col;
              if ((local_col >= 0) && (local_col < ncols))
              {
                window_mask[window_index] = 1;
                index = local_col + local_row*ncols;
                if (mask_data[index] != mask_fill_value)
                {
                  window_mask[window_index] = 1;
                  window[window_index] = input_image[index];
                }
                else
                {
                  window_mask[window_index] = 0;
                }
              }
              else
              {
                window_mask[window_index] = 0;
              }
            } // for (window_col = 0; window_col < params.window_size; window_col++)
          }
        } // for (window_row = 0; window_row < params.window_size; window_row++)
        std_dev_value = (float) std_dev(window,window_mask);
        index = col + row*ncols;
        std_dev_values[index] = std_dev_value;
        std_dev_mask[index] = 0;
        if (std_dev_value >= 0.0)
          std_dev_mask[index] = 1;
      } // for (col = 0; col < ncols; col++)
    } // for (row = 0; row < nrows; row++)

    return true;
  }

  double std_dev(double *window, unsigned char *window_mask)
  {
    int col, row, index;
    double dnpix, dsum, dsumsq, std_dev_value;

    dnpix = 0.0;
    dsum = 0.0;
    dsumsq = 0.0;
    for (row = 0; row < params.window_size; row++)
    {
      for (col = 0; col < params.window_size; col++)
      {
        index = col + row*params.window_size;
        if (window_mask[index] == 1)
        {
          dnpix += 1.0;
          dsum += window[index];
          dsumsq += window[index]*window[index];
        }
      }
    }

    if (dnpix > 1.0)
      std_dev_value = (dsumsq - ((dsum*dsum)/dnpix))/(dnpix-1.0);
    else if (dnpix == 1.0)
      std_dev_value = 0.0;
    else
      std_dev_value = -1.0;  // Negative value flags invalid result
               
    if (std_dev_value > 0.0)
      std_dev_value = sqrt(std_dev_value);

    return std_dev_value;
  }

} // CommonTilton

