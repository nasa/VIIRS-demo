/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<<
   >>>>
   >>>> 	Main program for the std_dev program - with required GDAL dependencies
   >>>>
   >>>>  Private:
   >>>> 	main(int argc, char **argv)
   >>>> 	usage()
   >>>> 	help()
   >>>>
   >>>>   Static:
   >>>>   Public:
   >>>>
   >>>>       Written: December 1, 2014
   >>>> Modifications: 
   >>>>
   >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<< */

#include "std_dev.h"
#include "params/params.h"
#include <gdal_priv.h>
#include <iostream>
#include <cstdlib>
#include <climits>
#include <cstring>

using namespace std;
using namespace CommonTilton;

//Globals
Params params("Version 1.70G, October 1, 2017");

// Forward function declarations
void usage();
void help();

/*-----------------------------------------------------------
|
|  Routine Name: main - Main program for the std_dev program interface
|
|  Purpose: Declares program parameters, reads parameter file and initializes program parameters,
|           opens log file (if requested), calls the std_dev function and returns an exit status.
|
|  Input from command line - parameter_file_name
|
|       Returns: EXIT_SUCCESS on success, EXIT_FAILURE on failure
|
|    Written By: James C. Tilton, NASA's GSFC, Mail Code 606.3, Greenbelt,MD 20771
|        E-Mail: James.C.Tilton@nasa.gov
|
|       Written: December 1, 2014
| Modifications: 
|
------------------------------------------------------------*/
int main(int argc, char *argv[])
{
  bool status = true;

  GDALAllRegister();

  if (argc == 1)
  {
    usage();
    cout << "ERROR: Need parameter file as argument." << endl;
    return EXIT_FAILURE;
  }
  else if ((strncmp(argv[1],"-v",2) == 0) || (strncmp(argv[1],"-version",8) == 0))
  {
    params.print_version();
    cout << "For help information: std_dev -h or std_dev -help" << endl << endl;
    return EXIT_SUCCESS;
  }
  else if ((strncmp(argv[1],"-h",2) == 0) || (strncmp(argv[1],"-help",5) == 0))
  {
    help();
    return EXIT_SUCCESS;
  }
  else if (strncmp(argv[1],"-",1) == 0)
  {
    usage();
    cout << "ERROR: The parameter file name cannot start with an \"-\"" << endl;
    return EXIT_FAILURE;
  }
  else
  {
    if (argc != 2)
    {
      usage();
      cout << "ERROR: Incorrect number of parameters on command line" << endl;
      return EXIT_FAILURE;
    }
    else
    {
      status = params.read(argv[1]);
      if (!status)
      {
        usage();
        cout << "ERROR: Error reading parameter file (read)" << endl;
        return EXIT_FAILURE;
      }
    }
  }

  if (status)
  {
    params.print();
    status = std_dev();
  }

  if (status)
  {
    cout << endl << "Successful completion of std_dev program" << endl;
  }
  else
  {
    cout << endl << "The std_dev program terminated improperly." << endl;
  }
  
  if (status)
    return EXIT_SUCCESS;
  else
    return EXIT_FAILURE;
}

/*-----------------------------------------------------------
|
|  Routine Name: usage - Usage function
|
|       Purpose: Informs user of proper usage of program when mis-used.
|
|         Input:
|
|        Output:
|
|       Returns: (void)
|
|    Written By: James C. Tilton, NASA's GSFC, Mail Code 606.3, Greenbelt,MD 20771
|        E-Mail: James.C.Tilton@nasa.gov
|
|       Written: December 1, 2014
| Modifications: 
|
------------------------------------------------------------*/
void usage()
{
  cout << endl << "Usage: " << endl << endl;
  cout << "std_dev parameter_file_name" << endl << endl;
  cout << "For help information: std_dev -h or std_dev -help" << endl;
  cout << "For version information: std_dev -v or std_dev -version" << endl;

  return;
}

/*-----------------------------------------------------------
|
|  Routine Name: help - Help function
|
|       Purpose: Provides help information to user on program parameters
|
|         Input:
|
|        Output:
|
|       Returns: (void)
|
|    Written By: James C. Tilton, NASA's GSFC, Mail Code 606.3, Greenbelt,MD 20771
|        E-Mail: James.C.Tilton@nasa.gov
|
|       Written: December 1, 2014
| Modifications: 
|
------------------------------------------------------------*/
void help()
{
  cout << endl << "The std_dev progam is called in the following manner:" << endl;
  cout << endl << "std_dev parameter_file_name" << endl;
  cout << endl << "where \"parameter_file_name\" is the name of the input parameter" << endl;
  cout << "file. For contents see below." << endl;
  cout << endl << "For this help: std_dev -h or std_dev -help" << endl;
  cout << endl << "For version information: std_dev -v or std_dev -version";
  cout << endl;
  cout << endl << "The parameter file consists of entries of the form:" << endl;
  cout << endl << "-parameter_name parameter_value(s)" << endl;

  fprintf(stdout,"\nThe following parameters may be specified in the input parameter file:\n\n");
  fprintf(stdout,"Input File and parameter:\n"
"-input_image		(string)	Input image file name(required)\n"
"					Integer data or float data types of\n"
"					up through 32 bits are allowed\n"
"-mask			(string)	Input image mask file name\n"
"					Data type must be \'Byte\'.\n"
"					NOTE: The input image may be instead\n"
"					masked by specifying a \'NoData Value\'\n"
"					in the input image.\n"
"					(optional, default = {none})\n"
"-mask_value		(int)		If input mask file is provided,\n"
"					this is the value in the mask file that\n"
"					designates invalid data. (default is\n"
"					 \'NoData Value\' from image header,\n"
"					 if provided - otherwise 0.)\n"
"-window_size		(int)		Window Size:\n"
"					  3. \"[3x3],\"\n"
"					  5. \"[5x5],\"\n"
"					  7. \"[7x7],\"\n"
"					  9. \"[9x9],\"\n"
"					(default = 3 -> \"[3x3]\")\n"
"-output_type		(int)		Output Type:\n"
"					  1. \"Multispectral,\"\n"
"					  2. \"Band Average,\"\n"
"					  3. \"Band Maximum,\"\n"
"					  4. \"Band Minimum,\"\n"
"					  5. \"Band Median,\"\n"
"					(default = 5 -> \"Band Median\")\n");
  fprintf(stdout,"Output Files:\n"
"-output_image		(string)	Output image (required)\n"
"-output_mask_image	(string)	Output mask image (required)\n");

  return;
}
