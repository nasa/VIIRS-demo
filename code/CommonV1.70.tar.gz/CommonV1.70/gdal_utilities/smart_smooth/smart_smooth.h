#ifndef SMART_SMOOTH_H
#define SMART_SMOOTH_H

using namespace std;

namespace CommonTilton
{

  bool smart_smooth();
  void mean_std_dev(int &ncols, int &nrows, float *input_image, unsigned char *mask_data, unsigned char &mask_fill_value,
                    float *mean_values, float *std_dev_values);
  void mean_std_dev(double *window, unsigned char *window_mask, double& mean_value, double& std_dev_value);
  void window_mean(int &ncols, int &nrows, float *mean_values, float *std_dev_values, float *out_image);
  float window_mean(float *mean_window, float *std_dev_window);

} // CommonTilton

#endif // SMART_SMOOTH_H

