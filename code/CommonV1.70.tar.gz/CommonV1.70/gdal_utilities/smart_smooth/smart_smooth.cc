// smart_smooth.cc

#include "smart_smooth.h"
#include "params/params.h"
#include <gdal_priv.h>
#include <iostream>
#include <float.h>
#include <algorithm>

// Externals
extern CommonTilton::Params params;

namespace CommonTilton
{
  bool smart_smooth()
  {
    int col, row, band, index, has_fill = false;
    int ncols, nrows, nbands, mask_nbands = 0;
    double fill_value = 0.0;
    GDALDataset *inDataset, *maskDataset, *outDataset;
    GDALDriver *driver;
    GDALRasterBand *rb, *mrb, *wb;

  // Check input image
    inDataset = (GDALDataset *)GDALOpen(params.input_image_file.c_str(), GA_ReadOnly);
    if (!inDataset)
    {
      cout << "Could not open input_image file name = " << params.input_image_file << endl;
      return false;
    }
    ncols = inDataset->GetRasterXSize();
    nrows = inDataset->GetRasterYSize();
    nbands = inDataset->GetRasterCount();
    driver = inDataset->GetDriver();
    cout << "Performing Smart Smooth Analysis on input image " << params.input_image_file << endl;
    cout << "with ncols = " << ncols << ", nrows = " << nrows << " and nbands = " << nbands << endl;

  // Handle masking
    unsigned char *mask = new unsigned char[ncols*nrows];
    int mask_has_fill = false;
    unsigned char mask_fill_value = params.mask_value;
    if (params.mask_flag)
    {
      maskDataset = (GDALDataset *)GDALOpen(params.mask_file.c_str(), GA_ReadOnly);
      if (!maskDataset)
      {
        cout << "ERROR: Could not open mask file name = " << params.mask_file << endl;
        return false;
      }
      if ((maskDataset->GetRasterXSize() != ncols) ||
          (maskDataset->GetRasterYSize() != nrows))
      {
        cout << "ERROR: mask image " << params.mask_file << " does not match input_image in size." << endl;
        return false;
      }
      mask_nbands = maskDataset->GetRasterCount();
      if ((mask_nbands > 1) && (mask_nbands != nbands))
      {
        cout << "ERROR: multispectral mask image " << params.mask_file << " does not match input_image number of bands." << endl;
        return false;
      }
      mrb = maskDataset->GetRasterBand(1);
      mask_has_fill = false;
      mask_fill_value = mrb->GetNoDataValue(&mask_has_fill);
      if (!mask_has_fill)
        mask_fill_value = params.mask_value;
    }
    else
    {
      maskDataset = NULL;
      rb = inDataset->GetRasterBand(1);
      has_fill = false;
      fill_value = rb->GetNoDataValue(&has_fill);
      if (has_fill)
        mask_nbands = nbands;
      else
        mask_nbands = 0;
    } // if (params.mask_flag)
    bool one_mask_band = ((params.mask_flag) && (mask_nbands == 1));
    if (one_mask_band)
    {
      mrb = maskDataset->GetRasterBand(1);
      if (mrb->RasterIO(GF_Read, 0, 0, ncols, nrows, &mask[0], ncols, nrows, GDT_Byte, 0, 0)
          == CE_Failure)
      {
        cout << "ERROR: Could not read mask data" << endl;
        return false;
      }
    }
    else
    {
      for (row = 0; row < nrows; row++)
        for (col = 0; col < ncols; col++)
        {
          index = col + row*ncols;
          mask[index] = mask_fill_value + 1;
        }
     // Takes care of case of no masking
      if (mask_nbands == 0)
      {
        mask_nbands = 1;
        one_mask_band = true;
      }
    }

   // Create output image
    char **papszOptions = NULL;
    outDataset = driver->Create(params.output_image_file.c_str(), ncols, nrows, nbands, GDT_Float32, papszOptions);
    const char *pszProj = inDataset->GetProjectionRef();
    if ((pszProj != NULL) && (strlen(pszProj) > 0))
      outDataset->SetProjection(pszProj);
    double imageGeoTransform[6];
    if ( inDataset->GetGeoTransform( imageGeoTransform ) == CE_None )
      outDataset->SetGeoTransform( imageGeoTransform);
    const char *pszGCPProj = inDataset->GetGCPProjection();
    if ((pszGCPProj != NULL) && (strlen(pszGCPProj) > 0))
    {
      int nGCPs = inDataset->GetGCPCount();
      const GDAL_GCP *psGCP;
      psGCP = inDataset->GetGCPs();
      if (nGCPs > 0)
        outDataset->SetGCPs(nGCPs,psGCP,pszGCPProj);
    }

    float *input_image = new float[ncols*nrows];
    float *mean_image = new float[ncols*nrows];
    float *std_dev_image = new float[ncols*nrows];
    float *out_image = new float[ncols*nrows];
    for (band = 0; band < nbands; band++)
    {
      rb = inDataset->GetRasterBand((band+1));
      if (rb->RasterIO(GF_Read, 0, 0, ncols, nrows, &input_image[0], ncols, nrows, GDT_Float32, 0, 0)
          == CE_Failure)
      {
        cout << "ERROR: Could not read input_image data" << endl;
        return false;
      }
      if (!one_mask_band)
      {
        if (params.mask_flag)
        {
          mrb = maskDataset->GetRasterBand((band+1));
          if (mrb->RasterIO(GF_Read, 0, 0, ncols, nrows, &mask[0], ncols, nrows, GDT_Byte, 0, 0)
              == CE_Failure)
          {
            cout << "ERROR: Could not read mask data" << endl;
            return false;
          }
        }
        else
        {
          for (row = 0; row < nrows; row++)
            for (col = 0; col < ncols; col++)
            {
              index = col + row*ncols;
              if (input_image[index] == fill_value)
                mask[index] = mask_fill_value;
              else
                mask[index] = mask_fill_value + 1;
            }
        }
      }
      mean_std_dev(ncols, nrows, input_image, mask, mask_fill_value, mean_image, std_dev_image);
      window_mean(ncols, nrows, mean_image, std_dev_image, out_image);
      wb = outDataset->GetRasterBand((band+1));
      if (wb->RasterIO(GF_Write, 0, 0, ncols, nrows, out_image, ncols, nrows, GDT_Float32, 0, 0)
          == CE_Failure)
      {
        cout << "ERROR: Could not write output_image data" << endl;
        return false;
     }

    } // for (band = 0; band < nbands; band++)

    GDALClose( (GDALDatasetH) inDataset);
    if (params.mask_flag)
      GDALClose( (GDALDatasetH) maskDataset);
    GDALClose( (GDALDatasetH) outDataset);

    return true;
  }

  void mean_std_dev(int &ncols, int &nrows, float *input_image, unsigned char *mask_data, unsigned char &mask_fill_value,
                    float *mean_values, float *std_dev_values)
  {
    int col, row, local_col, local_row, index, window_col, window_row, window_index;
    double *window = new double[params.window_size*params.window_size];
    unsigned char *window_mask = new unsigned char[params.window_size*params.window_size];
    double mean_value, std_dev_value;
    int window_range = params.window_size/2;

    for (row = 0; row < nrows; row++)
    {
      for (col = 0; col < ncols; col++)
      {
        for (window_row = 0; window_row < params.window_size; window_row++)
        {
          local_row = row - window_range + window_row;
          if ((local_row >= 0) && (local_row < nrows))
          {
            for (window_col = 0; window_col < params.window_size; window_col++)
            {
              window_index = window_col + window_row*params.window_size;
              local_col = col - window_range + window_col;
              if ((local_col >= 0) && (local_col < ncols))
              {
                window_mask[window_index] = 1;
                index = local_col + local_row*ncols;
                if (mask_data[index] != mask_fill_value)
                {
                  window_mask[window_index] = 1;
                  window[window_index] = input_image[index];
                }
                else
                {
                  window_mask[window_index] = 0;
                }
              }
              else
              {
                window_mask[window_index] = 0;
              }
            } // for (window_col = 0; window_col < params.window_size; window_col++)
          }
        } // for (window_row = 0; window_row < params.window_size; window_row++)
        mean_std_dev(window,window_mask,mean_value,std_dev_value);
        index = col + row*ncols;
        mean_values[index] = (float) mean_value;
        std_dev_values[index] = (float) std_dev_value;
      } // for (col = 0; col < ncols; col++)
    } // for (row = 0; row < nrows; row++)

    return;
  }

  void mean_std_dev(double *window, unsigned char *window_mask, double& mean_value, double& std_dev_value)
  {
    int col, row, index;
    double dnpix, dsum, dsumsq;

    dnpix = 0.0;
    dsum = 0.0;
    dsumsq = 0.0;
    for (row = 0; row < params.window_size; row++)
    {
      for (col = 0; col < params.window_size; col++)
      {
        index = col + row*params.window_size;
        if (window_mask[index] == 1)
        {
          dnpix += 1.0;
          dsum += window[index];
          dsumsq += window[index]*window[index];
        }
      }
    }

    if (dnpix > 0.0)
      mean_value = dsum/dnpix;
    else
      mean_value = -1.0;  // Negative value flags invalid result

    if (dnpix > 1.0)
      std_dev_value = (dsumsq - ((dsum*dsum)/dnpix))/(dnpix-1.0);
    else if (dnpix == 1.0)
      std_dev_value = 0.0;
    else
      std_dev_value = -1.0;  // Negative value flags invalid result
               
    if (std_dev_value > 0.0)
      std_dev_value = sqrt(std_dev_value);

    return;
  }

  void window_mean(int &ncols, int &nrows, float *mean_values, float *std_dev_values, float *out_image)
  {
    int col, row, local_col, local_row, index, window_col, window_row, window_index;
    float *mean_window = new float[params.window_size*params.window_size];
    float *std_dev_window = new float[params.window_size*params.window_size];
    int window_range = params.window_size/2;

    for (row = 0; row < nrows; row++)
    {
      for (col = 0; col < ncols; col++)
      {
        for (window_row = 0; window_row < params.window_size; window_row++)
        {
          local_row = row - window_range + window_row;
          if ((local_row >= 0) && (local_row < nrows))
          {
            for (window_col = 0; window_col < params.window_size; window_col++)
            {
              window_index = window_col + window_row*params.window_size;
              local_col = col - window_range + window_col;
              if ((local_col >= 0) && (local_col < ncols))
              {
                index = local_col + local_row*ncols;
                mean_window[window_index] = mean_values[index];
                std_dev_window[window_index] = std_dev_values[index];
              }
              else
              {
                mean_window[window_index] = -1.0;
                std_dev_window[window_index] = -1.0;
              }
            } // for (window_col = 0; window_col < params.window_size; window_col++)
          }
        } // for (window_row = 0; window_row < params.window_size; window_row++)
        index = col + row*ncols;
        out_image[index] = window_mean(mean_window,std_dev_window);
      } // for (col = 0; col < ncols; col++)
    } // for (row = 0; row < nrows; row++)

    return;
  }

  float window_mean(float *mean_window, float *std_dev_window)
  {
    int col, row, index, best_index = -1;

    for (row = 0; row < params.window_size; row++)
    {
      for (col = 0; col < params.window_size; col++)
      {
        index = col + row*params.window_size;
        if (best_index < 0)
        {
          if (std_dev_window[index] >= 0.0)
            best_index = index;
        }
        else
        {
          if (std_dev_window[index] >= 0.0)
          {
            if (std_dev_window[index] < std_dev_window[best_index])
              best_index = index;
          }
        }
      }
    }

    if (best_index < 0)
      return -1.0;
    else
      return mean_window[best_index];
  }

} // CommonTilton
