#ifndef MULTIPLY_H
#define MULTIPLY_H

using namespace std;

namespace CommonTilton
{
  bool add();

} // CommonTilton

#endif // MULTIPLY_H

