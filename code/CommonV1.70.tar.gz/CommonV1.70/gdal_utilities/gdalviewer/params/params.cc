// params.cc

#include "params.h"
#include <iostream>

CommonTilton::Image inputImage;
CommonTilton::Image maskImage;

namespace CommonTilton
{

 // Constructor
  Params::Params(const string& value)
  {
    version = value;
    input_image_file = "";
    mask_file = "";
    rgb_image_stretch = 2;
    range[0] = 0.1;
    range[1] = 0.9;

   // Flags for parameters under user control.
    input_image_flag = false;
    red_display_flag = false;
    green_display_flag = false;
    blue_display_flag = false;

  }

 // Destructor...
  Params::~Params() 
  {
  }

 // Print version
  void Params::print_version( )
  {
    cout << endl << version << endl << endl;

#if (defined(WINDOWS) || defined(CYGWIN))
    cout << endl << "Copyright (C) 2006 United States Government as represented by the" << endl;
#else
    cout << endl << "Copyright \u00a9 2006 United States Government as represented by the" << endl;
#endif
    cout << "Administrator of the National Aeronautics and Space Administration." << endl;
    cout << "No copyright is claimed in the United States under Title 17, U.S. Code." << endl;
    cout << "All Other Rights Reserved." << endl << endl;
  }

 // Open input image
  bool Params::open_image(const char *input_image)
  {
    int    band;
    double min_value;

    input_image_file = input_image;
    input_image_flag = inputImage.open(input_image_file);
    if (input_image_flag)
    {
      ncols = inputImage.get_ncols();
      nrows = inputImage.get_nrows();
      nbands = inputImage.get_nbands();
      dtype = inputImage.get_dtype();
      data_type = inputImage.get_data_type();
      switch (data_type)
      {
        case GDT_Byte:    break;
        case GDT_UInt16:  break;
        case GDT_Int16:   min_value = 0;
                          for (band = 0; band < nbands; band++)
                            if (min_value > inputImage.getMinimum(band))
                              min_value = inputImage.getMinimum(band);
                          if (min_value < 0.0)
                          {
                            cout << "WARNING: For the input image data file " << input_image_file << "," << endl;
                            cout << "short integer data will be converted to 32-bit float data." << endl;
                            dtype = Float32;
                          }
                          else
                          {
                            cout << "WARNING: For the input image data file " << input_image_file << "," << endl;
                            cout << "short integer data will be converted to unsigned short integer data." << endl;
                            dtype = UInt16;
                          }
                          break;
        case GDT_UInt32:  cout << "NOTE: For the input image data file " << input_image_file << "," << endl;
                          cout << "32-bit unsigned integer data will be converted to 32-bit float data." << endl;
                          dtype = Float32;
                          break;
        case GDT_Int32:   cout << "NOTE: For the input image data file " << input_image_file << "," << endl;
                          cout << "32-bit integer data will be converted to 32-bit float data." << endl;
                          dtype = Float32;
                          break;
        case GDT_Float32: break;
        case GDT_Float64: cout << "WARNING: For the input image data file " << input_image_file << "," << endl;
                          cout << "64-bit double data will be converted to 32-bit float data." << endl;
                          cout << "Out of ranges value will not be read properly." << endl;
                          dtype = Float32;
                          break;
        default:          cout << "Unknown or unsupported image data type for input image data file ";
                          cout << input_image_file << endl;
                          return false;
      }
    }

    if (!red_display_flag)
    {
      if (nbands < 3)
      {
        red_display_band = green_display_band = blue_display_band = 0;
        red_display_flag = green_display_flag = blue_display_flag = true;
      }
      else
      {
        red_display_band = 2;
        green_display_band = 1; 
        blue_display_band = 0;
        red_display_flag = green_display_flag = blue_display_flag = true;
      }
    }

    return true;
  }

 // Print parameters
 void Params::print()
 {
  // Print version
   cout << "This is " << version << endl << endl;
  // Print input parameters
   cout << "Input image file name: " << input_image_file << endl;
   cout << "Input image number of columns = " <<  ncols << endl;
   cout << "Input image number of rows = " <<  nrows << endl;
   cout << "Input image number of bands = " <<  nbands << endl;
   switch (dtype)
   {
     case UInt8:   cout << "Input image data type is UNSIGNED 8-bit (UInt8)" << endl;
                   break;
     case UInt16:  cout << "Input image data type is UNSIGNED 16-bit (UInt16)" << endl;
                   break;
     case Float32: cout << "Input image data type is 32-bit FLOAT (Float32)" << endl;
                   break;
     default:      cout << "Input image data type in invalid (Unknown)" << endl;
                   break;
   }
 }

} // namespace CommonTilton


