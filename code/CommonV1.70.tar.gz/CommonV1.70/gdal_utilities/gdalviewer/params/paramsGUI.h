#ifndef PARAMSGUI_H
#define PARAMSGUI_H

#include <gui/fileObject.h>
#include <gui/numberObject.h>
#include <gtkmm.h>

using namespace std;

namespace CommonTilton
{
  class ParamsGUI : public Gtk::Window
  {
    public:
        ParamsGUI();
        virtual ~ParamsGUI();
        void set_input_image_file(const string& file_name);

    protected:
      //Signal handlers:
        void on_help_requested();
        void on_run_program();
        void on_exit_requested();
        void on_input_image_selection_changed();
        void on_mask_image_selection_changed();
        void on_rgbImageStretchComboBox_changed();

      //Member widgets:
        Gtk::VBox vBox;
        Gtk::HBox displayBox, rgbImageStretchBox, rangeBox;
        FileObject input_image, mask_image;
        Gtk::Label requiredLabel;
        NumberObject redDisplayBand, greenDisplayBand, blueDisplayBand;
        Gtk::Label rgbImageStretchLabel;
        Gtk::ComboBoxText rgbImageStretchComboBox;
        NumberObject rangeFromObject, rangeToObject;

        Glib::RefPtr<Gtk::UIManager> m_refUIManager;
        Glib::RefPtr<Gtk::ActionGroup> m_refActionGroup;

    private:
  };

} // CommonTilton

#endif /* PARAMSGUI_H */
