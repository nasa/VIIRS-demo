#ifndef PARAMS_H
#define PARAMS_H

#include <image/image.h>
enum RHSEGDType { Unknown, UInt8, UInt16, UInt32, Float32 };
#include <string>
#include <fstream>

using namespace std;

namespace CommonTilton
{

  class Params 
  {
    public:
    // Constructor and Destructor
      Params(const string& value);
      virtual ~Params();

    // Member functions
      void print_version();
      bool open_image(const char *input_image);
      void print();

    /*-- Input image data file (required) --*/
      string input_image_file;     /*-- USER INPUT IMAGE FILENAME --*/
      bool   input_image_flag;     /*-- EXISTENCE FLAG --*/

    /*-- Number of columns in input image data file --*/
      int    ncols;                /*-- PROGRAM PARAMETER --*/

    /*-- Number of rows in input image data file --*/
      int    nrows;                /*-- PROGRAM PARAMETER --*/

    /*-- Number of spectral bands in input image data file --*/
      int    nbands;               /*-- PROGRAM PARAMETER --*/

    /*-- Data type of input image data --*/
      RHSEGDType dtype;            /*-- PROGRAM PARAMETER --*/
      GDALDataType data_type;      /*-- PROGRAM PARAMETER --*/

    /*-- Input data mask file (optional) --*/
      string mask_file;            /*-- USER INPUT FILENAME --*/
      bool   mask_flag;            /*-- EXISTENCE FLAG --*/

    /*-- Spectral bands to display as red, green and blue (required) --*/
      int  red_display_band, green_display_band, blue_display_band;
      bool red_display_flag, green_display_flag, blue_display_flag;

    /*-- RGB Image Stretch Option (optional - default supplied) --*/
      int rgb_image_stretch;

    /*-- Percentile Range for RGB Image Stretch (optional - defaults supplied) --*/
      float range[2];

    /* Program version */
      string version;              /* -- PROGRAM PARAMETER --*/

    /* Default current folder */
      string current_folder;       /* -- PROGRAM PARAMETER --*/

    /*-- Exit status from GUI --*/
      int     status;   	                /*-- PROGRAM PARAMETER --*/

    protected:

    private:
  };

} // CommonTilton

#endif /* PARAMS_H */
