// paramsGUI.cc
#include "paramsGUI.h"
#include "params.h"
#include <iostream>

extern CommonTilton::Params params;
extern CommonTilton::Image inputImage;
extern CommonTilton::Image maskImage;

namespace CommonTilton
{
 // Constructor
  ParamsGUI::ParamsGUI():
             vBox(false,10),
             input_image(" Image File to be Displayed:","Enter or Select the Input Image File",
                        Gtk::FILE_CHOOSER_ACTION_OPEN,true),
             mask_image(" Mask File (optional):","Enter or Select the Input Image File",
                        Gtk::FILE_CHOOSER_ACTION_OPEN,false),
             requiredLabel(" Required Files and Parameters (defaults given, if any):",0.0,0.0),
             redDisplayBand("Red Display Band:"),
             greenDisplayBand("Green Display Band:"),
             blueDisplayBand("Blue Display Band:"),
             rgbImageStretchLabel("RGB Image Stretch Option:"),
             rangeFromObject("Range From: "),
             rangeToObject("To: ")
  {
    set_title("GDAL Image Viewer Parameter Input");
    set_default_size(512,64);

    char *cwd;
    cwd = g_get_current_dir();
    params.current_folder = cwd;
    input_image.add_shortcut_folder(params.current_folder);
    input_image.set_current_folder(params.current_folder);
    g_free(cwd);

#ifdef GTKMM3
    rgbImageStretchComboBox.append("Linear Stretch with Percent Clipping");
    rgbImageStretchComboBox.append("      Histogram Equalization        ");
    rgbImageStretchComboBox.append(" Linear Stretch to Percentile Range ");
#else
    rgbImageStretchComboBox.append_text("Linear Stretch with Percent Clipping");
    rgbImageStretchComboBox.append_text("      Histogram Equalization        ");
    rgbImageStretchComboBox.append_text(" Linear Stretch to Percentile Range ");
#endif
    switch (params.rgb_image_stretch)
    {
      case 1:  
#ifdef ARTEMIS
               rgbImageStretchComboBox.set_active(0);
#else
               rgbImageStretchComboBox.set_active_text("Linear Stretch with Percent Clipping");
#endif
               break;
      case 2:  
#ifdef ARTEMIS
               rgbImageStretchComboBox.set_active(1);
#else
               rgbImageStretchComboBox.set_active_text("      Histogram Equalization        ");
#endif
               break;
      case 3:  
#ifdef ARTEMIS
               rgbImageStretchComboBox.set_active(2);
#else
               rgbImageStretchComboBox.set_active_text(" Linear Stretch to Percentile Range ");
#endif
               break;
      default: cout << "Invalid value for rgb_image_stretch" << endl;
               break;
    }
    rangeFromObject.set_fvalue(params.range[0]);
    rangeToObject.set_fvalue(params.range[1]);
    input_image.signal_selection_changed().connect(sigc::mem_fun(*this,
                         &ParamsGUI::on_input_image_selection_changed) );
    rgbImageStretchComboBox.signal_changed().connect(sigc::mem_fun(*this,
                         &ParamsGUI::on_rgbImageStretchComboBox_changed) );

    add(vBox); // put a MenuBar at the top of the box and other stuff below it.

  //Create actions for menus:
    m_refActionGroup = Gtk::ActionGroup::create();

    //Add normal Actions:
    m_refActionGroup->add( Gtk::Action::create("ActionMenu", "Program _Actions") );
    m_refActionGroup->add( Gtk::Action::create("Run", "_Run Program"),
                      sigc::mem_fun(*this, &ParamsGUI::on_run_program) );
    m_refActionGroup->add( Gtk::Action::create("Help", "_Help"),
                      sigc::mem_fun(*this, &ParamsGUI::on_help_requested) );
    m_refActionGroup->add( Gtk::Action::create("Exit", "_Exit"),
                      sigc::mem_fun(*this, &ParamsGUI::on_exit_requested) );

    m_refUIManager = Gtk::UIManager::create();
    m_refUIManager->insert_action_group(m_refActionGroup);
    add_accel_group(m_refUIManager->get_accel_group());

    //Layout the actions in the menubar:
    Glib::ustring ui_info = 
          "<ui>"
          "  <menubar name='MenuBar'>"
          "    <menu action='ActionMenu'>"
          "      <menuitem action='Run'/>"
          "      <separator/>"
          "      <menuitem action='Help'/>"
          "      <separator/>"
          "      <menuitem action='Exit'/>"
          "    </menu>"
          "  </menubar>"
          "</ui>";

#if (defined(GLIBMM_EXCEPTIONS_ENABLED) || (defined(ARTEMIS)))
    try
    {
      m_refUIManager->add_ui_from_string(ui_info);
    }
    catch(const Glib::Error& ex)
    {
      std::cerr << "building menus failed: " <<  ex.what();
    }
#else
    std::auto_ptr<Glib::Error> error;
    m_refUIManager->add_ui_from_string(ui_info, error);
    if(error.get())
    {
      std::cerr << "building menus failed: " <<  error->what();
    }
#endif //GLIBMM_EXCEPTIONS_ENABLED

    //Get the menubar widget, and add it to a container widget:
    Gtk::Widget* pMenubar = m_refUIManager->get_widget("/MenuBar");
    if(pMenubar)
      vBox.pack_start(*pMenubar, Gtk::PACK_SHRINK);

    vBox.pack_start(input_image);
    vBox.pack_start(mask_image);
    vBox.pack_start(requiredLabel);
    displayBox.pack_start(redDisplayBand);
    displayBox.pack_start(greenDisplayBand);
    displayBox.pack_start(blueDisplayBand);    
    vBox.pack_start(displayBox);
    rgbImageStretchBox.pack_start(rgbImageStretchLabel);
    rgbImageStretchBox.pack_start(rgbImageStretchComboBox);
    vBox.pack_start(rgbImageStretchBox);
    rangeBox.pack_start(rangeFromObject);
    rangeBox.pack_start(rangeToObject);
    vBox.pack_start(rangeBox);

    show_all_children();
//    displayBox.hide();
//    rgbImageStretchBox.hide();
    rangeBox.hide();
    mask_image.set_activeFlag(false);

    show();
  }

 // Destructor...
  ParamsGUI::~ParamsGUI() 
  {
  }

  void ParamsGUI::set_input_image_file(const string& file_name)
  {
    input_image.set_filename(file_name);
    on_input_image_selection_changed();
  }

  void ParamsGUI::on_input_image_selection_changed()
  {
    int    band;
    double min_value;

    params.input_image_file = input_image.get_filename();
    params.input_image_flag = inputImage.open(params.input_image_file);
    if (params.input_image_flag)
    {
      params.ncols = inputImage.get_ncols();
      params.nrows = inputImage.get_nrows();
      params.nbands = inputImage.get_nbands();
      params.dtype = inputImage.get_dtype();
      params.data_type = inputImage.get_data_type();
      switch (params.data_type)
      {
        case GDT_Byte:    break;
        case GDT_UInt16:  break;
        case GDT_Int16:   min_value = 0;
                          for (band = 0; band < params.nbands; band++)
                            if (min_value > inputImage.getMinimum(band))
                              min_value = inputImage.getMinimum(band);
                          if (min_value < 0.0)
                          {
                            cout << "WARNING: For the input image data file " << params.input_image_file << "," << endl;
                            cout << "short integer data will be converted to 32-bit float data." << endl;
                            params.dtype = Float32;
                          }
                          else
                          {
                            cout << "WARNING: For the input image data file " << params.input_image_file << "," << endl;
                            cout << "short integer data will be converted to unsigned short integer data." << endl;
                            params.dtype = UInt16;
                          }
                          break;
        case GDT_UInt32:  cout << "NOTE: For the input image data file " << params.input_image_file << "," << endl;
                          cout << "32-bit unsigned integer data will be converted to 32-bit float data." << endl;
                          params.dtype = Float32;
                          break;
        case GDT_Int32:   cout << "NOTE: For the input image data file " << params.input_image_file << "," << endl;
                          cout << "32-bit integer data will be converted to 32-bit float data." << endl;
                          params.dtype = Float32;
                          break;
        case GDT_Float32: break;
        case GDT_Float64: cout << "WARNING: For the input image data file " << params.input_image_file << "," << endl;
                          cout << "64-bit double data will be converted to 32-bit float data." << endl;
                          cout << "Out of ranges value will not be read properly." << endl;
                          params.dtype = Float32;
                          break;
        default:          cout << "Unknown or unsupported image data type for input image data file ";
                          cout << params.input_image_file << endl;
                          return;
      } 
    }
    else
    {
      cout << "WARNING:  Input image file " << params.input_image_file << " is of unknown format." << endl;
    }

    return;
  }

  void ParamsGUI::on_rgbImageStretchComboBox_changed()
  {
    string tmp_string;

    tmp_string = rgbImageStretchComboBox.get_active_text();
    if (tmp_string == "Linear Stretch with Percent Clipping")
      params.rgb_image_stretch = 1;
    else if (tmp_string == "      Histogram Equalization        ")
      params.rgb_image_stretch = 2;
    else if (tmp_string == " Linear Stretch to Percentile Range ")
      params.rgb_image_stretch = 3;
/*
    switch (params.rgb_image_stretch)
    {
      case 1:  cout << "rgb_image_stretch changed to \"Linear Stretch with Percent Clipping\"" << endl;
               break;
      case 2:  cout << "rgb_image_stretch changed to \"Histogram Equalization\"" << endl;
               break;
      case 3:  cout << "rgb_image_stretch changed to \"Linear Stretch to Percentile Range\"" << endl;
               break;
      default: cout << "Invalid value for rgb_image_stretch" << endl;
               break;
    }
*/
    if (params.rgb_image_stretch == 2)
      rangeBox.hide();
    else
      rangeBox.show();
    return;
  }

  void ParamsGUI::on_mask_image_selection_changed()
  {
    unsigned char mask_value = 0;
    double min_value, max_value;

    params.mask_file = mask_image.get_filename();
    params.mask_flag = maskImage.open(params.mask_file);

    if (params.mask_flag)
    {
      min_value = 0;
      max_value = 255;
      if (min_value > maskImage.getMinimum(0))
        min_value = maskImage.getMinimum(0);
      if (max_value < maskImage.getMaximum(0))
        max_value = maskImage.getMaximum(0);
      if ((min_value < 0.0) || (max_value > 255))
      {
        cout << "ERROR: Invalid range for input mask image. Must be in range 0 to 255." << endl;
        params.mask_flag = false;
        return;
      }
      if (maskImage.no_data_value_valid(0))
      {
        min_value = maskImage.get_no_data_value(0);
        if ((min_value < 256.0) && (min_value >= 0.0))
          mask_value = (unsigned char) min_value;
        else
        {
          cout << "ERROR: Mask value, " << mask_value << ", is out of 8-bit range" << endl;
          params.mask_flag = false;
          return;
        }
      }
      else
        mask_value = 0;
    }
    else
    {
      cout << "WARNING:  Input mask file " << params.mask_file << " is of unknown format." << endl;
      params.mask_flag = false;
    }

  }

  void ParamsGUI::on_help_requested()
  {
    Glib::ustring strMessage = "Enter in program parameters and run the program by\n"
                               "selecting the \"Run Program\" menu item under the\n"
                               "\"Program Actions\" menu.\n\nFor more help type "
                               "\"hsegviewer -help\" on the command line.\n\n";
    Gtk::MessageDialog dialog(strMessage, false, Gtk::MESSAGE_INFO, Gtk::BUTTONS_OK, true);
    
    dialog.run();
  }

  void ParamsGUI::on_run_program()
  {
    Glib::ustring tmp_string;

//    cout << "\"Run Program\" menu item selected" << endl;
    params.status = params.input_image_flag;
    if (!params.status)
    {
      input_image.set_filename("");
      Glib::ustring strMessage = "Invalid Input Image File.\n"
                                 "Please reselect a valid file.";
      Gtk::MessageDialog dialog(strMessage, false, Gtk::MESSAGE_INFO, Gtk::BUTTONS_OK, true);
     
      dialog.run();
      
      return;
    }

    params.red_display_flag = redDisplayBand.value_valid();
    if (params.red_display_flag)
    {
      params.red_display_band = redDisplayBand.get_value();
      if ((params.red_display_band < 0) || (params.red_display_band >= params.nbands))
        params.red_display_flag = false;
    }
    params.green_display_flag = greenDisplayBand.value_valid();
    if (params.green_display_flag)
    {
      params.green_display_band = greenDisplayBand.get_value();
      if ((params.green_display_band < 0) || (params.green_display_band >= params.nbands))
        params.green_display_flag = false;
    }
    params.blue_display_flag = blueDisplayBand.value_valid();
    if (params.blue_display_flag)
    {
      params.blue_display_band = blueDisplayBand.get_value();
      if ((params.blue_display_band < 0) || (params.blue_display_band >= params.nbands))
        params.blue_display_flag = false;
    }
    params.status = params.red_display_flag &&
                    params.green_display_flag && params.blue_display_flag;
    if (params.status)
    {
      tmp_string = rgbImageStretchComboBox.get_active_text();
      if (tmp_string == "Linear Stretch with Percent Clipping")
        params.rgb_image_stretch = 1;
      else if (tmp_string == "      Histogram Equalization        ")
        params.rgb_image_stretch = 2;
      else if (tmp_string == " Linear Stretch to Percentile Range ")
        params.rgb_image_stretch = 3;
      if (params.rgb_image_stretch != 2)
      {
        params.range[0] = rangeFromObject.get_fvalue();
        params.range[1] = rangeToObject.get_fvalue();
      }

      hide();
    }
    else
    {
      Glib::ustring strMessage = "Invalid values entered for red, green and/or blue display band.\n"
                                 "Please reenter valid values.";
      Gtk::MessageDialog dialog(strMessage, false, Gtk::MESSAGE_INFO, Gtk::BUTTONS_OK, true);
     
      dialog.run();
    }

    return;
  }

  void ParamsGUI::on_exit_requested()
  {
    cout << "\"Exit\" menu item selected" << endl;
    params.status = false;
    hide();
    return;
  }

} // namespace CommonTilton

