#ifndef GDALVIEWER_H
#define GDALVIEWER_H

#include <gui/fileObject.h>
#include <gui/numberObject.h>
#include <displayimage/displayimage.h>
#include <gtkmm.h>

using namespace std;

namespace CommonTilton
{
  class GDALViewer : public Gtk::Window
  {
    public:
        GDALViewer();
        virtual ~GDALViewer();

    protected:
      // Signal Handlers:
        void on_help_requested();
        void on_quit_requested();
        void on_input_image_selection_changed();
        void on_mask_image_selection_changed();
        void on_updateRGBImageButton_clicked();
        void on_rgbImageStretchComboBox_changed();

      //Child widgets:
        Gtk::VBox vBox;
        FileObject input_image, mask_image;
        Gtk::HBox displayBox, rgbImageStretchBox, rangeBox;
        
        Glib::RefPtr<Gtk::UIManager> m_refUIManager;
        Glib::RefPtr<Gtk::ActionGroup> m_refActionGroup;

        Gtk::Button rgbImageButton;
        Gtk::Button updateRGBImageButton;
        NumberObject redDisplayBand, greenDisplayBand, blueDisplayBand;
        Gtk::Label rgbImageStretchLabel;
        Gtk::ComboBoxText rgbImageStretchComboBox;
        NumberObject rangeFromObject, rangeToObject;

        DisplayImage rgbImageDisplay;

    private:
        bool initializeImages();
        void redisplay();
        
  };

} // CommonTilton

#endif // GDALVIEWER_H

