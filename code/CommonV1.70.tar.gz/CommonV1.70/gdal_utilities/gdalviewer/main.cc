/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<<
   >>>>
   >>>> 	Main program for the gdalviewer - GDAL Viewer - program
   >>>>
   >>>>  Private:
   >>>> 	main(int argc, char **argv)
   >>>> 	usage()
   >>>> 	help()
   >>>>
   >>>>   Static:
   >>>>   Public:
   >>>>
   >>>>       Written: April 25, 2019 (Based on hsegviewer)
   >>>> Modifications: 
   >>>>
   >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<< */

#include "gdalviewer.h"
#include "params/params.h"
#include "params/paramsGUI.h"
#include <image/image.h>
#include <iostream>
#include <fstream>
#include <gdal_priv.h>
#include <gtkmm.h>

using namespace std;
using namespace CommonTilton;

//Globals
Params params("Version 1.70G, April 25, 2019");

// Forward function declarations
void usage();
void help();

/*-----------------------------------------------------------
|
|  Routine Name: main - Main program for the gdalviewer program
|
|  Purpose: Declares program parameters, reads parameter file and initializes program parameters,
|           calls the gdalviewer function, and returns an exit status.
|
|  Input from command line - parameter_file_name
|
|       Returns: EXIT_SUCCESS on success, EXIT_FAILURE on failure
|
|    Written By: James C. Tilton, NASA's GSFC, Mail Code 606.3, Greenbelt,MD 20771
|        E-Mail: James.C.Tilton@nasa.gov
|
|       Written: April 25, 2019
| Modifications: 
|
------------------------------------------------------------*/
int main(int argc, char *argv[])
{
  bool status = true;

  GDALAllRegister();
  Gtk::Main kit(argc, argv);
  ParamsGUI paramsGUI;

  if (argc == 1)
  {
    Gtk::Main::run(paramsGUI);
    status = params.status;
  }
  else if ((strncmp(argv[1],"-v",2) == 0) || (strncmp(argv[1],"-version",8) == 0))
  {
    params.print_version();
    cout << "For help information: gdalviewer -h or gdalviewer -help" << endl << endl;
    return EXIT_SUCCESS;
  }
  else if ((strncmp(argv[1],"-h",2) == 0) || (strncmp(argv[1],"-help",5) == 0))
  {
    help();
    return EXIT_SUCCESS;
  }
  else if (strncmp(argv[1],"-",1) == 0)
  {
    usage();
    cout << "ERROR: The image file name cannot start with an \"-\"" << endl;
    return EXIT_FAILURE;
  }
  else
  {
    if (argc != 2)
    {
      usage();
      cout << "ERROR: Incorrect number of parameters on command line" << endl;
      return EXIT_FAILURE;
    }
    else
    {
      status = params.open_image(argv[1]);

      if (status)
        paramsGUI.hide();
      else
      {
        if (params.input_image_flag)
          paramsGUI.set_input_image_file(params.input_image_file);
        Gtk::Main::run(paramsGUI);
        status = params.status;
      }
    }
  }

  if (status)
  {
    params.print();
    GDALViewer gdalViewer;
    Gtk::Main::run(gdalViewer);
  }

  if (status)
  {
    cout << endl << "Successful completion of gdalviewer program" << endl;
  }
  else
  {
    cout << endl << "The gdalviewer program terminated improperly." << endl;
  }
  
  if (status)
    return EXIT_SUCCESS;
  else
    return EXIT_FAILURE;
}

/*-----------------------------------------------------------
|
|  Routine Name: usage - Usage function
|
|       Purpose: Informs user of proper usage of program when mis-used.
|
|         Input:
|
|        Output:
|
|       Returns: (void)
|
|    Written By: James C. Tilton, NASA's GSFC, Mail Code 606.3, Greenbelt,MD 20771
|        E-Mail: James.C.Tilton@nasa.gov
|
|       Written: April 25, 2019
| Modifications: 
|
------------------------------------------------------------*/
void usage()
{
  cout << endl << "Usage: " << endl << endl;
  cout << "gdalviewer" << endl;
  cout << "or" << endl;
  cout << "gdalviewer input_image_file_name" << endl << endl;
  cout << "For help information: gdalviewer -h or gdalviewer -help" << endl;
  cout << "For version information: gdalviewer -v or gdalviewer -version" << endl;

  return;
}

/*-----------------------------------------------------------
|
|  Routine Name: help - Help function
|
|       Purpose: Provides help information to user on program parameters
|
|         Input:
|
|        Output:
|
|       Returns: (void)
|
|    Written By: James C. Tilton, NASA's GSFC, Mail Code 606.3, Greenbelt,MD 20771
|        E-Mail: James.C.Tilton@nasa.gov
|
|       Written: April 25, 2019
| Modifications: 
|
------------------------------------------------------------*/
void help()
{
  cout << endl << "The gdalviewer progam can be called in two different manners:" << endl;
  cout << endl << "gdalviewer (where the program parameters are entered via a" << endl;
  cout << "            Graphical User Interface)" << endl;
  cout << "or" << endl;
  cout << "gdalviewer input_image_file_name" << endl;
  cout << endl << "For this help: gdalviewer -h or gdalviewer -help" << endl;
  cout << "For version information: gdalviewer -v or gdalviewer -version" << endl;

  return;
}

