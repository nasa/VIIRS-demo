#ifndef SUM_BANDS_H
#define SUM_BANDS_H

using namespace std;

namespace CommonTilton
{

  bool sum_bands();

} // CommonTilton

#endif // SUM_BANDS_H

