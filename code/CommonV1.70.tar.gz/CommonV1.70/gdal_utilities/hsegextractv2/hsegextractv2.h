/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<<
   >>>>
   >>>>       Purpose: General include file for hsegextractv2
   >>>>
   >>>>    Written By: James C. Tilton, NASA's GSFC, Mail Code 606.3, Greenbelt, MD 20771
   >>>>        E-Mail: James.C.Tilton@nasa.gov
   >>>>
   >>>>       Written: June 21, 2016: Based on hsegextract program from RHSEG/rhsegV1.64
   >>>> Modifications: 
   >>>>
   >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<< */

#ifndef HSEGEXTRACT_H
#define HSEGEXTRACT_H

using namespace std;

namespace CommonTilton
{
    bool hsegextractv2();

} // CommonTilton

#endif /*-- HSEGEXTRACT_H --*/
