/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<<
   >>>>
   >>>>          File:  results.cc
   >>>>
   >>>>          See results.h for documentation
   >>>>          Date:  June 24, 2016 - Based on Results class from RHSEG/rhsegV1.64
   >>>>
   >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<< */

#include "results.h"
#include "../params/params.h"
#include "../region/region_class.h"
#include "../region/region_object.h"
#include <iostream>

using namespace std;

extern CommonTilton::Params params;

namespace CommonTilton
{

 Results::Results()
 {
  nbands = 0;
  orig_nb_classes = 0;
  orig_nb_objects = 0;

  int_buffer_size = 0;
  max_int_buffer_size = 0;
  double_buffer_size = 0;

  int_buffer = NULL;
  double_buffer = NULL;

  object_int_buffer_size = 0;
  object_double_buffer_size = 0;

  return;
 }

 Results::Results(const Results& source)
 {

  nbands = source.nbands;
  orig_nb_classes = source.orig_nb_classes;
  orig_nb_objects = source.orig_nb_objects;

  int_buffer_size = source.int_buffer_size;
  double_buffer_size = source.double_buffer_size;
  object_int_buffer_size = source.object_int_buffer_size;
  object_double_buffer_size = source.object_double_buffer_size;
  max_int_buffer_size = 0; // This mean the buffers aren't allocated

  return;
 }

 Results::~Results()
 {
  if (int_buffer != NULL)
    delete [ ] int_buffer;
  if (double_buffer != NULL) 
    delete [ ] double_buffer;

  return;
 }

 void Results::operator =(const Results& source)
 {
  if (this == &source)
    return;

  nbands = source.nbands;
  orig_nb_classes = source.orig_nb_classes;
  orig_nb_objects = source.orig_nb_objects;

  int_buffer_size = source.int_buffer_size;
  double_buffer_size = source.double_buffer_size;
  object_int_buffer_size = source.object_int_buffer_size;
  object_double_buffer_size = source.object_double_buffer_size;
  max_int_buffer_size = 0; // This mean the buffers aren't allocated

  return;
 }

 void Results::set_buffer_sizes(const int& nb_bands, const int& nb_classes, const int& nb_objects)
 {

  nbands = nb_bands;
  orig_nb_classes = nb_classes;

  int_buffer_size = max_int_buffer_size = 0;
  double_buffer_size = 0;
  if (params.region_sum_flag)
  {
    double_buffer_size += nbands*orig_nb_classes;
    if (params.region_sumsq_flag)
      double_buffer_size += nbands*orig_nb_classes;
    if (params.region_sumxlogx_flag)
      double_buffer_size += nbands*orig_nb_classes;
  }
  if (params.region_std_dev_flag)
    double_buffer_size += orig_nb_classes;
  if (params.region_threshold_flag)
    double_buffer_size += orig_nb_classes;
 
  object_int_buffer_size = 0;
  object_double_buffer_size = 0;
  if (params.region_objects_flag)
  {
    orig_nb_objects = nb_objects;

    if (params.region_nb_objects_flag)
    {
      object_int_buffer_size = 3*orig_nb_objects;
      if (params.region_boundary_npix_flag)
        object_int_buffer_size += orig_nb_objects;
    }

    if (params.region_objects_list_flag)
    {
      if (params.region_sum_flag)
      {
        object_double_buffer_size += nbands*orig_nb_objects;
        if (params.region_sumsq_flag)
          object_double_buffer_size += nbands*orig_nb_objects;
        if (params.region_sumxlogx_flag)
          object_double_buffer_size += nbands*orig_nb_objects;
      }
      if (params.region_std_dev_flag)
        object_double_buffer_size += orig_nb_objects;
    }
  }

  return;
 }

  void Results::open_input(const string& region_classes_file, const string& region_objects_file)
  {
    region_classes_ifs.open(region_classes_file.c_str( ), ios_base::in | ios_base::binary );
 
    if (params.region_objects_flag)
      region_objects_ifs.open(region_objects_file.c_str( ), ios_base::in | ios_base::binary );

    return;
  }

  void Results::read(const int& segLevel, int& nb_classes, int& nb_objects, const int& nb_levels,
                     vector<unsigned int>& int_buffer_size,
                     vector<RegionClass>& region_classes, vector<RegionObject>& region_objects)
  {
    int band, index, region_index, hlevel;
    int offset, nghbrs_label_set_size;
    int fs_pos;

    if (max_int_buffer_size == 0)
    {
      for (hlevel = 0; hlevel < nb_levels; hlevel++)
        if (max_int_buffer_size < (int) int_buffer_size[hlevel])
          max_int_buffer_size = int_buffer_size[hlevel];
      if (max_int_buffer_size < object_int_buffer_size)
        max_int_buffer_size = object_int_buffer_size;
      int_buffer = new int[max_int_buffer_size];

      if (double_buffer_size > object_double_buffer_size)
        double_buffer = new double[double_buffer_size];
      else
        double_buffer = new double[object_double_buffer_size];
    }

    fs_pos = region_classes_ifs.tellg();
    if ((segLevel > 0) && (fs_pos == 0))
    {
      for (hlevel = 0; hlevel < segLevel; hlevel++)
      {
        offset = 0;
        offset += 4*int_buffer_size[hlevel];
        offset += 8*double_buffer_size;
        region_classes_ifs.seekg(offset, ios_base::cur);
      }
    }

    region_classes_ifs.read(reinterpret_cast<char *>(int_buffer),4*int_buffer_size[segLevel]);
    region_classes_ifs.read(reinterpret_cast<char *>(double_buffer),8*double_buffer_size);

    nb_classes = int_buffer_index = double_buffer_index = 0;
    for (region_index = 0; region_index < orig_nb_classes; ++region_index)
    {
      region_classes[region_index].label = int_buffer[int_buffer_index++];

      region_classes[region_index].merge_region_label = int_buffer[int_buffer_index++];

      region_classes[region_index].active_flag = false;
      if (region_classes[region_index].merge_region_label == 0)
      {
        region_classes[region_index].active_flag = true;
        nb_classes++;

        region_classes[region_index].npix = int_buffer[int_buffer_index++];

        if (params.region_sum_flag)
        {
          for (band = 0; band < nbands; band++)
            region_classes[region_index].sum[band] = double_buffer[double_buffer_index++];

          if (params.region_sumsq_flag)
            for (band = 0; band < nbands; band++)
              region_classes[region_index].sumsq[band] = double_buffer[double_buffer_index++];

          if (params.region_sumxlogx_flag)
            for (band = 0; band < nbands; band++)
              region_classes[region_index].sumxlogx[band] = double_buffer[double_buffer_index++];
        }

        if (params.region_std_dev_flag)
          region_classes[region_index].std_dev = double_buffer[double_buffer_index++];

        if (params.region_threshold_flag)
          region_classes[region_index].merge_threshold = double_buffer[double_buffer_index++];

        if (params.region_boundary_npix_flag)
          region_classes[region_index].boundary_npix = int_buffer[int_buffer_index++];

        if (params.region_nghbrs_list_flag) // Always true!
        {
          nghbrs_label_set_size = int_buffer[int_buffer_index++];
          region_classes[region_index].nghbrs_label_set.clear();
          for (index = 0; index < nghbrs_label_set_size; index++)
          {
            region_classes[region_index].nghbrs_label_set.insert(int_buffer[int_buffer_index++]);
          }
        }

        if (params.region_nb_objects_flag)
        {
          region_classes[region_index].nb_region_objects = int_buffer[int_buffer_index++];
        }
      
        if (params.region_objects_list_flag)
        {
          region_classes[region_index].region_objects_set.clear();
          for (index = 0; index < (int) region_classes[region_index].nb_region_objects; index++)
          {
            region_classes[region_index].region_objects_set.insert(int_buffer[int_buffer_index++]);
          }
        }
      } // if (region_classes[region_index].merge_region_label == 0)
    } // for (region_index = 0; region_index < orig_nb_classes; ++region_index)

    nb_objects = object_int_buffer_index = double_buffer_index = 0;
    if (params.region_objects_flag)
    {
      fs_pos = region_objects_ifs.tellg();
      if ((segLevel > 0) && (fs_pos == 0))
      {
        for (hlevel = 0; hlevel < segLevel; hlevel++)
        {
          offset = 0;
          offset += 4*object_int_buffer_size;
          offset += 8*object_double_buffer_size;
          region_objects_ifs.seekg(offset, ios_base::cur);
        }
      }

      region_objects_ifs.read(reinterpret_cast<char *>(int_buffer),4*object_int_buffer_size);
      region_objects_ifs.read(reinterpret_cast<char *>(double_buffer),8*object_double_buffer_size);

      for (region_index = 0; region_index < orig_nb_objects; ++region_index)
      {
        region_objects[region_index].label = int_buffer[object_int_buffer_index++];
        region_objects[region_index].merge_region_label = int_buffer[object_int_buffer_index++];

        region_objects[region_index].active_flag = false;
        if (region_objects[region_index].merge_region_label == 0)
        {
          region_objects[region_index].active_flag = true;
          nb_objects++;
          region_objects[region_index].npix = int_buffer[object_int_buffer_index++];

          if (params.region_sum_flag)
          {
            for (band = 0; band < nbands; band++)
              region_objects[region_index].sum[band] = double_buffer[double_buffer_index++];

            if (params.region_sumsq_flag)
              for (band = 0; band < nbands; band++)
                region_objects[region_index].sumsq[band] = double_buffer[double_buffer_index++];

            if (params.region_sumxlogx_flag)
              for (band = 0; band < nbands; band++)
                region_objects[region_index].sumxlogx[band] = double_buffer[double_buffer_index++];
          }

          if (params.region_std_dev_flag)
            region_objects[region_index].std_dev = double_buffer[double_buffer_index++];

          if (params.region_boundary_npix_flag)
            region_objects[region_index].boundary_npix = int_buffer[object_int_buffer_index++];
        } // if (region_classes[region_index].merge_region_label == 0)
      } // for (region_index = 0; region_index < orig_nb_objects; ++region_index)
    } // if (params.region_objects_flag)

    return;
  }

  void Results::close_input( )
  {
    region_classes_ifs.close( );
    if (params.region_objects_flag)
      region_objects_ifs.close( );
  }

} // namespace CommonTilton
