/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<<
   >>>>
   >>>>       Purpose:  Provides the Spatial class, which is a class dealing
   >>>>                 with spatial data
   >>>>
   >>>>    Written By:  James C. Tilton, MC 606.3, NASA's GSFC, Greenbelt, MD 20771
   >>>>                 E-Mail:  James.C.Tilton@nasa.gov
   >>>>          Date:  June 24, 2016 - Based on Spatial class from RHSEG/rhsegV1.64
   >>>>
   >>>> Modifications:  
   >>>>
   >>>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<< */

#ifndef SPATIAL_H
#define SPATIAL_H

#include <cstring>
#include <fstream>
#include <vector>
#include <set>

using namespace std;

namespace CommonTilton
{

    class RegionClass;
    class RegionObject;

    class Spatial
    {
      public:
          //  CONSTRUCTORS and DESTRUCTOR
          Spatial();
          ~Spatial();
          //  MODIFICATION MEMBER FUNCTIONS
          void read_region_maps( );
          void update_region_maps(const short unsigned int& hseg_level, 
                                  vector<RegionClass>& region_classes, vector<RegionObject>& region_objects);

          //  CONSTANT MEMBER FUNCTIONS
          void write_class_labels_map_ext(const string& class_labels_map_ext_file, vector<RegionClass>& region_classes);
          void write_class_npix_map_ext(const string& class_npix_map_ext_file, vector<RegionClass>& region_classes);
          void write_class_mean_map_ext(const string& class_mean_map_ext_file, vector<RegionClass>& region_classes);
          void write_class_std_dev_map_ext(const string& class_std_dev_map_ext_file, vector<RegionClass>& region_classes);
          void write_class_bpratio_map_ext(const string& class_bpratio_map_ext_file, vector<RegionClass>& region_classes);
          void write_object_labels_map_ext(const string& object_labels_map_ext_file, vector<RegionObject>& region_objects);
          void write_object_npix_map_ext(const string& object_npix_map_ext_file, vector<RegionObject>& region_objects);
          void write_object_mean_map_ext(const string& object_mean_map_ext_file, vector<RegionObject>& region_objects);
          void write_object_std_dev_map_ext(const string& object_std_dev_map_ext_file, vector<RegionObject>& region_objects);
          void write_object_bpratio_map_ext(const string& object_bpratio_map_ext_file, vector<RegionObject>& region_objects);
  
    // FRIEND FUNCTIONS and CLASSES
          friend class RegionClass;
          friend class RegionObject;

      private:
          //  PRIVATE DATA
          unsigned int  *region_class_label_map;  // Array of region class label map values.
          unsigned int  *region_object_label_map; // Array of region object label map values.
          fstream  region_class_label_map_fs;     // Output region class label map file stream.
          fstream  region_object_label_map_fs;    // Output region object label map file stream.
    };

// Related functions

} // CommonTilton

#endif /* SPATIAL_H */
