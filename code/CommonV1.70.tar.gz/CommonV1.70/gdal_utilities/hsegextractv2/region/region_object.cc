/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<<
   >>>>
   >>>>          File:  region_object.cc
   >>>>
   >>>>          See region_object.h for documentation
   >>>>          Date:  June 24, 2016
   >>>>
   >>>> Modifications:  
   >>>>
   >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<< */

#include "region_object.h"
#include "region_class.h"
#include "../params/params.h"
#include "../spatial/spatial.h"
#include <iostream>
#include <float.h>
#include <cmath>

extern CommonTilton::Params params;
extern CommonTilton::oParams oparams;

namespace CommonTilton
{

 bool RegionObject::sumsq_flag;
 bool RegionObject::sumxlogx_flag;
 bool RegionObject::region_class_nghbrs_list_flag;
 bool RegionObject::region_object_nghbrs_list_flag;
 int  RegionObject::nbands;
 double *RegionObject::scale;
 double *RegionObject::offset;

 RegionObject::RegionObject( )
 {
  int band;

// Initialize member variables
  active_flag = false;
  label = 0;
  npix = 0;
  sum = new double[nbands];
  for (band = 0; band < nbands; band++)
    sum[band] = 0.0;
  sumsq = NULL;
  if (sumsq_flag)
  {
    sumsq = new double[nbands];
    for (band = 0; band < nbands; band++)
      sumsq[band] = 0.0;
  }
  sumxlogx = NULL;
  if (sumxlogx_flag)
  {
    sumxlogx = new double[nbands];
    for (band = 0; band < nbands; band++)
      sumxlogx[band] = 0.0;
  }
  std_dev = 0.0;
  class_nghbrs_set.clear( );
  object_nghbrs_set.clear( );
  merge_region_label = 0;
  min_region_dissim = FLT_MAX;
  boundary_npix = 0;

  return;
 }

 RegionObject::RegionObject(const RegionObject& source)
 {
  int band;

// Copy member variables
  active_flag = source.active_flag;
  label = source.label;
  npix = source.npix;
  sum = new double[nbands];
  for (band = 0; band < nbands; band++)
    sum[band] = source.sum[band];
  if (sumsq_flag)
  {
    sumsq = new double[nbands];
    for (band = 0; band < nbands; band++)
      sumsq[band] = source.sumsq[band];
  }
  if (sumxlogx_flag)
  {
    sumxlogx = new double[nbands];
    for (band = 0; band < nbands; band++)
      sumxlogx[band] = source.sumxlogx[band];
  }
  std_dev = source.std_dev;

  class_nghbrs_set_copy(source);
  object_nghbrs_set_copy(source);
  merge_region_label = source.merge_region_label;
  min_region_dissim = source.min_region_dissim;
  boundary_npix = source.boundary_npix;

  return;
 }

 RegionObject::~RegionObject( )
 {
  delete [ ] sum;
  if (sumsq_flag)
    delete [ ] sumsq;
  if (sumxlogx_flag)
    delete [ ] sumxlogx;
  return;
 }

 void RegionObject::set_static_vals()
 {
  int band;

  sumsq_flag = params.region_sumsq_flag;
  sumxlogx_flag = params.region_sumxlogx_flag;
  nbands = params.nbands;
  scale = new double[nbands];
  offset = new double[nbands];

 // Coarsen to float to maintain consistency of results between different computing platforms and operating systems.
  for (band = 0; band < nbands; band++)
  {
    scale[band] = (float) (oparams.scale[band]*params.scale[band]);
    offset[band] = (float) (params.offset[band] + (oparams.offset[band]/params.scale[band]));
  }
  return;
 }

 void RegionObject::set_static_vals(const bool& classes_flag, const bool& objects_flag)
 {
  int band;

  sumsq_flag = params.region_sumsq_flag;
  sumxlogx_flag = params.region_sumxlogx_flag;
  region_class_nghbrs_list_flag = classes_flag;
  region_object_nghbrs_list_flag = objects_flag;
  nbands = params.nbands;
  scale = new double[nbands];
  offset = new double[nbands];
  for (band = 0; band < nbands; band++)
  {
    scale[band] = oparams.scale[band];
    offset[band] = oparams.offset[band];
  }
  return;
 }

 void RegionObject::operator =(const RegionObject& source)
 {
  int band;

  if (this == &source)
    return;

// Copy member variables
  active_flag = source.active_flag;
  label = source.label;
  npix = source.npix;
  for (band = 0; band < nbands; band++)
    sum[band] = source.sum[band];
  if (sumsq_flag)
  {
    for (band = 0; band < nbands; band++)
      sumsq[band] = source.sumsq[band];
  }
  if (sumxlogx_flag)
  {
    for (band = 0; band < nbands; band++)
      sumxlogx[band] = source.sumxlogx[band];
  }
  std_dev = source.std_dev;

  class_nghbrs_set_copy(source);
  object_nghbrs_set_copy(source);
  merge_region_label = source.merge_region_label;
  min_region_dissim = source.min_region_dissim;
  boundary_npix = source.boundary_npix;

  return;
 }

 void RegionObject::operator +=(const RegionObject& source)
 {
  int band;

// Update member variables
  npix += source.npix;
  for (band = 0; band < nbands; band++)
    sum[band] += source.sum[band];
  if (sumsq_flag)
  {
    for (band = 0; band < nbands; band++)
      sumsq[band] += source.sumsq[band];
  }
  if (sumxlogx_flag)
  {
    for (band = 0; band < nbands; band++)
      sumxlogx[band] += source.sumxlogx[band];
  }

// These values returned to original default values - must be updated by other means
  class_nghbrs_set.clear( );
  object_nghbrs_set.clear( );
  merge_region_label = 0;
  std_dev = 0.0;
  min_region_dissim = FLT_MAX;
  boundary_npix = 0;

 }

 void RegionObject::clear( )
 {
      int band;

      active_flag = false;
// Clear everything EXCEPT label and merge_region_label!!!
      npix = 0;
      for (band = 0; band < nbands; band++)
        sum[band] = 0.0;
      if (sumsq_flag)
      {
        for (band = 0; band < nbands; band++)
          sumsq[band] = 0.0;
      }
      if (sumxlogx_flag)
      {
        for (band = 0; band < nbands; band++)
          sumxlogx[band] = 0.0;
      }
      std_dev = 0.0;

      class_nghbrs_set.clear( );
      object_nghbrs_set.clear( );
      min_region_dissim = FLT_MAX;
      boundary_npix = 0;

      return;
 }

 void RegionObject::clear_region_object_info( )
 {
      boundary_npix = 0;
      min_region_dissim = FLT_MAX;

      return;
 }

 void RegionObject::calc_std_dev( )
 {
 // Postcondition: If npix <= 1, std_dev is set to 0.0.  If npix > 1,
 // std_dev is the region standard deviation.

  std_dev = 0.0;
  if (npix <= 1)
    return;

  int band;
  float  sumf, sumsqf, tempf;
  double tempd;
  double numpix = (double) npix;

  for (band = 0; band < nbands; band++)
  {
/*  The original code for at this point was:
    tempd = (sumsq[band] - ((sum[band]*sum[band])/numpix))/(numpix-1.0);
    However, minor differences in the value of sumsq due to different
    order of summation performed by instances of the program run with
    different number of processors was magnified by this form of the
    equation.  The following four lines of code reduce or eliminate
    this magnification of differences of value of sumsq - even though
    the calculations are performed in single rather than double precision!!
*/
    sumf = (float) ((sum[band]*sum[band])/numpix);
    sumsqf = (float) sumsq[band];
    tempf = sumsqf - sumf;
    tempd = tempf/(numpix-1.0);
    if (tempd > 0.0)
      tempd = sqrt(tempd);
    else
      tempd = 0.0;
    std_dev += tempd/oparams.scale[band];
  }
  std_dev /= (double) nbands;

  return;
 }

 void RegionObject::class_nghbrs_set_copy(const RegionObject& source)
 {
    class_nghbrs_set.clear( );
    if (!source.class_nghbrs_set.empty( ))
    {
      set<unsigned int>::const_iterator class_nghbrs_iter = source.class_nghbrs_set.begin( );
      while (class_nghbrs_iter != source.class_nghbrs_set.end( ))
      {
        class_nghbrs_set.insert(*class_nghbrs_iter);
        ++class_nghbrs_iter;
      }
    }
    return;
 }

 void RegionObject::object_nghbrs_set_copy(const RegionObject& source)
 {
    object_nghbrs_set.clear( );
    if (!source.object_nghbrs_set.empty( ))
    {
      set<unsigned int>::const_iterator object_nghbrs_iter = source.object_nghbrs_set.begin( );
      while (object_nghbrs_iter != source.object_nghbrs_set.end( ))
      {
        object_nghbrs_set.insert(*object_nghbrs_iter);
        ++object_nghbrs_iter;
      }
    }
    return;
 }

 double RegionObject::get_unscaled_mean(int band) const
 {
   return (((sum[band]/npix)/oparams.scale[band])+oparams.offset[band]);
 }

 double RegionObject::get_unscaled_std_dev(int band) const
 {
   return (get_std_dev(band)/oparams.scale[band]);
 }

 double RegionObject::get_std_dev(int band) const
 {
   double stdDev = 0.0;

   if (npix <= 1)
     return stdDev;

   double numpix = (double) npix;

   stdDev = (sumsq[band] - ((sum[band]*sum[band])/numpix))/(numpix-1.0);
   if (stdDev > 0.0)
     stdDev = sqrt(stdDev);
   else
     stdDev = 0.0;

   return (stdDev/oparams.scale[band]);
 }

} // namespace CommonTilton
