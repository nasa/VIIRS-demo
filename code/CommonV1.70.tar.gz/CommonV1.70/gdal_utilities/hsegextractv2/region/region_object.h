/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<<
   >>>>
   >>>>       Purpose:  Provides the RegionObject class, which is a class dealing
   >>>>                 with region object data
   >>>>
   >>>>    Written By:  James C. Tilton, MC 606.3, NASA's GSFC, Greenbelt, MD 20771
   >>>>                 e-mail:  James.C.Tilton@nasa.gov
   >>>>          Date:  June 24, 2016 - Based on RegionObject class from RHSEG/rhsegV1.64
   >>>>
   >>>> Modifications:  
   >>>>
   >>>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<< */

#ifndef REGIONOBJECT_H
#define REGIONOBJECT_H

#include <string>
#include <vector>
#include <set>
#include <map>
#include <float.h>

using namespace std;

namespace CommonTilton
{

  class RegionClass;
  class Spatial;

  class RegionObject
  {
    public:
      //  CONSTRUCTORS and DESTRUCTOR
      RegionObject();
      RegionObject(const RegionObject& source);
      ~RegionObject();
      //  MODIFICATION MEMBER FUNCTIONS
      static void set_static_vals();
      static void set_static_vals(const bool& classes_flag, const bool& objects_flag);
      void operator =(const RegionObject& source);
      void operator +=(const RegionObject& source);
      void clear();
      void clear_region_object_info();
      void set_active_flag(const bool& value)
           { active_flag = value; }
      void set_label(const unsigned int& value)
           { label = value; }
      void set_label_active(const unsigned int& value)
           { label = value; active_flag = true; }
      void set_npix(const unsigned int& value)
           { npix = value; }
      void set_sum(const int& index, const float& value)
           { sum[index] = value; }
      void set_std_dev(const float& value)
           { std_dev = value; }
      void set_boundary_npix(const unsigned int& value)
           { boundary_npix = value; }
      void set_merge_region_label(const unsigned int& value)
           { merge_region_label = value; }
      void increment_boundary_npix()
           { boundary_npix++ ; }
      void calc_std_dev();
      void merge_regions(RegionObject *merge_region, vector<RegionObject>& region_objects);
      void class_nghbrs_set_copy(const RegionObject& source);
      void object_nghbrs_set_copy(const RegionObject& source);
      void class_nghbrs_set_clear()
           { class_nghbrs_set.clear(); }
      void object_nghbrs_set_clear()
           { object_nghbrs_set.clear(); }

      //  CONSTANT MEMBER FUNCTIONS
      bool get_active_flag() const { return active_flag; }
      unsigned int get_label() const { return label; }
      unsigned int get_npix() const { return npix; }
      double get_sum(int index) const { return sum[index]; }
      double get_unscaled_mean(int band) const;
      double get_unscaled_std_dev(int band) const;
      double get_std_dev() const { return std_dev; }
      double get_std_dev(int band) const;
      unsigned int get_merge_region_label() const
                   { return merge_region_label; }
      unsigned int get_boundary_npix( ) const { return boundary_npix; }

      // FRIEND FUNCTIONS and CLASSES
      friend class Results;
      friend class Spatial;
      friend class RegionClass;

    private:
      //  PRIVATE DATA
      bool               active_flag;        // true if active, false if not-active or merged into another region
      unsigned int       label;              // Label of this connected region
      unsigned int       npix;               // Number of pixels in this connected region
      double             *sum;               // Sum of image values (in each band)
      double             *sumsq;             // Sum of squares of image values (in each band)
      double             *sumxlogx;          // Sum of xlogx of image values x (in each band)
      double             std_dev;            // Region band average standard deviation feature value
      set<unsigned int>  class_nghbrs_set;   // Set of labels of the neighboring region classes for this region object
      set<unsigned int>  object_nghbrs_set;  // Set of labels of the neighboring region objects for this region object
      unsigned int       merge_region_label; // Label of region into which this region was merged (= 0 if not merged)
      double             min_region_dissim;  // Dissimilarity of region to minimum vector
      unsigned int       boundary_npix;      // Number of boundary pixels in the region.
      //  PRIVATE STATIC DATA
      static bool    sumsq_flag;        // true iff the sumsq feature is to be calculated.
      static bool    sumxlogx_flag;     // true iff the sumxlogx feature is to be calculated.
      static bool    region_class_nghbrs_list_flag; // Used in rhseg_read
      static bool    region_object_nghbrs_list_flag; // Used in rhseg_read
      static int     nbands;            // Number of spectral bands in the input image data.
      static double  *scale, *offset;   // Scale and offset values used in input image data scaling and normalization
  } ;

  // Other related functions

} // CommonTilton

#endif /* REGIONOBJECT_H */
