/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<<
   >>>>
   >>>>       Purpose:  Provides the RegionClass class, which is a class dealing
   >>>>                 with region data
   >>>>
   >>>>    Written By:  James C. Tilton, MC 606.3, NASA's GSFC, Greenbelt, MD 20771
   >>>>                 e-mail:  James.C.Tilton@nasa.gov
   >>>>          Date:  June 24, 2016 - Based on RegionClass class from RHSEG/rhsegV1.64
   >>>>
   >>>> Modifications:  
   >>>>
   >>>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<< */

#ifndef REGIONCLASS_H
#define REGIONCLASS_H

#include <float.h>
#include <string>
#include <vector>
#include <set>
#include <map>

using namespace std;

namespace CommonTilton
{

  class RegionObject;
  class Spatial;

  class RegionClass
  {
    public:
      //  CONSTRUCTORS and DESTRUCTOR
      RegionClass();
      RegionClass(const RegionClass& source);
      ~RegionClass();
      //  MODIFICATION MEMBER FUNCTIONS
      static void set_static_vals();
      void operator =(const RegionClass& source);
      void operator =(const RegionObject& source);
      void operator +=(const RegionClass& source);
      void operator -=(const RegionClass& source);
      void clear();
      void partial_clear();
      void nghbrs_label_set_clear()
           { nghbrs_label_set.clear(); }
      void clear_region_info();
      void nghbrs_label_set_copy(const RegionClass& source);
      void nghbrs_label_set_copy(const RegionObject& source);
      void region_objects_set_copy(const RegionClass& source);
      void set_active_flag(const bool& value)
           { active_flag = value; }
      void set_label(const unsigned int& value)
           { label = value; }
      void calc_std_dev();

      //  CONSTANT MEMBER FUNCTIONS
      bool get_active_flag() const { return active_flag; }
      double get_scale(int index) const { return scale[index]; }
      double get_offset(int index) const { return offset[index]; }
      unsigned int get_label() const { return label; }
      unsigned int get_npix() const { return npix; }
      double get_sum(int index) const { return sum[index]; }
      double get_sumsq(int index) const { return sumsq[index]; }
      double get_sumxlogx(int index) const { return sumxlogx[index]; }
      double get_std_dev() const { return std_dev; }
      double get_sum_pixel_gdissim() const { return sum_pixel_gdissim; }
      double get_min_region_dissim() const { return min_region_dissim; }
      unsigned int get_merge_region_label() const { return merge_region_label; }
      int get_region_objects_set_size() const { return region_objects_set.size(); }
      int get_nb_region_objects () const { return nb_region_objects; }
      int get_nghbrs_label_set_size() const { return nghbrs_label_set.size(); }
      unsigned int get_boundary_npix( ) const { return boundary_npix; }
      double get_merge_threshold( ) const { return merge_threshold; }
      set<unsigned int>::iterator get_region_objects_set_begin() const
                                  { return region_objects_set.begin(); }
      set<unsigned int>::iterator get_region_objects_set_end() const
                                  { return region_objects_set.end(); }
      unsigned int get_best_nghbr_label(vector<RegionClass>& region_classes);
      unsigned int get_best_region_label(vector<RegionClass>& region_classes);
      double get_unscaled_mean(int band) const;
      double get_unscaled_std_dev(int band) const;
      double get_std_dev(int band) const;
      float get_max_edge_value() const { return max_edge_value; }
      // FRIEND FUNCTIONS and CLASSES
      friend RegionClass operator -(const RegionClass& arg1, const RegionClass& arg2);
      friend class Results;
//      friend class RegionObject;
    private:
      //  PRIVATE DATA
      bool               active_flag;  // true if active, false if not-active or merged into another region
      unsigned int       label;        // RegionClass label
      unsigned int       npix;         // Number of pixels in the region
      double             *sum;         // Sum of image values (in each band)
      double             *sumsq;       // Sum of squares of image values (in each band)
      double             *sumxlogx;    // Sum of xlogx of image values x (in each band)
      double             std_dev;      // Region band average standard deviation feature value
      float              max_edge_value;     // Maximum edge value in region
      set<unsigned int>  nghbrs_label_set;   // Set of labels of the neighbors of this region
      unsigned int       merge_region_label; // RegionClass label of region into which this region was merged (=0 if not merged)
      double             sum_pixel_gdissim;  // Sum of the dissimilarity values across all region pixels
      double             min_region_dissim;  // Dissimilarity of region to minimum vector
      unsigned int       nb_region_objects;    // Number of region objects contained in this region class.
      set<unsigned int>  region_objects_set;   // Set of labels of spatially connected subregions contained in this region
      unsigned int       boundary_npix;      // Number of boundary pixels in the region.
      double             merge_threshold;    // Merge threshold for most recent merge involving this region.
      //  PRIVATE STATIC DATA
      static bool    sumsq_flag;        // true iff the sumsq feature is to be calculated.
      static bool    sumxlogx_flag;     // true iff the sumxlogx feature is to be calculated.
      static int     nbands;            // Number of spectral bands in the input image data.
      static double  *scale, *offset;   // Scale and offset values used in input image data scaling and normalization
  };

  // Related functions
} // CommonTilton

#endif /* REGIONCLASS_H */
