#ifndef EDGE_H
#define EDGE_H

using namespace std;

namespace CommonTilton
{

  bool edge();
  bool edge(int &ncols, int &nrows, float *input_image, unsigned char *mask_data, unsigned char &mask_fill_value,
            float *edge_values, unsigned char *edge_mask);
  double prewitt(const double window[3][3]);
  double sobel(const double window[3][3]);
  double scharr(const double window[3][3]);
  double frei_chen(const double window[3][3], const short int& option);
  double std_dev(const double window[3][3]);
  void scale_offset(const int& new_min, const int& new_max, int &ncols, int &nrows, 
                    float *input_image, unsigned char *mask_data, unsigned char &mask_fill_value);

} // CommonTilton

#endif // EDGE_H

