// edge.cc

#include "edge.h"
#include "params/params.h"
#include <gdal_priv.h>
#include <iostream>
#include <float.h>

// Externals
extern CommonTilton::Params params;

namespace CommonTilton
{
  bool edge()
  {
    int col, row, band, index, has_fill = false;
    int ncols, nrows, nbands, mask_nbands = 0;
    double fill_value = 0.0;
    GDALDataset *inDataset, *maskDataset, *outDataset, *outmaskDataset;
    GDALDriver *driver;
    GDALRasterBand *rb, *mrb, *wb, *mwb;

  // Check input image
    inDataset = (GDALDataset *)GDALOpen(params.input_image_file.c_str(), GA_ReadOnly);
    if (!inDataset)
    {
      cout << "Could not open input_image file name = " << params.input_image_file << endl;
      return false;
    }
    ncols = inDataset->GetRasterXSize();
    nrows = inDataset->GetRasterYSize();
    nbands = inDataset->GetRasterCount();
    driver = inDataset->GetDriver();
    cout << "Performing Edge Analysis on input image " << params.input_image_file << endl;
    cout << "with ncols = " << ncols << ", nrows = " << nrows << " and nbands = " << nbands << endl;

  // Handle masking
    unsigned char *mask = new unsigned char[ncols*nrows];
    int mask_has_fill = false;
    unsigned char mask_fill_value = params.mask_value;
    if (params.mask_flag)
    {
      maskDataset = (GDALDataset *)GDALOpen(params.mask_file.c_str(), GA_ReadOnly);
      if (!maskDataset)
      {
        cout << "ERROR: Could not open mask file name = " << params.mask_file << endl;
        return false;
      }
      if ((maskDataset->GetRasterXSize() != ncols) ||
          (maskDataset->GetRasterYSize() != nrows))
      {
        cout << "ERROR: mask image " << params.mask_file << " does not match input_image in size." << endl;
        return false;
      }
      mask_nbands = maskDataset->GetRasterCount();
      if ((mask_nbands > 1) && (mask_nbands != nbands))
      {
        cout << "ERROR: multispectral mask image " << params.mask_file << " does not match input_image number of bands." << endl;
        return false;
      }
      mrb = maskDataset->GetRasterBand(1);
      mask_has_fill = false;
      mask_fill_value = mrb->GetNoDataValue(&mask_has_fill);
      if (!mask_has_fill)
        mask_fill_value = params.mask_value;
    }
    else
    {
      maskDataset = NULL;
      rb = inDataset->GetRasterBand(1);
      has_fill = false;
      fill_value = rb->GetNoDataValue(&has_fill);
      if (has_fill)
        mask_nbands = nbands;
      else
        mask_nbands = 0;
    }
    bool one_mask_band = ((params.mask_flag) && (mask_nbands == 1));
    if (one_mask_band)
    {
      mrb = maskDataset->GetRasterBand(1);
      if (mrb->RasterIO(GF_Read, 0, 0, ncols, nrows, &mask[0], ncols, nrows, GDT_Byte, 0, 0)
          == CE_Failure)
      {
        cout << "ERROR: Could not read mask data" << endl;
        return false;
      }
    }
    else
    {
      for (row = 0; row < nrows; row++)
        for (col = 0; col < ncols; col++)
        {
          index = col + row*ncols;
          mask[index] = mask_fill_value + 1;
        }
     // Takes care of case of no masking
      if (mask_nbands == 0)
      {
        mask_nbands = 1;
        one_mask_band = true;
      }
    }

   // Create output edge image and output edge mask
    int out_nbands = 1;
    char **papszOptions = NULL;
    if (params.output_type == 1)
      out_nbands = nbands;
    outDataset = driver->Create(params.output_image_file.c_str(), ncols, nrows, out_nbands, GDT_Float32, papszOptions);
    outmaskDataset = driver->Create(params.output_mask_image_file.c_str(), ncols, nrows, out_nbands, GDT_Byte, papszOptions);
    const char *pszProj = inDataset->GetProjectionRef();
    if ((pszProj != NULL) && (strlen(pszProj) > 0))
    {
      outDataset->SetProjection(pszProj);
      outmaskDataset->SetProjection(pszProj);
    }
    double imageGeoTransform[6];
    if ( inDataset->GetGeoTransform( imageGeoTransform ) == CE_None )
    {
      outDataset->SetGeoTransform( imageGeoTransform);
      outmaskDataset->SetGeoTransform( imageGeoTransform);
    }
    const char *pszGCPProj = inDataset->GetGCPProjection();
    if ((pszGCPProj != NULL) && (strlen(pszGCPProj) > 0))
    {
      int nGCPs = inDataset->GetGCPCount();
      const GDAL_GCP *psGCP;
      psGCP = inDataset->GetGCPs();
      if (nGCPs > 0)
      {
        outDataset->SetGCPs(nGCPs,psGCP,pszGCPProj);
        outmaskDataset->SetGCPs(nGCPs,psGCP,pszGCPProj);
      }
    }

    float *input_image = new float[ncols*nrows];
    float *out_image, *temp_out_image = NULL;
    out_image = new float[ncols*nrows];
    unsigned char *out_mask_image, *temp_out_mask_image = NULL;
    out_mask_image = new unsigned char[ncols*nrows];
    unsigned char out_mask_fill_value = 0;
    float new_max = 1.0;
    float new_min = 0.0;
    if (params.output_type != 1)
    {
      temp_out_image = new float[ncols*nrows];
      temp_out_mask_image = new unsigned char[ncols*nrows];
      for (row = 0; row < nrows; row++)
        for (col = 0; col < ncols; col++)
        {
          index = col + row*ncols;
          out_image[index] = 0.0;
          if (params.output_type == 3)
            out_image[index] = -FLT_MAX;
          if (params.output_type == 4)
            out_image[index] = FLT_MAX;
          out_mask_image[index] = 1;
        }
    }
    for (band = 0; band < nbands; band++)
    {
      rb = inDataset->GetRasterBand((band+1));
      if (rb->RasterIO(GF_Read, 0, 0, ncols, nrows, &input_image[0], ncols, nrows, GDT_Float32, 0, 0)
          == CE_Failure)
      {
        cout << "ERROR: Could not read input_image data" << endl;
        return false;
      }

      if (!one_mask_band)
      {
        if (params.mask_flag)
        {
          mrb = maskDataset->GetRasterBand((band+1));
          if (mrb->RasterIO(GF_Read, 0, 0, ncols, nrows, &mask[0], ncols, nrows, GDT_Byte, 0, 0)
              == CE_Failure)
          {
            cout << "ERROR: Could not read mask data" << endl;
            return false;
          }
        }
        else
        {
          for (row = 0; row < nrows; row++)
            for (col = 0; col < ncols; col++)
            {
              index = col + row*ncols;
              if (input_image[index] == fill_value)
                mask[index] = mask_fill_value;
              else
                mask[index] = mask_fill_value + 1;
            }
        }
      }
      if (params.bias_value != 0.0)
      {
        for (row = 0; row < nrows; row++)
          for (col = 0; col < ncols; col++)
          {
            index = col + row*ncols;
            if (mask[index] != mask_fill_value)
              input_image[index] += params.bias_value;
          }
      }
      if (params.output_type == 1)
      {
        edge(ncols,nrows,input_image,mask,mask_fill_value,out_image,out_mask_image);
        if (params.scale_output_flag)
          scale_offset(new_min, new_max, ncols,nrows,out_image,out_mask_image,out_mask_fill_value);
        if (params.edge_threshold > 0.0)
        {
          for (row = 0; row < nrows; row++)
            for (col = 0; col < ncols; col++)
            {
              index = col + row*ncols;
              if (out_image[index] <= params.edge_threshold)
                out_image[index] = 0.0;
            }
        }
        wb = outDataset->GetRasterBand((band+1));
        if (wb->RasterIO(GF_Write, 0, 0, ncols, nrows, out_image, ncols, nrows, GDT_Float32, 0, 0)
            == CE_Failure)
        {
          cout << "ERROR: Could not write output image data" << endl;
          return false;
        }

        mwb = outmaskDataset->GetRasterBand((band+1));
        if (mwb->RasterIO(GF_Write, 0, 0, ncols, nrows, out_mask_image, ncols, nrows, GDT_Byte, 0, 0)
            == CE_Failure)
        {
          cout << "ERROR: Could not write output mask data" << endl;
          return false;
        }

      }
      else
      {
        edge(ncols,nrows,input_image,mask,mask_fill_value,temp_out_image,temp_out_mask_image);
        for (row = 0; row < nrows; row++)
          for (col = 0; col < ncols; col++)
          {
            index = col + row*ncols;
            if (params.output_type == 2)
              out_image[index] += temp_out_image[index];
            if (params.output_type == 3)
              if (temp_out_image[index] > out_image[index])
                out_image[index] = temp_out_image[index];
            if (params.output_type == 4)
              if (temp_out_image[index] < out_image[index])
                out_image[index] = temp_out_image[index];
            if (temp_out_mask_image[index] == 0)
              out_mask_image[index] = 0;
          }
      }
    }
    if (params.output_type != 1)
    {
      if (params.output_type == 2)
      {

        for (row = 0; row < nrows; row++)
          for (col = 0; col < ncols; col++)
          {
            index = col + row*ncols;
            out_image[index] /= nbands;
          }
      }
      if (params.edge_threshold > 0.0)
      {
        for (row = 0; row < nrows; row++)
          for (col = 0; col < ncols; col++)
          {
            index = col + row*ncols;
            if (out_image[index] <= params.edge_threshold)
              out_image[index] = 0.0;
          }
      }
      wb = outDataset->GetRasterBand((1));
      if (wb->RasterIO(GF_Write, 0, 0, ncols, nrows, out_image, ncols, nrows, GDT_Float32, 0, 0)
          == CE_Failure)
      {
        cout << "ERROR: Could not write output image data" << endl;
        return false;
      }

      mwb = outmaskDataset->GetRasterBand((1));
      if (mwb->RasterIO(GF_Write, 0, 0, ncols, nrows, out_mask_image, ncols, nrows, GDT_Byte, 0, 0)
          == CE_Failure)
      {
        cout << "ERROR: Could not write output mask data" << endl;
        return false;
      }

    }

    GDALClose( (GDALDatasetH) inDataset);
    if (params.mask_flag)
      GDALClose( (GDALDatasetH) maskDataset);
    GDALClose( (GDALDatasetH) outDataset);
    GDALClose( (GDALDatasetH) outmaskDataset);

    return true;
  }

  bool edge(int &ncols, int &nrows, float *input_image, unsigned char *mask_data, unsigned char &mask_fill_value,
            float *edge_values, unsigned char *edge_mask)
  {
    bool data_valid_flag;
    int col, row, index;
    double window[3][3];
    float edge_value;

    for (row = 0; row < nrows; row++)
    {
      for (col = 0; col < ncols; col++)
      {
        data_valid_flag = true;
        if ((col == 0) || (row == 0) || (col == (ncols-1)) || (row == (nrows-1)))
          data_valid_flag = false;
        if (data_valid_flag)
        {
          index = (col-1) + (row-1)*ncols;
          data_valid_flag = data_valid_flag && (mask_data[index] != mask_fill_value);
          index = col + (row-1)*ncols;
          data_valid_flag = data_valid_flag && (mask_data[index] != mask_fill_value);
          index = (col+1) + (row-1)*ncols;
          data_valid_flag = data_valid_flag && (mask_data[index] != mask_fill_value);
          index = (col-1) + row*ncols;
          data_valid_flag = data_valid_flag && (mask_data[index] != mask_fill_value);
          index = col + row*ncols;
          data_valid_flag = data_valid_flag && (mask_data[index] != mask_fill_value);
          index = (col+1) + row*ncols;
          data_valid_flag = data_valid_flag && (mask_data[index] != mask_fill_value);
          index = (col-1) + (row+1)*ncols;
          data_valid_flag = data_valid_flag && (mask_data[index] != mask_fill_value);
          index = col + (row+1)*ncols;
          data_valid_flag = data_valid_flag && (mask_data[index] != mask_fill_value);
          index = (col+1) + (row+1)*ncols;
          data_valid_flag = data_valid_flag && (mask_data[index] != mask_fill_value);
        }

        edge_value = 0.0;
        if (data_valid_flag)
        {
          index = (col-1) + (row-1)*ncols;
          window[0][0] = input_image[index];
          index = col + (row-1)*ncols;
          window[1][0] = input_image[index];
          index = (col+1) + (row-1)*ncols;
          window[2][0] = input_image[index];
          index = (col-1) + row*ncols;
          window[0][1] = input_image[index];
          index = col + row*ncols;
          window[1][1] = input_image[index];
          index = (col+1) + row*ncols;
          window[2][1] = input_image[index];
          index = (col-1) + (row+1)*ncols;
          window[0][2] = input_image[index];
          index = col + (row+1)*ncols;
          window[1][2] = input_image[index];
          index = (col+1) + (row+1)*ncols;
          window[2][2] = input_image[index];

          switch (params.edge_operation)
          {
            case Prewitt:   edge_value = (float) prewitt(window);
                            break;
            case Sobel:     edge_value = (float) sobel(window);
                            break;
            case Scharr:    edge_value = (float) scharr(window);
                            break;
            case Frei_Chen: edge_value = (float) frei_chen(window,params.fc_option);
                            break;
            default:        edge_value = 0.0;
                            break;
          }
        } // if (data_valid_flag)
        index = col + row*ncols;
        edge_values[index] = edge_value;
        edge_mask[index] = 0;
        if (data_valid_flag)
          edge_mask[index] = 1;
      } // for (col = 1; col < (ncols-1); col++)
    } // for (row = 0; row < nrows; row++)

    return true;
  }

  double prewitt(const double window[3][3])
  {
    double gx, gy;
    double edge_value;

    gx = window[2][0] - window[0][0];
    gx += window[2][1] - window[0][1];
    gx += window[2][2] - window[0][2];
    gy = window[0][0] + window[1][0] + window[2][0];
    gy -= window[0][2] + window[1][2] + window[2][2];

    edge_value = sqrt(gx*gx + gy*gy);

    return edge_value;
  }

  double sobel(const double window[3][3])
  {
    double gx, gy;
    double edge_value;

    gx = window[2][0] - window[0][0];
    gx += 2*(window[2][1] - window[0][1]);
    gx += window[2][2] - window[0][2];
    gy = window[0][0] + 2*window[1][0] + window[2][0];
    gy -= window[0][2] + 2*window[1][2] + window[2][2];

    edge_value = sqrt(gx*gx + gy*gy);

    return edge_value;
  }

  double scharr(const double window[3][3])
  {
    double gx, gy;
    double edge_value;

    gx = 3*(window[2][0] - window[0][0]);
    gx += 10*(window[2][1] - window[0][1]);
    gx += 3*(window[2][2] - window[0][2]);
    gy = 3*window[0][2] + 10*window[1][2] + 3*window[2][2];
    gy -= 3*window[0][0] + 10*window[1][0] + 3*window[2][0];

    edge_value = sqrt(gx*gx + gy*gy);

    return edge_value;
  }

  double frei_chen(const double window[3][3], const short int& option)
  {
    double g1, g2, g3, g4, g5, g6, g7, g8, g9, M, S, edge_value;
    double sqrt2 = sqrt(2.0);

    g1 = window[0][0] + sqrt2*window[1][0] + window[2][0];
    g1 -= window[0][2] + sqrt2*window[1][2] + window[2][2];
    g1 /= 2*sqrt2;
    g2 = window[0][0] - window[2][0];
    g2 += sqrt2*(window[0][1] - window[2][1]);
    g2 += window[0][2] - window[2][2];
    g2 /= 2*sqrt2;
    g3 = sqrt2*window[2][0] - window[1][0];
    g3 += window[0][1] - window[2][1];
    g3 += window[1][2] - sqrt2*window[0][2];
    g3 /= 2*sqrt2;
    g4 = sqrt2*window[0][0] - window[1][0];
    g4 += window[2][1] - window[0][1];
    g4 += window[1][2] - sqrt2*window[2][2];
    g4 /= 2*sqrt2;
    g5 = window[1][0];
    g5 -= window[0][1] + window[2][1];
    g5 += window[1][2];
    g5 /= 2;
    g6 = window[2][0] - window[0][0];
    g6 += window[0][2] - window[2][2];
    g6 /= 2;
    g7 = window[0][0] - 2*window[1][0] + window[2][0];
    g7 -= 2*window[0][1] - 4*window[1][1] + 2*window[2][1];
    g7 += window[0][2] - 2*window[1][2] + window[2][2];
    g7 /= 6;
    g8 = window[0][1] + 4*window[1][1] + window[2][1];
    g8 -= 2*window[0][0] - window[1][0] + 2*window[2][0];
    g8 -= 2*window[0][2] - window[1][2] + 2*window[2][2];
    g8 /= 6;
    g9 = window[0][0] + window[1][0] + window[2][0];
    g9 += window[0][1] + window[1][1] + window[2][1];
    g9 += window[0][2] + window[1][2] + window[2][2];
    g9 /= 3;

  // edge option - default
    M = g1*g1 + g2*g2 + g3*g3 + g4*g4;
    S = M + g5*g5 + g6*g6 + g7*g7 + g8*g8 + g9*g9;

    if (option == 2)
    {
     // line-edge option
      M = g1*g1 + g2*g2 + g3*g3 + g4*g4 + g5*g5 + g6*g6 + g7*g7 + g8*g8;
      S = M + g9*g9;
    }

    edge_value = sqrt(M/S);

    return edge_value;
  }

  void scale_offset(const int& new_min, const int& new_max, int &ncols, int &nrows, 
                    float *input_image, unsigned char *mask_data, unsigned char &mask_fill_value)
  {
    int col, row, index;
    double old_min, old_max, scale, offset, scaled_value;

    old_min = FLT_MAX;
    old_max = -FLT_MAX;
    for (row = 0; row < nrows; row ++)
      for (col = 0; col < ncols; col ++)
      {
        index = col + row*ncols;
        if (mask_data[index] != mask_fill_value)
        {
          if (input_image[index] < old_min)
            old_min = input_image[index];
          if (input_image[index] > old_max)
            old_max = input_image[index];
        }
      }

    scale = (new_max-new_min)/(old_max-old_min);
    offset = scale*old_min - new_min;

    for (row = 0; row < nrows; row ++)
      for (col = 0; col < ncols; col ++)
      {
        index = col + row*ncols;
        if (mask_data[index] != mask_fill_value)
        {
          scaled_value = input_image[index];
          scaled_value = scale*scaled_value - offset;
          input_image[index] = scaled_value;
        }
      }

    return;
  }

} // CommonTilton

