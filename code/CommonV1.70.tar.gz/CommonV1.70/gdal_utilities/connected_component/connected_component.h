#ifndef CONNECTED_COMPONENT_H
#define CONNECTED_COMPONENT_H

using namespace std;

namespace CommonTilton
{

  bool connected_component();
  void find_nghbr(const int& col, const int& row,
                  const short unsigned int& nbdir, int& nbcol, int& nbrow);

} // CommonTilton

#endif // CONNECTED_COMPONENT_H

