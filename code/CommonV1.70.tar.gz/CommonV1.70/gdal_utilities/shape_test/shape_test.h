#ifndef SHAPE_H
#define SHAPE_H

using namespace std;

namespace CommonTilton
{

  bool shape_test();

} // CommonTilton

#endif // SHAPE_H

