#ifndef MASK_EXTRACT_H
#define MASK_EXTRACT_H

using namespace std;

namespace CommonTilton
{

  bool mask_extract();

} // CommonTilton

#endif // MASK_EXTRACT_H

