/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<<
   >>>>
   >>>>       Purpose:  Provides the Params class, which is a class 
   >>>>                 holding program parameters.
   >>>>
   >>>>    Written By:  James C. Tilton, MC 606.3, NASA's GSFC, Greenbelt, MD 20771
   >>>>                 e-mail:  James.C.Tilton@nasa.gov
   >>>>
   >>>>          Date:  April 22, 2014
   >>>>
   >>>> Modifications:  August 10, 2016 - Added optional mask_value
   >>>>                 August 25, 2016 - Added output_image
   >>>>
   >>>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<< */
#ifndef PARAMS_H
#define PARAMS_H

#include <string>
#include <fstream>
#include <sstream>
#include <stdexcept>

using namespace std;

namespace CommonTilton
{
// Params class
  class Params 
  {
    public:
    // Constructor and Destructor
      Params(const string& value);
      virtual ~Params();

    // Member functions
      void print_version();
      bool read(const char *param_file);
      void print();

    // Member variables (public)
    /*-- Input image (required) --*/
      string input_image_file;       /*-- USER INPUT IMAGE FILENAME --*/

    /*-- Output type (optional, default provided) --*/
      int output_type;               /*-- USER INPUT PARAMETER --*/

    /*-- Mask logic (optional, default provided) --*/
      int mask_logic;                /*-- USER INPUT PARAMETER --*/

    /*-- Mask value (optional, default provided) --*/
      int mask_value;                /*-- USER INPUT PARAMETER --*/
      bool mask_value_flag;          /*-- EXISTENCE FLAG --*/

    /*-- Output image (optional) --*/
      string output_image_file;      /*-- USER INPUT IMAGE FILENAME --*/
      bool output_image_flag;        /*-- EXISTENCE FLAG --*/

    /*-- Output mask image (required) --*/
      string output_mask_image_file; /*-- USER INPUT IMAGE FILENAME --*/

    /* Program version */
      string version;                       /* -- PROGRAM PARAMETER --*/

    // FRIEND FUNCTIONS and CLASSES
    protected:

    private:
  };

  string process_line(const string& line, const bool& list_flag);

} // CommonTilton

#endif /* PARAMS_H */
