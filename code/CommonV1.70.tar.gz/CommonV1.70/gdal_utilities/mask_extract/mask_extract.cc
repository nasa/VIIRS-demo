// mask_extract.cc

#include "mask_extract.h"
#include "params/params.h"
#include <gdal_priv.h>
#include <iostream>
#include <float.h>

// Externals
extern CommonTilton::Params params;

namespace CommonTilton
{
  bool mask_extract()
  {
    int col, row, band, index, has_fill = false;
    int ncols, nrows, nbands, count;
    double fill_value = 0.0;
    GDALDataset *inDataset, *outmaskDataset;
    GDALDataset *outDataset = NULL;
    GDALDataType datatype;
    GDALDriver *driver;
    GDALRasterBand *rb, *wb, *mwb;

  // Check input image
    inDataset = (GDALDataset *)GDALOpen(params.input_image_file.c_str(), GA_ReadOnly);
    if (!inDataset)
    {
      cout << "Could not open input_image file name = " << params.input_image_file << endl;
      return false;
    }
    ncols = inDataset->GetRasterXSize();
    nrows = inDataset->GetRasterYSize();
    nbands = inDataset->GetRasterCount();
    driver = inDataset->GetDriver();
    cout << "Extracting mask information from input image " << params.input_image_file << endl;
    cout << "with ncols = " << ncols << ", nrows = " << nrows << " and nbands = " << nbands << endl;

    rb = inDataset->GetRasterBand(1);
    has_fill = false;
    fill_value = rb->GetNoDataValue(&has_fill);
    if (params.mask_value_flag)
    {
      has_fill = true;
      fill_value = params.mask_value;
    }
    if (has_fill)
    {
     // Create output mask image
      char **papszOptions = NULL;
      int out_nbands = 1;
      if (params.output_type == 1)
        out_nbands = nbands;
      datatype = GDT_Byte;
      outmaskDataset = driver->Create(params.output_mask_image_file.c_str(), ncols, nrows, out_nbands, datatype, papszOptions);
      char **metadata = inDataset->GetMetadata("");
      outmaskDataset->SetMetadata(metadata,"");
      const char *pszProj = inDataset->GetProjectionRef();
      if ((pszProj != NULL) && (strlen(pszProj) > 0))
        outmaskDataset->SetProjection(pszProj);
      double imageGeoTransform[6];
      if ( inDataset->GetGeoTransform( imageGeoTransform ) == CE_None )
        outmaskDataset->SetGeoTransform( imageGeoTransform);
      const char *pszGCPProj = inDataset->GetGCPProjection();
      if ((pszGCPProj != NULL) && (strlen(pszGCPProj) > 0))
      {
        int nGCPs = inDataset->GetGCPCount();
        const GDAL_GCP *psGCP;
        psGCP = inDataset->GetGCPs();
        if (nGCPs > 0)
        {
          outmaskDataset->SetGCPs(nGCPs,psGCP,pszGCPProj);
        }
      }

     // Create output image (if requested)
      if (params.output_image_flag)
      {
        datatype = inDataset->GetRasterBand(1)->GetRasterDataType();
        outDataset = driver->Create(params.output_image_file.c_str(), ncols, nrows, nbands, datatype, papszOptions);
        outDataset->SetMetadata(metadata,"");
        if ((pszProj != NULL) && (strlen(pszProj) > 0))
          outDataset->SetProjection(pszProj);
        if ( inDataset->GetGeoTransform( imageGeoTransform ) == CE_None )
          outDataset->SetGeoTransform( imageGeoTransform);
        if ((pszGCPProj != NULL) && (strlen(pszGCPProj) > 0))
        {
          int nGCPs = inDataset->GetGCPCount();
          const GDAL_GCP *psGCP;
          psGCP = inDataset->GetGCPs();
          if (nGCPs > 0)
          {
            outDataset->SetGCPs(nGCPs,psGCP,pszGCPProj);
          }
        }
      }

      float *input_image = new float[ncols*nrows];
      unsigned char *out_mask_image;
      out_mask_image = new unsigned char[ncols*nrows];
      if (params.output_type == 2)
      {
        for (row = 0; row < nrows; row++)
          for (col = 0; col < ncols; col++)
          {
            index = col + row*ncols;
            if (params.mask_logic == 1)
              out_mask_image[index] = 0;
            else
              out_mask_image[index] = 1;
          }
      }
      count = nrows*ncols;
      cout << "Image consists of " << count << " pixels." << endl;
      for (band = 0; band < nbands; band++)
      {
        rb = inDataset->GetRasterBand((band+1));
        if (rb->RasterIO(GF_Read, 0, 0, ncols, nrows, &input_image[0], ncols, nrows, GDT_Float32, 0, 0)
            == CE_Failure)
        {
          cout << "ERROR: Could not read input_image data" << endl;
          return false;
        }
        if (params.output_type == 1)
        {
          count = 0;
          for (row = 0; row < nrows; row++)
            for (col = 0; col < ncols; col++)
            {
              index = col + row*ncols;
              if (input_image[index] == fill_value)
              {
                out_mask_image[index] = 0;
                input_image[index] = 0.0;
                count++;
              }
              else
                out_mask_image[index] = 1;
            }
          cout << "Found " << count << " bad data values in band " << (band+1) << endl;
          mwb = outmaskDataset->GetRasterBand((band+1));
          if (mwb->RasterIO(GF_Write, 0, 0, ncols, nrows, out_mask_image, ncols, nrows, GDT_Byte, 0, 0)
              == CE_Failure)
          {
            cout << "ERROR: Could not write output_mask_image data" << endl;
            return false;
          }
        }
        else
        {
          for (row = 0; row < nrows; row++)
            for (col = 0; col < ncols; col++)
            {
              index = col + row*ncols;
              if (params.mask_logic == 1)
              {
                if (input_image[index] != fill_value)
                  out_mask_image[index] = 1;
                else
                  input_image[index] = 0.0;
              }
              else
              {
                if (input_image[index] == fill_value)
                {
                  out_mask_image[index] = 0;
                  input_image[index] = 0.0;
                }
              }
            }
        }
        if (params.output_image_flag)
        {
          wb = outDataset->GetRasterBand(band+1);
          if (wb->RasterIO(GF_Write, 0, 0, ncols, nrows, input_image, ncols, nrows, GDT_Float32, 0, 0)
              == CE_Failure)
          {
            cout << "ERROR: Could not write image_data" << endl;
            return false;
          }
        }
      } // for (band = 0; band < nbands; band++)
      if (params.output_type == 2)
      {
        count = 0;
        for (row = 0; row < nrows; row++)
          for (col = 0; col < ncols; col++)
          {
            index = col + row*ncols;
            if (out_mask_image[index] == 0)
              count++;
          }
        cout << "Found " << count << " bad data values in image." << endl;
        mwb = outmaskDataset->GetRasterBand((1));
        if (mwb->RasterIO(GF_Write, 0, 0, ncols, nrows, out_mask_image, ncols, nrows, GDT_Byte, 0, 0)
            == CE_Failure)
        {
          cout << "ERROR: Could not write output_mask_image data" << endl;
          return false;
        }
      }

      GDALClose( (GDALDatasetH) inDataset);
      if (params.output_image_flag)
        GDALClose( (GDALDatasetH) outDataset);
      GDALClose( (GDALDatasetH) outmaskDataset);

      return true;
    } // if (hasfill)
    else
    {
      GDALClose( (GDALDatasetH) inDataset);
      cout << "ERROR: Input image " << params.input_image_file << " does not have a fill value. A mask cannot be created." << endl;
      return false;
    }

  }

} // CommonTilton
