// register.cc

#include "register.h"
#include "params/params.h"
#include <image/image.h>
#include <gdal_priv.h>
#include <iostream>
#include <float.h>

// Externals
extern CommonTilton::Params params;

namespace CommonTilton
{
  bool register_image()
  {
    Image base_image;

    base_image.open(params.base_image_file);

    if (base_image.info_valid())
    {
      base_image.print_info();
    }
    else
    {
      cout << "ERROR(register): Could not open " << params.base_image_file << endl;
      return false;
    }

    Image register_image;
    register_image.open(params.register_image_file);

    if (register_image.info_valid())
    {
      register_image.print_info();
    }
    else 
    {
      cout << "ERROR(register): Could not open " << params.register_image_file << endl;
      return false;
    }

    Image output_image;
    output_image.registered_copy(register_image);
    output_image.print_info();

    base_image.close();
    register_image.close();
    output_image.close();

    return true;

  }

} // CommonTilton

