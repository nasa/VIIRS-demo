/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<<
   >>>>
   >>>>       Purpose:  Provides the Params class, which is a class 
   >>>>                 holding program parameters.
   >>>>
   >>>>    Written By:  James C. Tilton, MC 606.3, NASA's GSFC, Greenbelt, MD 20771
   >>>>                 e-mail:  James.C.Tilton@nasa.gov
   >>>>          Date:  May 4, 2016
   >>>> Modifications:  
   >>>>
   >>>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<< */
#ifndef PARAMS_H
#define PARAMS_H

#include <string>
#include <fstream>
#include <sstream>
#include <stdexcept>

using namespace std;

namespace CommonTilton
{
// Params class
  class Params 
  {
    public:
    // Constructor and Destructor
      Params(const string& value);
      virtual ~Params();

    // Member functions
      void print_version();
      bool read(const char *param_file);
      void print();

    // Member variables (public)
      string version;              /* -- PROGRAM PARAMETER --*/

    /*-- ENVI format base input image data file (required) --*/
      string   base_image_file;        /*-- BASE INPUT IMAGE FILE NAME --*/
      bool     base_image_flag;        /*-- FLAG --*/

    /*-- ENVI format input image data file to be registered (required) --*/
      string   register_image_file;    /*-- INPUT IMAGE FILE NAME FOR IMAGE TO BE REGISTERED--*/
      bool     register_image_flag;    /*-- FLAG --*/

    /*-- Registered output image data file (required) --*/
      string   output_image_file;      /*-- OUTPUT REGISTERED IMAGE FILE NAME --*/
      bool     output_image_flag;      /*-- FLAG --*/

    protected:

    private:
  };

  string process_line(const string& line, const bool& list_flag);

} // CommonTilton

#endif /* PARAMS_H */
