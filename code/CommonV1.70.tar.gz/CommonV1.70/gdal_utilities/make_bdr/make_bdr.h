#ifndef MAKE_BDR_H
#define MAKE_BDR_H

using namespace std;

namespace CommonTilton
{

  bool make_bdr();

} // CommonTilton

#endif // MAKE_BDR_H

