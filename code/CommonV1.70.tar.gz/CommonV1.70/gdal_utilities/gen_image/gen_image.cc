// gen_image.cc

#include "gen_image.h"
#include "params/params.h"
#include <gdal_priv.h>
#include <iostream>
#include <float.h>

// Externals
extern CommonTilton::Params params;

namespace CommonTilton
{
  bool gen_image()
  {
    int col, row, index;
    GDALDataset *outDataset;
    GDALDriver *driver;
    GDALRasterBand *wb;

   // Create output image
    driver = GetGDALDriverManager()->GetDriverByName(params.output_format.c_str());
    if (driver == NULL)
    {
      cout << "ERROR(image): Could not find driver with name " << params.output_format << endl;
      return false;
    }
    int out_nbands = 1;
    char **papszOptions = NULL;
    outDataset = driver->Create(params.output_image_file.c_str(), params.ncols, params.nrows, out_nbands, GDT_Float32, papszOptions);

    float *output_image = new float[params.ncols*params.nrows];

    for (row = 0; row < params.nrows; row++)
      for (col = 0; col < params.ncols; col++)
      {
        index = col + row*params.ncols;
        output_image[index] = 0;
        if (params.option == 1)
          output_image[index] = col;
        else if (params.option == 2)
          output_image[index] = row;
      }

    wb = outDataset->GetRasterBand(1);
    if (wb->RasterIO(GF_Write, 0, 0, params.ncols, params.nrows, output_image, params.ncols, params.nrows, GDT_Float32, 0, 0)
        == CE_Failure)
    {
      cout << "ERROR: Could not write output image data" << endl;
      return false;
    }


    GDALClose( (GDALDatasetH) outDataset);

    return true;
  }

} // CommonTilton

