#ifndef MULTIPLY_H
#define MULTIPLY_H

using namespace std;

namespace CommonTilton
{
  bool multiply();

} // CommonTilton

#endif // MULTIPLY_H

