#ifndef CONVERT_TO_GEOTIFF_H
#define CONVERT_TO_GEOTIFF_H

#include <string>
#include <sstream>
#include <stdexcept>

using namespace std;

namespace CommonTilton
{
  bool convert_to_geotiff();

  class BadConversion : public runtime_error
  {
    public:
      BadConversion(const string& s) : runtime_error(s)
      { }
  };

  inline string stringify_int(int x)
  {
    ostringstream o;
    if (!(o << x))
      throw BadConversion("stringify_int(int)");
    return o.str();
  }

} // CommonTilton

#endif // CONVERT_TO_GEOTIFF_H
