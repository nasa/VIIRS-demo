// gen_3d_image.cc

#include "gen_3d_image.h"
#include "params/params.h"
#include <iostream>
#include <float.h>

// Externals
extern CommonTilton::Params params;

namespace CommonTilton
{
  bool gen_3d_image()
  {
    bool status = true;
    int col, row, slice, index;
    unsigned char *byte_output;
    unsigned short *short_output;
    unsigned int *int_output;
    float *float_output;
    fstream output_file;
    int io_size = params.ncols*params.nrows;
    byte_output = NULL; // To avoid compiler warnings
    short_output = NULL; // To avoid compiler warnings
    int_output = NULL; // To avoid compiler warnings
    float_output = NULL; // To avoid compiler warnings

    if (params.dtype == UInt8)
      byte_output = new unsigned char[io_size];
    else if (params.dtype == UInt16)
      short_output = new unsigned short[io_size];
    else if (params.dtype == UInt32)
      int_output = new unsigned int[io_size];
    else // if (params.dtype == Float32)
      float_output = new float[io_size];

    float value;
    output_file.open(params.output_image_file.c_str(), ios_base::out | ios_base::binary );
    for (slice = 0; slice < params.nslices; slice++)
    {
     for (row = 0; row < params.nrows; row++)
      for (col = 0; col < params.ncols; col++)
      {
        value = 0;
        if (params.option == 1)
          value = col+1;
        else if (params.option == 2)
          value = row+1;
        else if (params.option == 3)
          value = slice+1;
        index = col + row*params.ncols;
        if (params.dtype == UInt8)
          byte_output[index] = (unsigned char) value;
        else if (params.dtype == UInt16)
          short_output[index] = (unsigned short) value;
        else if (params.dtype == UInt32)
          int_output[index] = (unsigned int) value;
        else // if (params.dtype == Float32)
          float_output[index] = value;
      }
      if (params.dtype == UInt8)
        output_file.write(reinterpret_cast<char *>(byte_output),io_size);
      else if (params.dtype == UInt16)
        output_file.write(reinterpret_cast<char *>(short_output),2*io_size);
      else if (params.dtype == UInt32)
        output_file.write(reinterpret_cast<char *>(int_output),4*io_size);
      else // if (params.dtype == Float32)
        output_file.write(reinterpret_cast<char *>(float_output),4*io_size);
    }

    output_file.close();


    return status;
  }

} // CommonTilton

