#ifndef GEN_3D_IMAGE_H
#define GEN_3D_IMAGE_H

using namespace std;

namespace CommonTilton
{

  bool gen_3d_image();

} // CommonTilton

#endif // GEN_3D_IMAGE_H

