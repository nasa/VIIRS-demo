/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<<
   >>>>
   >>>>       Purpose:  Provides the Params class, which is a class 
   >>>>                 holding program parameters.
   >>>>
   >>>>    Written By:  James C. Tilton, MC 606.3, NASA's GSFC, Greenbelt, MD 20771
   >>>>                 e-mail:  James.C.Tilton@nasa.gov
   >>>>          Date:  September 11, 2017
   >>>> Modifications:  July 23, 2018 - rewrote to eliminate dependence on image.cc code
   >>>>
   >>>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<< */
#ifndef PARAMS_H
#define PARAMS_H

#include <string>
#include <fstream>
#include <sstream>
#include <stdexcept>

using namespace std;

namespace CommonTilton
{
  enum RHSEGDType { Unknown, UInt8, UInt16, UInt32, Float32 };

// Params class
  class Params 
  {
    public:
    // Constructor and Destructor
      Params(const string& value);
      virtual ~Params();

    // Member functions
      void print_version();
      bool read(const char *param_file);
      void print();

    // Member variables (public)
      string version;                /* -- PROGRAM PARAMETER --*/

    /*-- Output image (required) --*/
      string output_image_file;      /*-- USER INPUT IMAGE FILENAME --*/

    /*-- Number of columns in output image data file (required) --*/
      int    ncols;                  /*-- USER INPUT PARAMETER --*/

    /*-- Number of rows in ouput image data file (required) --*/
      int    nrows;                  /*-- USER INPUT PARAMETER --*/

    /*-- Number of slices in ouput image data file (required) --*/
      int    nslices;                /*-- USER INPUT PARAMETER --*/

    /*-- Data type of input image data (required) --*/
      RHSEGDType dtype;   	    /*-- USER INPUT PARAMETER --*/

    /*-- Image generation option (optional, default provided) --*/
      short int option;   	     /*-- USER INPUT PARAMETER --*/

    // FRIEND FUNCTIONS and CLASSES
    protected:

    private:
  };

  string process_line(const string& line, const bool& list_flag);

} // CommonTilton

#endif /* PARAMS_H */
