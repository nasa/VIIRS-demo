// find_best_thresh.cc

#include "find_best_thresh.h"
#include "params/params.h"
#include "data/data.h"
#include <iostream>
#include <cstdlib>
#include <set>
#include <algorithm>

// Externals
extern CommonTilton::Params params;

namespace CommonTilton
{
  bool find_best_thresh()
  {
// Open input logs file
    params.input_log_fs.open(params.input_log_files.c_str(),ios_base::in);
    if (!params.input_log_fs.is_open())
      return false;

    string input_log_filename, sub_string;
    unsigned int first_pos, last_pos, prefix_size, length;
    int tileID, sample_label, level, nb_levels;
    int h_level, nb_classes, nb_objects, sample_pixels, object_label, object_pixels, overlap_pixels;
    float mg_thresh, error_rate;
    Data *data_ptr;
    set<Data *> data_set;
    set<Data *>::iterator data_set_iter;
    prefix_size = params.prefix.size();
    while (!params.input_log_fs.eof())
    {
      getline(params.input_log_fs,input_log_filename);
      first_pos = input_log_filename.find(params.prefix) + prefix_size;
      last_pos = input_log_filename.find(params.suffix);
      if (last_pos < 20)
      {
        length = last_pos - first_pos;
        sub_string = input_log_filename.substr(first_pos,length);
        tileID = atoi(sub_string.c_str());
        fstream input_log_fs;
        string line;
      // Open input log file
        input_log_fs.open(input_log_filename.c_str(),ios_base::in);
        if (!input_log_fs.is_open())
          return false;
        getline(input_log_fs,line);
        getline(input_log_fs,line);
        while (!line.empty())
        {
          if (line.size() > 0)
          {
            sub_string = get_next_sub_string(line);
            h_level = atoi(sub_string.c_str());
            sub_string = get_next_sub_string(line);
            nb_classes = atoi(sub_string.c_str());
            sub_string = get_next_sub_string(line);
            nb_objects = atoi(sub_string.c_str());
            sub_string = get_next_sub_string(line);
            mg_thresh = atof(sub_string.c_str());
            sub_string = get_next_sub_string(line);
            sample_label = atoi(sub_string.c_str());
            sub_string = get_next_sub_string(line);
            sample_pixels = atoi(sub_string.c_str());
            sub_string = get_next_sub_string(line);
            object_label = atoi(sub_string.c_str());
            sub_string = get_next_sub_string(line);
            object_pixels = atoi(sub_string.c_str());
            sub_string = get_next_sub_string(line);
            overlap_pixels = atoi(sub_string.c_str());
            sub_string = get_next_sub_string(line);
            error_rate = atof(sub_string.c_str());

            if (error_rate < 0.99)
            {
              if (data_set.empty())
              {
                Data *data = new Data(tileID,sample_label);
                data->add_level(h_level,nb_classes,nb_objects,mg_thresh,sample_label,sample_pixels,
                                object_label,object_pixels,overlap_pixels,error_rate);
                data_set.insert(data);
              }
              else
              {
                data_set_iter = data_set.begin();
                bool found_flag = false;
                while ((!found_flag) && (data_set_iter != data_set.end()))
                {
                  data_ptr = *data_set_iter;
                  if ((data_ptr->get_tileID() == tileID) && (data_ptr->get_sample_label() == sample_label))
                  {
                    data_ptr->add_level(h_level,nb_classes,nb_objects,mg_thresh,sample_label,sample_pixels,
                                object_label,object_pixels,overlap_pixels,error_rate);
                    found_flag = true;
                  }
                  ++data_set_iter;
                }
                if (!found_flag)
                {
                  Data *data = new Data(tileID,sample_label);
                  data->add_level(h_level,nb_classes,nb_objects,mg_thresh,sample_label,sample_pixels,
                                  object_label,object_pixels,overlap_pixels,error_rate);
                  data_set.insert(data);
                }
              }
//            params.output_log_fs << h_level << ", " << nb_classes << ", " << nb_objects << ", " << mg_thresh << ", ";
//            params.output_log_fs << sample_label << ", " << sample_pixels << ", " << object_label << ", " << object_pixels << ", ";
//            params.output_log_fs << overlap_pixels << ", " << error_rate << endl;
            }
          }
          getline(input_log_fs,line);
        }
      }
    }

    unsigned int data_set_size = data_set.size();
    vector<Data> sorted_data_set(data_set_size,Data());
    unsigned int index = 0;
    data_set_iter = data_set.begin();
    while (data_set_iter != data_set.end())
    {
      data_ptr = *data_set_iter;
      tileID = data_ptr->get_tileID();
      sample_label = data_ptr->get_sample_label();
      nb_levels = data_ptr->get_nb_levels();
      params.output_log_fs << endl << "For tileID " << tileID << " and field_sample " << sample_label << ":" << endl;
      params.output_log_fs << endl << "h_level, classes, objects, mg_thresh, sample_pixels, object_label, object_pixels, overlap_pixels, error_rate" << endl;
      for (level = 0; level < nb_levels; level++)
      {
        data_ptr->get_data(level,h_level,nb_classes,nb_objects,mg_thresh,sample_pixels,
                           object_label,object_pixels,overlap_pixels,error_rate);
        params.output_log_fs << h_level << ", " << nb_classes << ", " << nb_objects << ", " << mg_thresh << ", ";
        params.output_log_fs << sample_pixels << ", " << object_label << ", " << object_pixels << ", ";
        params.output_log_fs << overlap_pixels << ", " << error_rate << endl;
      }
      data_ptr->set_best_thresh();
      sorted_data_set[index] = *data_ptr;
      ++data_set_iter;
      index++;
    }
    sort(sorted_data_set.begin(),sorted_data_set.end(),ThreshLessThan());

    float best_mg_thresh, best_error_rate, max_mg_thresh = 0.0;
    data_set_iter = data_set.begin();
    params.output_log_fs << endl << "Best error rate sorted by mg_thresh:" << endl;
    params.output_log_fs << "tileID, field_sample, best_mg_thresh, best_error_rate" << endl;
    for (index = 0; index < data_set_size; index++)
    {
      tileID = sorted_data_set[index].get_tileID();
      sample_label = sorted_data_set[index].get_sample_label();
      sorted_data_set[index].get_best_thresh(best_mg_thresh,best_error_rate);
      if (max_mg_thresh < best_mg_thresh)
        max_mg_thresh = best_mg_thresh;
      params.output_log_fs << tileID << ", " << sample_label << ", " << best_mg_thresh << ", " << best_error_rate << endl;  
    }

  // Find maximum number of hierarchical levels and the minimum and maximum mg_thresh over all cases.
    int max_nb_levels;
    float min_mg_thresh;
    max_nb_levels = sorted_data_set[0].get_nb_levels();
    min_mg_thresh = sorted_data_set[0].get_min_mg_thresh();
    max_mg_thresh = sorted_data_set[0].get_max_mg_thresh();
    for (index = 1; index < data_set_size; index++)
    {
      if (sorted_data_set[index].get_nb_levels() > max_nb_levels)
        max_nb_levels = sorted_data_set[index].get_nb_levels();
      if (sorted_data_set[index].get_min_mg_thresh() < min_mg_thresh)
        min_mg_thresh = sorted_data_set[index].get_min_mg_thresh();
      if (sorted_data_set[index].get_max_mg_thresh() > max_mg_thresh)
        max_mg_thresh = sorted_data_set[index].get_max_mg_thresh();
    }

    params.output_log_fs << endl << "Maximum number of hierarchical levels = " << max_nb_levels << endl;
    params.output_log_fs << "Minimum merge threshold = " << min_mg_thresh << endl;
    params.output_log_fs << "Maximum merge threshold = " << max_mg_thresh << endl;
    float mg_thresh_incr = (max_mg_thresh - min_mg_thresh)/max_nb_levels;
    min_mg_thresh -= (mg_thresh_incr/2);
    max_mg_thresh += (mg_thresh_incr/2);

    int nb_samples;
    float sum_error_rate;
    params.output_log_fs << endl << "mg_thresh_center, ave_best_error_rate" << endl;  
    float thresh;
    for (thresh = min_mg_thresh; thresh < max_mg_thresh; thresh += mg_thresh_incr)
    {
      nb_samples = 0;
      sum_error_rate = 0.0;
      for (index = 0; index < data_set_size; index++)
      {
        sorted_data_set[index].get_best_thresh(best_mg_thresh,best_error_rate);
        if ((best_mg_thresh >= thresh) && (best_mg_thresh < (thresh + mg_thresh_incr)))
        {
          nb_samples += 1;
          sum_error_rate += best_error_rate;
        }
      }
      if (nb_samples > 0)
        params.output_log_fs << (thresh + (mg_thresh_incr/2.0)) << ", " << (sum_error_rate/nb_samples) << endl;
    }

    params.output_log_fs << endl << "mg_thresh_center, ave_error_rate, median_error_rate" << endl;
    vector<float> sorted_error_rate;
    for (thresh = min_mg_thresh; thresh < max_mg_thresh; thresh += mg_thresh_incr)
    {
      nb_samples = 0;
      sum_error_rate = 0.0;
      sorted_error_rate.clear();
      for (index = 0; index < data_set_size; index++)
      {
        nb_levels = sorted_data_set[index].get_nb_levels();
        for (level = 0; level < nb_levels; level++)
        {
          mg_thresh = sorted_data_set[index].get_mg_thresh(level);
          error_rate = sorted_data_set[index].get_error_rate(level);
          if ((mg_thresh >= thresh) && (mg_thresh < (thresh + mg_thresh_incr)))
          {
            nb_samples += 1;
            sum_error_rate += error_rate;
            sorted_error_rate.push_back(error_rate);
          }
        }
      }
      if (nb_samples > 0)
      {
        if (nb_samples == 1)
          params.output_log_fs << (thresh + (mg_thresh_incr/2.0)) << ", " << sum_error_rate << ", " << sum_error_rate << endl;
        else
        {
          sort(sorted_error_rate.begin(),sorted_error_rate.end());
          params.output_log_fs << (thresh + (mg_thresh_incr/2.0)) << ", " << (sum_error_rate/nb_samples);
          params.output_log_fs << ", " << sorted_error_rate[nb_samples/2] << endl;
        }
      }
    }

    return true;
  }

  string get_next_sub_string(string& line)
  {
    int sub_pos;
    string sub_string;

    sub_pos = line.find_first_of(",");
    if (sub_pos != (int) string::npos)
    {
      sub_string = line.substr(0,sub_pos);
      line = line.substr(sub_pos+1);
    }
    else
    {
      sub_string = line;
      line = "";
    }

    return sub_string;

  }
} // CommonTilton
