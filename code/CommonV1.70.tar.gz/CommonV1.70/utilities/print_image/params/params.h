/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<<
   >>>>
   >>>>       Purpose:  Provides the Params class, which is a class 
   >>>>                 holding program parameters.
   >>>>
   >>>>    Written By:  James C. Tilton, MC 606.3, NASA's GSFC, Greenbelt, MD 20771
   >>>>                 e-mail:  James.C.Tilton@nasa.gov
   >>>>          Date:  August 15, 2014
   >>>> Modifications:  
   >>>>
   >>>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<< */
#ifndef PARAMS_H
#define PARAMS_H

#include <image/image.h>
#include <string>
#include <fstream>
#include <sstream>
#include <stdexcept>

using namespace std;

namespace CommonTilton
{
// Params class
  class Params 
  {
    public:
    // Constructor and Destructor
      Params(const string& value);
      virtual ~Params();

    // Member functions
      void print_version();
      bool read(const char *param_file);
      void print();

    // Member variables (public)
    /*-- Input image (required) --*/
      string input_image_file;     /*-- USER INPUT IMAGE FILENAME --*/

#ifndef GDAL
    /*-- Number of columns in input image data file (required) --*/
      int    ncols;                /*-- USER INPUT PARAMETER --*/
      bool   ncols_flag;           /*-- EXISTENCE FLAG --*/

    /*-- Number of rows in input image data file (required) --*/
      int    nrows;                /*-- USER INPUT PARAMETER --*/
      bool   nrows_flag;           /*-- EXISTENCE FLAG --*/

    /*-- Number of spectral bands in input image data file (required) --*/
      int    nbands;		   /*-- USER INPUT PARAMETER --*/
      bool   nbands_flag;          /*-- EXISTENCE FLAG --*/

    /*-- Data type of input image data (required) --*/
      RHSEGDType dtype;   	   /*-- USER INPUT PARAMETER --*/
      bool       dtype_flag;       /*-- EXISTENCE FLAG --*/
#endif

    /*-- Band to be printed (optional, default provided) --*/
      int  band;                   /*-- USER INPUT PARAMETER --*/
      bool band_flag;              /*-- EXISTENCE FLAG --*/

    /*-- Spatial window to be printed (optional, default provided) --*/
      int  srcwin[4];              /*-- USER INPUT PARAMETERS --*/
      bool srcwin_flag;            /*-- EXISTENCE FLAG --*/

    /* Program version */
      string version;                       /* -- PROGRAM PARAMETER --*/

    // FRIEND FUNCTIONS and CLASSES
    protected:

    private:
  };

  string process_line(const string& line, const bool& list_flag);

} // CommonTilton

#endif /* PARAMS_H */
