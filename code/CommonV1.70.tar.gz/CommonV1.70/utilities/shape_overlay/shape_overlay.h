#ifndef SHAPE_OVERLAY_H
#define SHAPE_OVERLAY_H

namespace CommonTilton
{

  bool shape_overlay();

} // CommonTilton

#endif // SHAPE_OVERLAY_H

