#ifndef INSERT_3D_IMAGE_H
#define INSERT_3D_IMAGE_H

using namespace std;

namespace CommonTilton
{

  bool insert_3d_image();

} // CommonTilton

#endif // INSERT_3D_IMAGE_H

