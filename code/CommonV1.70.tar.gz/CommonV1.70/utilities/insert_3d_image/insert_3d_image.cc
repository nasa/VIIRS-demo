// insert_3d_image.cc

#include "insert_3d_image.h"
#include "params/params.h"
#include <iostream>
#include <float.h>

// Externals
extern CommonTilton::Params params;

namespace CommonTilton
{
  bool insert_3d_image()
  {
    bool outside_flag = false;
    int col, row, slice, base_index, insert_index;
    unsigned char *byte_base, *byte_insert;
    unsigned short *short_base, *short_insert;
    unsigned int *int_base, *int_insert;
    float *float_base, *float_insert;
    fstream base_file, insert_file, output_file;
    int base_io_size = params.base_ncols*params.base_nrows;
    int insert_io_size = params.insert_ncols*params.insert_nrows;
    byte_base = byte_insert = NULL; // To avoid compiler warnings
    short_base = short_insert = NULL; // To avoid compiler warnings
    int_base = int_insert = NULL; // To avoid compiler warnings
    float_base = float_insert = NULL; // To avoid compiler warnings

    if (params.dtype == UInt8)
    {
      byte_base = new unsigned char[base_io_size];
      byte_insert = new unsigned char[insert_io_size];
    }
    else if (params.dtype == UInt16)
    {
      short_base = new unsigned short[base_io_size];
      short_insert = new unsigned short[insert_io_size];
    }
    else if (params.dtype == UInt32)
    {
      int_base = new unsigned int[base_io_size];
      int_insert = new unsigned int[insert_io_size];
    }
    else // if (params.dtype == Float32)
    {
      float_base = new float[base_io_size];
      float_insert = new float[insert_io_size];
    }

    base_file.open(params.base_image.c_str(), ios_base::in | ios_base::binary );
    insert_file.open(params.insert_image.c_str(), ios_base::in | ios_base::binary );
    output_file.open(params.output_image.c_str(), ios_base::out | ios_base::binary );
    for (slice = 0; slice < params.insert_nslices; slice++)
    {
      if (slice < params.base_nslices)
      {
        if (params.dtype == UInt8)
        {
          base_file.read(reinterpret_cast<char *>(byte_base),base_io_size);
          insert_file.read(reinterpret_cast<char *>(byte_insert),insert_io_size);
        }
        else if (params.dtype == UInt16)
        {
          base_file.read(reinterpret_cast<char *>(short_base),2*base_io_size);
          insert_file.read(reinterpret_cast<char *>(short_insert),2*insert_io_size);
        }
        else if (params.dtype == UInt32)
        {
          base_file.read(reinterpret_cast<char *>(int_base),4*base_io_size);
          insert_file.read(reinterpret_cast<char *>(int_insert),4*insert_io_size);
        }
        else // if (params.dtype == Float32)
        {
          base_file.read(reinterpret_cast<char *>(float_base),4*base_io_size);
          insert_file.read(reinterpret_cast<char *>(float_insert),4*insert_io_size);
        }
        for (row = 0; row < params.insert_nrows; row++)
        {
          if (row < params.base_nrows)
          {
            for (col = 0; col < params.insert_ncols; col++)
            {
              if (col < params.base_ncols)
              {
                base_index = (params.insert_column + col) + (params.insert_row + row)*params.base_ncols;
                insert_index = col + row*params.insert_ncols;
                if (params.dtype == UInt8)
                  byte_base[base_index] = byte_insert[insert_index];
                else if (params.dtype == UInt16)
                  short_base[base_index] = short_insert[insert_index];
                else if (params.dtype == UInt32)
                  int_base[base_index] = int_insert[insert_index];
                else // if (params.dtype == Float32)
                  float_base[base_index] = float_insert[insert_index];
              }
              else
                outside_flag = true;
            } // for (col = params.insert_column; col < params.insert_ncols; col++)
          }
          else
            outside_flag = true;
        } // for (row = params.insert_row; row < params.insert_nrows; row++)
      }
      else
        outside_flag = true;
      if (params.dtype == UInt8)
        output_file.write(reinterpret_cast<char *>(byte_base),base_io_size);
      else if (params.dtype == UInt16)
        output_file.write(reinterpret_cast<char *>(short_base),2*base_io_size);
      else if (params.dtype == UInt32)
        output_file.write(reinterpret_cast<char *>(int_base),4*base_io_size);
      else // if (params.dtype == Float32)
        output_file.write(reinterpret_cast<char *>(float_base),4*base_io_size);
    } // for (slice = params.insert_slice; slice < params.insert_nslices; slice++)

    if (outside_flag)
      cout << "WARNING: Inserted image extends outside base image" << endl;

    base_file.close( );
    insert_file.close( );
    output_file.close( );

    return true;
  }

} // CommonTilton

