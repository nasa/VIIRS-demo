// params.cc

#include "params.h"
#include <iostream>
#include <cstdlib>

namespace CommonTilton
{

 // Constructor
  Params::Params(const string& value)
  {
    version = value;

    return;
  }

 // Destructor...
  Params::~Params() 
  {
    return;
  }

 // Print version
  void Params::print_version( )
  {
    cout << endl << version << endl << endl;

    return;
  }

 // Read parameters
  bool Params::read(const char *param_file)
  {
//    cout << "Reading parameters from " << param_file << endl;
    ifstream param_fs(param_file);
    if (!param_fs.is_open())
    {
      cout << "Cannot open input file " << param_file << endl;
      return false;
    }

  // Read initial parameters from parameter file until End-of-File reached
    bool base_image_flag = false;
    bool base_ncols_flag = false;
    bool base_nrows_flag = false;
    bool base_nslices_flag = false;
    bool dtype_flag = false;
    bool insert_image_flag = false;
    bool insert_ncols_flag = false;
    bool insert_nrows_flag = false;
    bool insert_nslices_flag = false;
    bool insert_column_flag = false;
    bool insert_row_flag = false;
    bool insert_slice_flag = false;
    bool output_image_flag = false;
    int sub_pos;
    string line, sub_string;
    while (!param_fs.eof())
    {
      getline(param_fs,line);
      sub_pos = line.find("-");
      while ((!param_fs.eof()) && (sub_pos != 0))
      {
        getline(param_fs,line);
        sub_pos = line.find("-");
      }
      if (line.find("-base_image") != string::npos)
      {
        base_image = process_line(line,false);
        base_image_flag = true;
      }
      if (line.find("-base_ncols") != string::npos)
      {
        sub_string = process_line(line,false);
        base_ncols = atoi(sub_string.c_str());
        base_ncols_flag = true;
      }
      if (line.find("-base_nrows") != string::npos)
      {
        sub_string = process_line(line,false);
        base_nrows = atoi(sub_string.c_str());
        base_nrows_flag = true;
      }
      if (line.find("-base_nslices") != string::npos)
      {
        sub_string = process_line(line,false);
        base_nslices = atoi(sub_string.c_str());
        base_nslices_flag = true;
      }
      if (line.find("-dtype") != string::npos)
      {
        sub_string = process_line(line,false);
        if (sub_string == "UInt8")
        {
          dtype = UInt8;
          dtype_flag = true;
        }
        else if (sub_string == "UInt16")
        {
          dtype = UInt16;
          dtype_flag = true;
        }
        else if (sub_string == "UInt32")
        {
          dtype = UInt32;
          dtype_flag = true;
        }
        else if (sub_string == "Float32")
        {
          dtype = Float32;
          dtype_flag = true;
        }
        else
        { 
          dtype = Unknown;
          dtype_flag = false;
        }
      }
      if (line.find("-insert_image") != string::npos)
      {
        insert_image = process_line(line,false);
        insert_image_flag = true;
      }
      if (line.find("-insert_ncols") != string::npos)
      {
        sub_string = process_line(line,false);
        insert_ncols = atoi(sub_string.c_str());
        insert_ncols_flag = true;
      }
      if (line.find("-insert_nrows") != string::npos)
      {
        sub_string = process_line(line,false);
        insert_nrows = atoi(sub_string.c_str());
        insert_nrows_flag = true;
      }
      if (line.find("-insert_nslices") != string::npos)
      {
        sub_string = process_line(line,false);
        insert_nslices = atoi(sub_string.c_str());
        insert_nslices_flag = true;
      }
      if (line.find("-insert_column") != string::npos)
      {
        sub_string = process_line(line,false);
        insert_column = atoi(sub_string.c_str());
        insert_column_flag = true;
      }
      if (line.find("-insert_row") != string::npos)
      {
        sub_string = process_line(line,false);
        insert_row = atoi(sub_string.c_str());
        insert_row_flag = true;
      }
      if (line.find("-insert_slice") != string::npos)
      {
        sub_string = process_line(line,false);
        insert_slice = atoi(sub_string.c_str());
        insert_slice_flag = true;
      }
      if (line.find("-output_image") != string::npos)
      {
        output_image = process_line(line,false);
        output_image_flag = true;
      }
    }

    param_fs.close();

// Exit with false status if a required parameter is not set, or an improper parameter
// setting is detected.
    if (!base_image_flag)
    {
      cout << "ERROR: -base_image (Image to insert into) is required" << endl;
      return false;
    }
    if (!base_ncols_flag)
    {
      cout << "ERROR: -base_ncols (Number of columns in base image) is required" << endl;
      return false;
    }
    if (!base_nrows_flag)
    {
      cout << "ERROR: -base_nrows (Number of rows in base image) is required" << endl;
      return false;
    }
    if (!base_nslices_flag)
    {
      cout << "ERROR: -base_nslices (Number of slices in base image) is required" << endl;
      return false;
    }
    if (!dtype_flag)
    {
      cout << "ERROR: -dtype (Data type of the base image) is required" << endl;
      return false;
    }
    if (!insert_image_flag)
    {
      cout << "ERROR: -insert_image (Image to insert into) is required" << endl;
      return false;
    }
    if (!insert_ncols_flag)
    {
      cout << "ERROR: -insert_ncols (Number of columns in image to be inserted) is required" << endl;
      return false;
    }
    if (!insert_nrows_flag)
    {
      cout << "ERROR: -insert_nrows (Number of rows in image to be inserted) is required" << endl;
      return false;
    }
    if (!insert_nslices_flag)
    {
      cout << "ERROR: -insert_nslices (Number of slices in image to be inserted) is required" << endl;
      return false;
    }
    if (!insert_column_flag)
    {
      cout << "ERROR: -insert_column (Insert location column) is required" << endl;
      return false;
    }
    if (!insert_row_flag)
    {
      cout << "ERROR: -insert_row (Insert location row) is required" << endl;
      return false;
    }
    if (!insert_slice_flag)
    {
      cout << "ERROR: -insert_slice (Insert location slice) is required" << endl;
      return false;
    }
    if (!output_image_flag)
    {
      cout << "ERROR: -output_image (Output image) is required" << endl;
      return false;
    }

    return true;
  }

 // Print parameters
  void Params::print()
  {
  // Print version
     cout << "This is " << version << endl << endl;

  // Print input parameters
     cout << "Base image file name: " << base_image << endl;
     cout << "Base image number of columns = " <<  base_ncols << endl;
     cout << "Base image number of rows = " <<  base_nrows << endl;
     cout << "Base image number of slices = " <<  base_nslices << endl;
     switch (dtype)
     {
       case UInt8:   cout << "Base image has UInt8 image data type" << endl;
                     break;
       case UInt16:  cout << "Base image has UInt16 image data type" << endl;
                     break;
       case UInt32:  cout << "Base image has UInt32 image data type" << endl;
                     break;
       case Float32: cout << "Base image has Float32 image data type" << endl;
                     break;
       default:      cout << "WARNING: Requested invalid image data type" << endl;
                     break;
     }
     cout << "Insert image file name: " << insert_image << endl;
     cout << "Insert image number of columns = " <<  insert_ncols << endl;
     cout << "Insert image number of rows = " <<  insert_nrows << endl;
     cout << "Insert image number of slices = " <<  insert_nslices << endl;
     cout << "Insert location column = " <<  insert_column << endl;
     cout << "Insert location row = " <<  insert_row << endl;
     cout << "Insert location slice = " <<  insert_slice << endl;
     cout << "Output image file name: " << output_image << endl;

     return;
  }

  string process_line(const string& line, const bool& list_flag)
  {
    int sub_pos, sub_pos_space, sub_pos_tab;
    string sub_string;

    sub_pos_space = line.find_first_of(" ");
    sub_pos_tab = line.find_first_of("\t");
    sub_pos = sub_pos_space;
    if (sub_pos ==  (int) string::npos)
      sub_pos = sub_pos_tab;
    if (sub_pos ==  (int) string::npos)
      return " ";

    sub_string = line.substr(sub_pos);
    while ((sub_string.substr(0,1) == "\t") || (sub_string.substr(0,1) == " "))
      sub_string = line.substr(++sub_pos);
#ifndef WINDOWS
    if (list_flag)
      return sub_string;

    sub_pos = sub_string.find_first_of(" ");
    if (sub_pos !=  (int) string::npos)
      sub_string = sub_string.substr(0,sub_pos);
    sub_pos = sub_string.find_first_of("\t");
    if (sub_pos !=  (int) string::npos)
      sub_string = sub_string.substr(0,sub_pos);
    sub_pos = sub_string.find_first_of("\r");
    if (sub_pos !=  (int) string::npos)
      sub_string = sub_string.substr(0,sub_pos);
#endif
    return sub_string;
  }

} // namespace CommonTilton
