/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<<
   >>>>
   >>>>       Purpose:  Provides the Params class, which is a class 
   >>>>                 holding program parameters.
   >>>>
   >>>>    Written By:  James C. Tilton, MC 606.3, NASA's GSFC, Greenbelt, MD 20771
   >>>>                 e-mail:  James.C.Tilton@nasa.gov
   >>>>          Date:  July 23, 2018
   >>>> Modifications:  
   >>>>
   >>>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<< */
#ifndef PARAMS_H
#define PARAMS_H

#include <string>
#include <fstream>
#include <sstream>
#include <stdexcept>

using namespace std;

namespace CommonTilton
{
  enum RHSEGDType { Unknown, UInt8, UInt16, UInt32, Float32 };

// Params class
  class Params 
  {
    public:
    // Constructor and Destructor
      Params(const string& value);
      virtual ~Params();

    // Member functions
      void print_version();
      bool read(const char *param_file);
      void print();

    // Member variables (public)
    /* Program version */
      string version;		     /* -- PROGRAM PARAMETER --*/

    /*-- Base image (required) --*/
      string base_image;             /*-- USER INPUT FILENAME --*/

    /*-- Number of columns in base image data file (required) --*/
      int    base_ncols;             /*-- USER INPUT PARAMETER --*/

    /*-- Number of rows in base image data file (required) --*/
      int    base_nrows;             /*-- USER INPUT PARAMETER --*/

    /*-- Number of slices in base image data file (required) --*/
      int    base_nslices;           /*-- USER INPUT PARAMETER --*/

    /*-- Data type of base image data (required) --*/
      RHSEGDType dtype;   	     /*-- USER INPUT PARAMETER --*/

    /*-- Insert image (required) --*/
      string insert_image;             /*-- USER INPUT FILENAME --*/

    /*-- Number of columns in insert image data file (required) --*/
      int    insert_ncols;             /*-- USER INPUT PARAMETER --*/

    /*-- Number of rows in insert image data file (required) --*/
      int    insert_nrows;             /*-- USER INPUT PARAMETER --*/

    /*-- Number of slices in insert image data file (required) --*/
      int    insert_nslices;           /*-- USER INPUT PARAMETER --*/

    /*-- Insert location column (required) --*/
      int    insert_column;            /*-- USER INPUT PARAMETER --*/

    /*-- Insert location row (required) --*/
      int    insert_row;               /*-- USER INPUT PARAMETER --*/

    /*-- Insert location slice (required) --*/
      int    insert_slice;             /*-- USER INPUT PARAMETER --*/

    /*-- Output image (required) --*/
      string output_image;             /*-- USER INPUT FILENAME --*/

    // FRIEND FUNCTIONS and CLASSES
    protected:

    private:
  };

  string process_line(const string& line, const bool& list_flag);

} // CommonTilton

#endif /* PARAMS_H */
