/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<<
   >>>>
   >>>> 	Main program for the window_3d program. Does not use GDAL.
   >>>>
   >>>>  Private:
   >>>> 	main(int argc, char **argv)
   >>>> 	usage()
   >>>> 	help()
   >>>>
   >>>>   Static:
   >>>>   Public:
   >>>>
   >>>>       Written: March 26, 2018
   >>>> Modifications: 
   >>>>
   >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<< */

#include "window_3d.h"
#include "params/params.h"
#include <iostream>
#include <cstdlib>
#include <climits>
#include <cstring>

using namespace std;
using namespace CommonTilton;

//Globals
Params params("Version 1.70, March 26, 2018");

// Forward function declarations
void usage();
void help();

/*-----------------------------------------------------------
|
|  Routine Name: main - Main program for the window_3d program interface
|
|  Purpose: Declares program parameters, reads parameter file and initializes program parameters,
|           opens log file (if requested), calls the window_3d function and returns an exit status.
|
|  Input from command line - parameter_file_name
|
|       Returns: EXIT_SUCCESS on success, EXIT_FAILURE on failure
|
|    Written By: James C. Tilton, NASA's GSFC, Mail Code 606.3, Greenbelt,MD 20771
|        E-Mail: James.C.Tilton@nasa.gov
|
|       Written: March 26, 2018
| Modifications: 
|
------------------------------------------------------------*/
int main(int argc, char *argv[])
{
  bool status = true;

  if (argc == 1)
  {
    usage();
    cout << "ERROR: Need parameter file as argument." << endl;
    return EXIT_FAILURE;
  }
  else if ((strncmp(argv[1],"-v",2) == 0) || (strncmp(argv[1],"-version",8) == 0))
  {
    params.print_version();
    cout << "For help information: window_3d -h or window_3d -help" << endl << endl;
    return EXIT_SUCCESS;
  }
  else if ((strncmp(argv[1],"-h",2) == 0) || (strncmp(argv[1],"-help",5) == 0))
  {
    help();
    return EXIT_SUCCESS;
  }
  else if (strncmp(argv[1],"-",1) == 0)
  {
    usage();
    cout << "ERROR: The parameter file name cannot start with an \"-\"" << endl;
    return EXIT_FAILURE;
  }
  else
  {
    if (argc != 2)
    {
      usage();
      cout << "ERROR: Incorrect number of parameters on command line" << endl;
      return EXIT_FAILURE;
    }
    else
    {
      status = params.read(argv[1]);
      if (!status)
      {
        usage();
        cout << "ERROR: Error reading parameter file (read)" << endl;
        return EXIT_FAILURE;
      }
    }
  }

  if (status)
  {
    params.print();
    status = window_3d();
  }

  if (status)
  {
    cout << endl << "Successful completion of window_3d program" << endl;
  }
  else
  {
    cout << endl << "The window_3d program terminated improperly." << endl;
  }
  
  if (status)
    return EXIT_SUCCESS;
  else
    return EXIT_FAILURE;
}

/*-----------------------------------------------------------
|
|  Routine Name: usage - Usage function
|
|       Purpose: Informs user of proper usage of program when mis-used.
|
|         Input:
|
|        Output:
|
|       Returns: (void)
|
|    Written By: James C. Tilton, NASA's GSFC, Mail Code 606.3, Greenbelt,MD 20771
|        E-Mail: James.C.Tilton@nasa.gov
|
|       Written: March 26, 2018
| Modifications: 
|
------------------------------------------------------------*/
void usage()
{
  cout << endl << "Usage: " << endl << endl;
  cout << "window_3d parameter_file_name" << endl << endl;
  cout << "For help information: window_3d -h or window_3d -help" << endl;
  cout << "For version information: window_3d -v or window_3d -version" << endl;

  return;
}

/*-----------------------------------------------------------
|
|  Routine Name: help - Help function
|
|       Purpose: Provides help information to user on program parameters
|
|         Input:
|
|        Output:
|
|       Returns: (void)
|
|    Written By: James C. Tilton, NASA's GSFC, Mail Code 606.3, Greenbelt,MD 20771
|        E-Mail: James.C.Tilton@nasa.gov
|
|       Written: March 26, 2018
| Modifications: 
|
------------------------------------------------------------*/
void help()
{
  cout << endl << "The window_3d progam is called in the following manner:" << endl;
  cout << endl << "window_3d parameter_file_name" << endl;
  cout << endl << "where \"parameter_file_name\" is the name of the input parameter" << endl;
  cout << "file. For contents see below." << endl;
  cout << endl << "For this help: window_3d -h or window_3d -help" << endl;
  cout << endl << "For version information: window_3d -v or window_3d -version";
  cout << endl;
  cout << endl << "The parameter file consists of entries of the form:" << endl;
  cout << endl << "-parameter_name parameter_value(s)" << endl;

  fprintf(stdout,"\nThe following parameters may be specified in the input parameter file:\n\n");
  fprintf(stdout,"Input File and parameter:\n"
"-input_image		(string)	Input image file name(required)\n"
"-ncols			(int)		Number of columns in input image data\n"
"				        (0 < ncols < %d, required)\n"
"-nrows			(int)		Number of rows in input image data\n"
"				        (0 < nrows < %d, required)\n"
"-nslices		(int)		Number of slices in input image data\n"
"					(0 < nslices < %d, required)\n"
"-nbands			(int)		Number of spectral bands in input image\n"
"					data.  (0 < nbands < %d, optional,\n"
"					 default = 1)\n"
"-dtype			(string)	Input image data type. Currently must\n"
"					be either:\n"
"					 UInt8   => \"unsigned char (8-bit)\" or\n"
"					 UInt16  => \"unsigned short int\n"
"						     (16-bit)\" or\n"
"					 Float32 => \"float (32-bit)\"\n"
"					(required)\n"
"-mask			(string)	Input image mask file name\n"
"					Data type must be \'Byte\'.\n"
"					NOTE: The input image may be instead\n"
"					masked by specifying a \'NoData Value\'\n"
"					in the input image.\n"
"					(optional, default = {none})\n"
"-mask_value		(int)		If input mask file is provided,\n"
"					this is the value in the mask file that\n"
"					designates invalid data. (default is 0.)\n"
"-window_size		(int)		Window Size:\n"
"					  3. \"[3x3],\"\n"
"					  5. \"[5x5],\"\n"
"					  7. \"[7x7],\"\n"
"					  9. \"[9x9],\"\n"
"					 11. \"[11x11],\"\n"
"					 13. \"[13x13],\"\n"
"					 15. \"[15x15],\"\n"
"					(default = 3 -> \"[3x3]\")\n"
"-operation		(int)		Window Operation:\n"
"					  1. \"Window Average,\"\n"
"					  2. \"Window Maximum,\"\n"
"					  3. \"Window Minimum,\"\n"
"					  4. \"Window Median,\"\n"
"					(default = 4 -> \"Window Median\")\n",
          USHRT_MAX,USHRT_MAX,USHRT_MAX,USHRT_MAX);
  fprintf(stdout,"Output Files:\n"
"-output_image		(string)	Output image (required)\n"
"NOTE: Output image data type will be Float32, except for the case of the\n"
"Window Median operation, where the data type will be the same as the Input Image\n"
"-output_mask_image	(string)	Output mask image (required)\n");

  return;
}
