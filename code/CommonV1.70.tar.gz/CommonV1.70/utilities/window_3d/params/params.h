/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<<
   >>>>
   >>>>       Purpose:  Provides the Params class, which is a class 
   >>>>                 holding program parameters.
   >>>>
   >>>>    Written By:  James C. Tilton, MC 606.3, NASA's GSFC, Greenbelt, MD 20771
   >>>>                 e-mail:  James.C.Tilton@nasa.gov
   >>>>          Date:  March 25, 2018
   >>>> Modifications:  
   >>>>
   >>>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<< */
#ifndef PARAMS_H
#define PARAMS_H

#include <string>
#include <fstream>
#include <sstream>
#include <stdexcept>

enum RHSEGDType { Unknown, UInt8, UInt16, UInt32, Float32 };

using namespace std;

namespace CommonTilton
{
// Params class
  class Params 
  {
    public:
    // Constructor and Destructor
      Params(const string& value);
      virtual ~Params();

    // Member functions
      void print_version();
      bool read(const char *param_file);
      void print();

    // Member variables (public)
    /*-- Input image (required) --*/
      string input_image_file;      /*-- USER INPUT IMAGE FILENAME --*/

    /*-- Number of columns in input image data file (required) --*/
      int    ncols;                /*-- USER INPUT PARAMETER --*/

    /*-- Number of rows in input image data file (required) --*/
      int    nrows;                /*-- USER INPUT PARAMETER --*/

      /*-- Number of slices in input image data file (required) --*/
      int    nslices;              /*-- USER INPUT PARAMETER --*/

    /*-- Number of spectral bands in input image data file (optional, default provided) --*/
      int    nbands;		   /*-- USER INPUT PARAMETER --*/

    /*-- Data type of input image data (required) --*/
      RHSEGDType dtype;   	   /*-- USER INPUT PARAMETER --*/

    /*-- Input data mask file (optional, no default provided) --*/
      string mask_file;              /*-- USER INPUT FILENAME --*/
      bool   mask_flag;              /*-- EXISTENCE FLAG --*/

    /*-- Input mask value (optional, default provided) --*/
      int    mask_value;	     /*-- USER INPUT PARAMETER --*/
      bool   mask_value_flag;        /*-- EXISTENCE FLAG --*/

    /*-- Window Size (optional, default provided) --*/
      int window_size;               /*-- USER INPUT PARAMETER --*/

    /*-- Output type (optional, default provided) --*/
      int operation;                 /*-- USER INPUT PARAMETER --*/

    /*-- Output image (required, no default provided) --*/
      string output_image_file;      /*-- USER INPUT IMAGE FILENAME --*/

    /*-- Output mask image (required) --*/
      string output_mask_image_file; /*-- USER INPUT IMAGE FILENAME --*/

    /* Program version */
      string version;                /* -- PROGRAM PARAMETER --*/

    // FRIEND FUNCTIONS and CLASSES

    protected:

    private:
  };

  string process_line(const string& line, const bool& list_flag);

} // CommonTilton

#endif /* PARAMS_H */
