#ifndef WINDOW_3D_H
#define WINDOW_3D_H

using namespace std;

namespace CommonTilton
{

  bool window_3d();
  bool window_3d(float *input_image, unsigned char *input_mask, float *output_image, unsigned char *output_mask);
  float window_3d_average(float *window, unsigned char *window_mask, bool& valid_flag);
  float window_3d_maximum(float *window, unsigned char *window_mask, bool& valid_flag);
  float window_3d_minimum(float *window, unsigned char *window_mask, bool& valid_flag);
  float window_3d_median(float *window, unsigned char *window_mask, bool& valid_flag);

} // CommonTilton

#endif // WINDOW_3D_H

