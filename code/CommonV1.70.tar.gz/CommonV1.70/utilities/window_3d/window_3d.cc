// window_3d.cc

#include "window_3d.h"
#include "params/params.h"
#include <iostream>
#include <float.h>
#include <vector>
#include <algorithm>

// Externals
extern CommonTilton::Params params;


namespace CommonTilton
{
  bool window_3d()
  {
    int col, row, slice, band, index;
    unsigned char *input_mask, *output_mask, *temp_output_mask, *byte_input, *byte_output;
    unsigned short *short_input, *short_output;
    float *float_input, *float_output;
    fstream input_file, output_file;
    int io_size = params.ncols*params.nrows*params.nslices;
    byte_input = byte_output = input_mask = NULL; // To avoid compiler warnings
    short_input = short_output = NULL; // To avoid compiler warnings

  // Allocation and read input mask image (if provided) and allocate output mask image
    if (params.mask_flag)
    {
      input_mask = new unsigned char[io_size];
      input_file.open(params.mask_file.c_str(), ios_base::in | ios_base::binary );
      input_file.read(reinterpret_cast<char *>(input_mask),io_size);
      input_file.close();
    }
    output_mask = new unsigned char[io_size];
    temp_output_mask = new unsigned char[io_size];

  // Allocate and open input image and allocate and open output image
    if (params.dtype == UInt8)
    {
      byte_input = new unsigned char[io_size];
      if (params.operation == 4)
        byte_output = new unsigned char[io_size];
    }
    else if (params.dtype == UInt16)
    {
      short_input = new unsigned short[io_size];
      if (params.operation == 4)
        short_output = new unsigned short[io_size];
    }
    float_input = new float[io_size];
    input_file.open(params.input_image_file.c_str(), ios_base::in | ios_base::binary );
    output_file.open(params.output_image_file.c_str(), ios_base::out | ios_base::binary );
    float_output = new float[io_size];

    cout << "Performing Window Analysis on input image " << params.input_image_file << endl;
    cout << "with ncols = " << params.ncols << ", nrows = " << params.nrows << ", nslices = ";
    cout << params.nslices << " and nbands = " << params.nbands << endl;

   // Initialize output  mask
    for (slice = 0; slice < params.nslices; slice++)
      for (row = 0; row < params.nrows; row++)
        for (col = 0; col < params.ncols; col++)
        {
          index = col + row*params.ncols + slice*params.nrows*params.ncols;
          output_mask[index] = 1;
        }
    for (band = 0; band < params.nbands; band++)
    {
     // Initialize output image and temporary output mask
      for (slice = 0; slice < params.nslices; slice++)
        for (row = 0; row < params.nrows; row++)
          for (col = 0; col < params.ncols; col++)
          {
            index = col + row*params.ncols + slice*params.nrows*params.ncols;
            float_output[index] = 0.0;
            temp_output_mask[index] = 1;
          }
     // Read input image data and call window_3d
      if (params.dtype == UInt8)
      {
        input_file.read(reinterpret_cast<char *>(byte_input),io_size);
        for (slice = 0; slice < params.nslices; slice++)
          for (row = 0; row < params.nrows; row++)
            for (col = 0; col < params.ncols; col++)
            {
              index = col + row*params.ncols + slice*params.nrows*params.ncols;
              float_input[index] = (float) byte_input[index];
            }
      }
      else if (params.dtype == UInt16)
      {
        input_file.read(reinterpret_cast<char *>(short_input),2*io_size);
        for (slice = 0; slice < params.nslices; slice++)
          for (row = 0; row < params.nrows; row++)
            for (col = 0; col < params.ncols; col++)
            {
              index = col + row*params.ncols + slice*params.nrows*params.ncols;
              float_input[index] = (float) short_input[index];
            }
      }
      else // if (params.dtype == Float32)
      {
        input_file.read(reinterpret_cast<char *>(float_input),4*io_size);
      }

      window_3d(float_input,input_mask,float_output,temp_output_mask);

      for (slice = 0; slice < params.nslices; slice++)
        for (row = 0; row < params.nrows; row++)
          for (col = 0; col < params.ncols; col++)
          {
            index = col + row*params.ncols + slice*params.nrows*params.ncols;
            if (temp_output_mask[index] == 0)
              output_mask[index] = 0;
            if (params.dtype == UInt8)
            {
              byte_output[index] = (unsigned char) float_output[index];
            }
            else if (params.dtype == UInt16)
            {
              short_output[index] = (unsigned short) float_output[index];
            }
          }
      if (params.operation == 4)
      {
        if (params.dtype == UInt8)
        {
          output_file.write(reinterpret_cast<char *>(byte_output),io_size);
        }
        else if (params.dtype == UInt16)
        {
          output_file.write(reinterpret_cast<char *>(short_output),2*io_size);
        }
        else // if (params.dtype == Float32)
        {
          output_file.write(reinterpret_cast<char *>(float_output),4*io_size);
        }
      }
      else
      {
        output_file.write(reinterpret_cast<char *>(float_output),4*io_size);
      }
    } // for (band = 0; band < params.nbands; band++)
    output_file.close();
    output_file.open(params.output_mask_image_file.c_str(), ios_base::out | ios_base::binary );
    output_file.write(reinterpret_cast<char *>(output_mask),io_size);
    output_file.close();

    return true;
  }

  bool window_3d(float *input_image, unsigned char *input_mask, float *output_image, unsigned char *output_mask)
  {
    int col, row, slice, local_col, local_row, local_slice, index, window_col, window_row, window_slice, window_index;
    float *window = new float[params.window_size*params.window_size*params.window_size];
    unsigned char *window_mask = new unsigned char[params.window_size*params.window_size*params.window_size];
    float operation_value;
    int window_range = params.window_size/2;
    bool valid_flag;

    for (slice = 0; slice < params.nslices; slice++)
    {
      for (row = 0; row < params.nrows; row++)
      {
        for (col = 0; col < params.ncols; col++)
        {
          for (window_slice = 0; window_slice < params.window_size; window_slice++)
          {
            for (window_row = 0; window_row < params.window_size; window_row++)
            {
              for (window_col = 0; window_col < params.window_size; window_col++)
              {
                window_index = window_col + window_row*params.window_size + window_slice*params.window_size*params.window_size;
                local_slice = slice - window_range + window_slice;
                local_row = row - window_range + window_row;
                local_col = col - window_range + window_col;
                if ((local_slice >= 0) && (local_slice < params.nslices) && 
                    (local_row >= 0) && (local_row < params.nrows) &&
                    (local_col >= 0) && (local_col < params.ncols))
                {
                  window_mask[window_index] = 1;
                  index = local_col + local_row*params.ncols + local_slice*params.nrows*params.ncols;
                  if ((input_mask == NULL) || (input_mask[index] != params.mask_value))
                  {
                    window_mask[window_index] = 1;
                    window[window_index] = input_image[index];
                  }
                  else
                  {
                    window_mask[window_index] = 0;
                  }
                }
                else
                {
                  window_mask[window_index] = 0;
                }
              } // for (window_col = 0; window_col < params.window_size; window_col++)
            } // for (window_row = 0; window_row < params.window_size; window_row++)
          } // for (window_slice = 0; window_slice < params.window_size; window_slice++)
          switch (params.operation)
          {
           // Window Average
            case 1:  operation_value = window_3d_average(window,window_mask,valid_flag);
                     break;
           // Window Maximum
            case 2:  operation_value = window_3d_maximum(window,window_mask,valid_flag);
                     break;
           // Window Minimum
            case 3:  operation_value = window_3d_minimum(window,window_mask,valid_flag);
                     break;
           // Window Median
            case 4:  operation_value = window_3d_median(window,window_mask,valid_flag);
                     break;
           // Invalid
            default: operation_value = 0.0;
                     valid_flag = false;
                     break;
          }
          index = col + row*params.ncols + slice*params.nrows*params.ncols;
          output_image[index] = operation_value;
          output_mask[index] = 0;
          if (valid_flag)
            output_mask[index] = 1;
        } // for (col = 0; col < params.ncols; col++)
      } // for (row = 0; row < params.nrows; row++)
    } // for (slice = 0; slice < params.nslices; slice++)

    return true;
  }

  float window_3d_average(float *window, unsigned char *window_mask, bool& valid_flag)
  {
    int col, row, slice, index;
    float dnpix, dsum, window_value;

    dnpix = 0.0;
    dsum = 0.0;
    for (slice = 0; slice < params.window_size; slice++)
    {
      for (row = 0; row < params.window_size; row++)
      {
        for (col = 0; col < params.window_size; col++)
        {
          index = col + row*params.window_size + slice*params.window_size*params.window_size;
          if (window_mask[index] == 1)
          {
            dnpix += 1.0;
            dsum += window[index];
          }
        }
      }
    }

    if (dnpix > 0.0)
    {
      window_value = dsum/dnpix;
      valid_flag = true;
    }
    else
    {
      window_value = 0.0;
      valid_flag = false;
    }

    return window_value;
  }

  float window_3d_maximum(float *window, unsigned char *window_mask, bool& valid_flag)
  {
    int col, row, slice, index, npix;
    float window_value;

    npix = 0;
    window_value = -FLT_MAX;
    for (slice = 0; slice < params.window_size; slice++)
    {
      for (row = 0; row < params.window_size; row++)
      {
        for (col = 0; col < params.window_size; col++)
        {
          index = col + row*params.window_size + slice*params.window_size*params.window_size;
          if (window_mask[index] == 1)
          {
            npix++;
            if (window[index] > window_value)
              window_value = window[index];
          }
        }
      }
    }

    if (npix > 0)
      valid_flag = true;
    else
      valid_flag = false;

    return window_value;
  }

  float window_3d_minimum(float *window, unsigned char *window_mask, bool& valid_flag)
  {
    int col, row, slice, index, npix;
    float window_value;

    npix = 0;
    window_value = FLT_MAX;
    for (slice = 0; slice < params.window_size; slice++)
    {
      for (row = 0; row < params.window_size; row++)
      {
        for (col = 0; col < params.window_size; col++)
        {
          index = col + row*params.window_size + slice*params.window_size*params.window_size;
          if (window_mask[index] == 1)
          {
            npix++;
            if (window[index] < window_value)
              window_value = window[index];
          }
        }
      }
    }

    if (npix > 0)
      valid_flag = true;
    else
      valid_flag = false;

    return window_value;
  }

  float window_3d_median(float *window, unsigned char *window_mask, bool& valid_flag)
  {
    int col, row, slice, index, npix, mid_index;
    float window_value;
    vector<float> data_vector;

    npix = 0;
    for (slice = 0; slice < params.window_size; slice++)
    {
      for (row = 0; row < params.window_size; row++)
      {
        for (col = 0; col < params.window_size; col++)
        {
          index = col + row*params.window_size + slice*params.window_size*params.window_size;
          if (window_mask[index] == 1)
          {
            npix++;
            data_vector.push_back(window[index]);
          }
        }
      }
    }

    if (npix > 0)
    {
      valid_flag = true;
      sort(data_vector.begin(),data_vector.end());
      mid_index = npix/2;
      window_value = data_vector[mid_index];
    }
    else
    {
      valid_flag = false;
      window_value = 0.0;
    }

    return window_value;
  }

} // CommonTilton

