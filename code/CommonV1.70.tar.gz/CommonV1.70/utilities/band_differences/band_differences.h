#ifndef BANDDIFF_H
#define BANDDIFF_H

#define MASK_VALUE 0

using namespace std;

namespace CommonTilton
{

  bool band_differences();

} // CommonTilton

#endif // BANDDIFF_H

