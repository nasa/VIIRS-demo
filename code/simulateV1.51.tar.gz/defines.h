#ifndef DEFINES_H
#define DEFINES_H

#define MODIS
//#undef MODIS  // Undefine MODIS if VIIRS (not MODIS) is to be analyzed

#define J1
#undef J1  // Undefine J1 if SNPP VIIRS is to be analyzed

// Comment out (with //) all values of SWATH_SIZE except the desired value.
#ifdef MODIS
#define SWATH_SIZE    40 // Number of rows in a 250m resolution MODIS swath
//#define SWATH_SIZE    20 // Number of rows in a 500m resolution MODIS swath
//#define SWATH_SIZE    10 // Number of rows in a 1km resolution MODIS swath
#else // Analyze VIIRS data
//#define SWATH_SIZE    16 // Maximum number of rows in an NPP VIIRS data swath for Mbands or DNB
//#define SWATH_SIZE    32 // Maximum number of rows in an NPP VIIRS data swath for Ibands
#define DNB
#undef DNB // Undefine if not processing NPP VIIRS or J1 DNB
#endif

#define COLUMN_FACTOR  4  // Number of columns in simulated subset will be COLUMN_FACTOR*SWATH_SIZE
#define SUBSET_PCT    25  // Percentage of pixels that need to be valid in a subset to compute the correlation factor
#define TIME_SIZE     26  // Dimension size for vector used in timing buffer string
#define PI            3.14159265358

#endif // DEFINES_H
