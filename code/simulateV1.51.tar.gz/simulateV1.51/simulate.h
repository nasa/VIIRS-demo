#ifndef SIMULATE_H
#define SIMULATE_H

#include <defines.h>
#include <string>
#include <sstream>
#include <stdexcept>
#include <gdal_priv.h>
#include <proj_api.h>
#include <ogr_spatialref.h>

//#define NBINS 64 // Number quantization bins for Mutual Information step - 64 => 6-bits
//#define NBINS_SQRD 4096 // NBINS squared
//#define NBINS 128 // Number quantization bins for Mutual Information step - 128 => 7-bits
//#define NBINS_SQRD 16384 // NBINS squared
//#define NBINS 256 // Number quantization bins for Mutual Information step - 256 => 8-bits
//#define NBINS_SQRD 65536 // NBINS squared
//#define NBINS 512 // Number quantization bins for Mutual Information step - 512 => 9-bits
//#define NBINS_SQRD 262144 // NBINS squared
//#define NBINS 1024 // Number quantization bins for Mutual Information step - 1024 => 10-bits
//#define NBINS_SQRD 1048576 // NBINS squared
//#define NBINS 2048 // Number quantization bins for Mutual Information step - 2048 => 11-bits
//#define NBINS_SQRD 4194304 // NBINS squared
#define NBINS 4096 // Number quantization bins for Mutual Information step - 2048 => 12-bits
#define NBINS_SQRD 16777216 // NBINS squared
//#define NBINS 8192 // Number quantization bins for Mutual Information step - 2048 => 13-bits
//#define NBINS_SQRD 67108864 // NBINS squared
//#define NBINS 16384 // Number quantization bins for Mutual Information step - 2048 => 14-bits
//#define NBINS_SQRD 268435456 // NBINS squared

using namespace std;

namespace NPP_VIIRS
{

  bool simulate(GDALDataset *inputds, GDALDataset *latitudeds, GDALDataset *longitudeds,
#ifdef MODIS
                GDALDataset *scands, GDALDataset *trackds,
                const projPJ& pj_latlong, const projPJ& pj_utm,
                GDALDataset *water_maskds, float *OLI_image, unsigned char *OLI_mask);
#else
                const projPJ& pj_latlong, const projPJ& pj_utm,
                GDALDataset *water_maskds, GDALDataset *cloud_maskds, float *OLI_image, unsigned char *OLI_mask);
#endif

  void get_I_type_weights(const int& n, const double& r, int& itype, double& wgt1, double& wgt2);
  void get_II_type_weights(const int& n, const double& r, int& itype, double& wgt1, double& wgt2);
  void get_III_type_weights(const int& n, const double& r, int& itype, double& wgt1, double& wgt2);

  void normalize_image(float *image_data);
  void quantize_image(float *image_data);
  float calc_correlation(float *fixed_data, float *shift_data);
  float calc_cross_corr(float *fixed_data, float *shift_data);
  float calc_nmi(float *fixed_data, float *shift_data);

  class BadConversion : public std::runtime_error
  {
    public:
      BadConversion(const std::string& s)
        : std::runtime_error(s)
        { }
  };

  inline std::string stringify_int(int x)
  {
    std::ostringstream o;
    if (!(o << x))
      throw BadConversion("stringify_int(int)");
    return o.str();
  }

  void do_simulation(const int& col_offset, const int& row_offset, float *OLI_image,
                     double *UTM_X_subset, double *UTM_Y_subset, double *int_func, float *input_simulated_subset);

  void lat_long_to_utm(const projPJ& pj_latlong, const projPJ& pj_utm, 
                       const double& latitude, const double& longitude,
                       double& UTM_X, double& UTM_Y);
  void utm_to_lat_long(const projPJ& pj_latlong, const projPJ& pj_utm, 
                       const double& UTM_X, const double& UTM_Y,
                       double& latitude, double& longitude);

  void utm_x_y_to_col_row(const double& UTM_X, const double& UTM_Y, 
                          const double& X_offset, const double& Y_offset,
                          const double& X_gsd, const double& Y_gsd,
                          int& col, int& row);
  void utm_col_row_to_x_y(const int& col, const int& row,
                          const double& X_offset, const double& Y_offset,
                          const double& X_gsd, const double& Y_gsd,
                          double& UTM_X, double& UTM_Y);

  double offset_for_rounding(const double& value);

#ifdef MODIS
  void find_hkm_lat_long(float *km_latitude, float *km_longitude,
                         float *scan_offset, float *track_offset,
                         const int& km_ncols, const int& km_nrows,
                         const int& hkm_ncols, const int& hkm_nrows,
                         double *hkm_latitude, double *hkm_longitude);

  void find_input_lat_long(double *hkm_latitude, double *hkm_longitude,
                           const int& hkm_ncols, const int& hkm_nrows,
                           double *input_latitude, double *input_longitude);
#endif

} // NPP_VIIRS

#endif // SIMULATE_H
