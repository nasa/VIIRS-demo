#ifndef PARAMS_H
#define PARAMS_H

#include <defines.h>
#include <string>
#include <gdal_priv.h>

using namespace std;

namespace NPP_VIIRS
{

  class Params 
  {
    public:
    // Constructor and Destructor
      Params(const string& value);
      virtual ~Params();

    // Member functions
      void print_version();
      bool read(const char *param_file);
#ifndef MODIS
#ifdef DNB
      void find_column_offset();
#else
      void find_aggregation_zone();
#endif
#endif
      void print();

    // Member variables (public)
      string version;			     /* -- PROGRAM PARAMETER --*/

#ifdef MODIS
    /*-- Input single band MODIS reflectance image file (required) --*/
      string   MODIS_reflectance_image_file; /*-- INPUT IMAGE FILE NAME --*/
#else
    /*-- Input single band VIIRS radiance image file (required) --*/
      string   VIIRS_radiance_image_file;    /*-- INPUT IMAGE FILE NAME --*/
#endif

    /*-- Input latitude image data file (required) --*/
      string   latitude_image_file;	     /*-- INPUT IMAGE FILE NAME --*/

    /*-- Input longitude image data file (required) --*/
      string   longitude_image_file;	     /*-- INPUT IMAGE FILE NAME --*/

#ifdef MODIS
    /*-- Input scan offset image file (required) -- */
      string   scan_offset_image_file;       /*-- INPUT IMAGE FILE NAME --*/

    /*-- Input track offset image file (required) -- */
      string   track_offset_image_file;      /*-- INPUT IMAGE FILE NAME --*/
#endif
    /*-- Input water mask image data file (required) --*/
      string   water_mask_file;		     /*-- INPUT IMAGE FILE NAME --*/

    /*-- Input cloud_mask image data file (required) --*/
      string   cloud_mask_file;		     /*-- INPUT IMAGE FILE NAME --*/
      bool     cloud_mask_flag;              /*-- EXISTENCE FLAG --*/

    /*-- Scan number for VIIRS or MODIS image subset simulated (required) --*/
      int scan;                              /*-- USER INPUT PARAMETER --*/
      int row_offset;                        /*-- PROGRAM PARAMETER --*/

    /*-- Water pixel ratio threshold (optional, default provided) --*/
      float water_threshold;                 /*-- USER INPUT PARAMETER --*/

    /*-- Cloud pixel ratio threshold (optional, default provided) --*/
      float cloud_threshold;                 /*-- USER INPUT PARAMETER --*/

    /*-- Number of columns for VIIRS or MODIS image subset simulated (defaulted) --*/
      int ncols;                             /*-- DEFAULTED PROGRAM PARAMETER --*/

    /*-- Number of rows for VIIRS or MODIS image subset simulated (defaulted) --*/
      int nrows;                             /*-- DEFAULTED PROGRAM PARAMETER --*/

#ifndef MODIS
    /*-- VIIRS aggregation zone for selected image subset (optional for DNB, defaulted otherwise) --*/
      int aggregation_zone;                  /*-- USER INPUT PARAMETER (for DNB) or PROGRAM PARAMETER (otherwise) --*/
      bool aggregation_zone_flag;	     /*-- EXISTENCE FLAG --*/
      int best_aggregation_zone;             /*-- PROGRAM PARAMETER --*/
#ifdef DNB
    /*-- Start scan flag for VIIRS DNB image subset (optional) --*/
      bool start_scan_flag;                  /*-- USER INPUT PARAMETER --*/
      bool best_start_scan_flag;             /*-- PROGRAM PARAMETER --*/
#endif
#endif

    /*-- Starting column offset for VIIRS or MODIS image subset simulated (optional, and defaulted for DNB) --*/
      int column_offset;                     /*-- USER INPUT PARAMETER --*/
      bool column_offset_flag;               /*-- EXISTENCE FLAG --*/
      int best_column_offset;                /*-- PROGRAM PARAMETER --*/

    /*-- Minimum column offset for VIIRS or MODIS image subset simulated (optional) --*/
      int min_column_offset;                 /*-- USER INPUT PARAMETER --*/
      bool min_column_offset_flag;           /*-- EXISTENCE FLAG --*/

    /*-- Maximum column offset for VIIRS or MODIS image subset simulated (optional) --*/
      int max_column_offset;                 /*-- USER INPUT PARAMETER --*/
      bool max_column_offset_flag;           /*-- EXISTENCE FLAG --*/

    /*-- Input single band Landsat OLI image file (required) --*/
      string   Landsat_OLI_image_file;	     /*-- INPUT IMAGE FILE NAME--*/

    /*-- Input single band Landsat OLI image mask file (required) --*/
      string   Landsat_OLI_mask_file;	     /*-- INPUT IMAGE MASK FILE NAME--*/

    /*-- Initial column shift Landsat OLI image (optional, default provided) --*/
      int OLI_column_shift;                  /*-- USER INPUT PARAMETER --*/

    /*-- Initial row shift Landsat OLI image (optional, default provided) --*/
      int OLI_row_shift;                     /*-- USER INPUT PARAMETER --*/

    /*-- Number of pixel shifts of Landsat OLI image in each direction (optional, default provided) --*/
      int number_OLI_shifts;                 /*-- USER INPUT PARAMETER --*/

    /*-- Correlation type (optional, default provided) --*/
      int corr_type;                         /*-- USER INPUT PARAMETER --*/

    /*-- Minimum best correlation (optional, default provided) --*/
      float min_corr_peak;                   /*-- USER INPUT PARAMETER --*/

    /*-- Output Landsat OLI image subset file (required) --*/
      string   Landsat_OLI_subset_image_file; /*-- OUTPUT IMAGE FILE NAME --*/

#ifdef MODIS
    /*-- Output MODIS image subset file (required) --*/
      string   MODIS_subset_image_file;      /*-- OUTPUT IMAGE FILE NAME --*/

    /*-- Output simulated MODIS image file (required) --*/
      string   simulated_MODIS_image_file;   /*-- OUTPUT IMAGE FILE NAME --*/
#else
    /*-- Output VIIRS image subset file (required) --*/
      string   VIIRS_subset_image_file;      /*-- OUTPUT IMAGE FILE NAME --*/

    /*-- Output simulated VIIRS image file (required) --*/
      string   simulated_VIIRS_image_file;   /*-- OUTPUT IMAGE FILE NAME --*/
#endif

    /*-- Scale factors --*/
      int      X_scale_factor;               /*-- PROGRAM PARAMETER --*/
      int      Y_scale_factor;               /*-- PROGRAM PARAMETER --*/

    /*-- Landsat OLI program parameters --*/
      int      OLI_ncols, OLI_nrows;         /*-- PROGRAM PARAMETERS --*/
      double   OLI_X_offset, OLI_Y_offset;   /*-- PROGRAM PARAMETERS --*/
      double   OLI_X_gsd, OLI_Y_gsd;         /*-- PROGRAM PARAMETERS --*/
      double   min_OLI_X, max_OLI_X;         /*-- PROGRAM PARAMETERS --*/
      double   min_OLI_Y, max_OLI_Y;         /*-- PROGRAM PARAMETERS --*/
      GDALDataType OLI_data_type;            /*-- PROGRAM PARAMETER --*/
      GDALDriver *OLI_driver;                /*-- PROGRAM PARAMETER --*/

    /*-- Other program parameters --*/
      int   best_col_offset;                 /*-- PROGRAM PARAMETER --*/
      int   best_row_offset;                 /*-- PROGRAM PARAMETER --*/
      float best_correlation;                /*-- PROGRAM PARAMETER --*/

#ifndef MODIS
#ifdef DNB
      int DNB_Zones[33];  // Aggregation Zone 1 (index = 0) is split into two zones - giving and extra aggregation zone
#else
      int Agg_Zones[5];
#endif
#endif

    protected:

    private:
  };

  string process_line(const string& line, const bool& list_flag);

} // NPP_VIIRS

#endif /* PARAMS_H */
