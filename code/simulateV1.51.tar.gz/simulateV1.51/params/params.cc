// params.cc

#include "params.h"
#include <defines.h>
#include <iostream>
#include <cstdlib>
#include <fstream>

namespace NPP_VIIRS
{

 // Constructor
  Params::Params(const string& value)
  {
    version = value;
    cloud_mask_flag = false;
#ifndef MODIS
    aggregation_zone_flag = false;
#endif
    nrows = SWATH_SIZE;
    water_threshold = 0.2;
    cloud_threshold = 0.1;
    OLI_column_shift = 0;
    OLI_row_shift = 0;
    number_OLI_shifts = 1;
    corr_type = 1;
    min_corr_peak = 0.5;
    column_offset_flag = false;
    min_column_offset_flag = false;
    max_column_offset_flag = false;
#ifndef MODIS
#ifdef DNB
    start_scan_flag = true;
    DNB_Zones[0] = 92;  // Aggregation Zone 1 is split into two equal sized zones (index 0 and 1).
    DNB_Zones[1] = 92;
    DNB_Zones[2] = 72;
    DNB_Zones[3] = 88;
    DNB_Zones[4] = 72;
    DNB_Zones[5] = 80;
    DNB_Zones[6] = 72;
    DNB_Zones[7] = 64;
    DNB_Zones[8] = 64;
    DNB_Zones[9] = 64;
    DNB_Zones[10] = 64;
    DNB_Zones[11] = 64;
    DNB_Zones[12] = 80;
    DNB_Zones[13] = 56;
    DNB_Zones[14] = 80;
    DNB_Zones[15] = 72;
    DNB_Zones[16] = 72;
    DNB_Zones[17] = 72;
    DNB_Zones[18] = 32;
    DNB_Zones[19] = 48;
    DNB_Zones[20] = 32;
#ifdef J1
  // The "start scan" 21st aggregation zone has 456 columns and
  // and the "end scan" 21st aggregation zone has 736 columns.
  // These aggregation zones are divided up into smaller sections below.
  // This results in 27 aggregation zones instead of 21 for the start scan
  // and 31 aggregation zones for the end scan.
    DNB_Zones[21] = 64;
    DNB_Zones[22] = 64;
    DNB_Zones[23] = 64;
    DNB_Zones[24] = 64;
    DNB_Zones[25] = 64;
    DNB_Zones[26] = 64;
    DNB_Zones[27] = 72;  // Last zone for start scan
    DNB_Zones[28] = 64;  // Zones 28 through 31 are good only for end scan
    DNB_Zones[29] = 64;
    DNB_Zones[30] = 64;
    DNB_Zones[31] = 88;  // Last zone for end scan (DNB_Zones[32] is undefined)
#else
    DNB_Zones[21] = 48;
    DNB_Zones[22] = 40;
    DNB_Zones[23] = 56;
    DNB_Zones[24] = 40;
    DNB_Zones[25] = 72;
    DNB_Zones[26] = 24;
    DNB_Zones[27] = 32;
    DNB_Zones[28] = 64;
    DNB_Zones[29] = 64;
    DNB_Zones[30] = 64;
    DNB_Zones[31] = 16;
    DNB_Zones[32] = 80;
#endif // !J1
#else
    Agg_Zones[0] = 640;
    Agg_Zones[1] = 368;
    Agg_Zones[2] = 1184;
    Agg_Zones[3] = 368;
    Agg_Zones[4] = 640;
#endif
#endif // #ifndef MODIS
    return;
  }

 // Destructor...
  Params::~Params() 
  {
    return;
  }

 // Print version
  void Params::print_version( )
  {
    cout << endl << version << endl << endl;

    return;
  }

 // Read parameters
  bool Params::read(const char *param_file)
  {
#ifdef MODIS
    if ((SWATH_SIZE != 40) && (SWATH_SIZE != 20) && (SWATH_SIZE != 10))
      return false;
#else
    if ((SWATH_SIZE != 32) && (SWATH_SIZE != 16))
      return false;
#endif

//    cout << endl << "Parameters to be read from file " << param_file << endl << endl;
    ifstream param_fs(param_file);
    if (!param_fs.is_open())
    {
      cout << "Cannot open input file " << param_file << endl;
      return false;
    }

  // Read parameters from parameter file until End-of-File reached
#ifdef MODIS
    bool MODIS_reflectance_image_flag = false;
#else
    bool VIIRS_radiance_image_flag = false;
#endif
    bool latitude_image_flag = false;
    bool longitude_image_flag = false;
#ifdef MODIS
    bool scan_offset_image_flag = false;
    bool track_offset_image_flag = false;
#endif
    bool water_mask_flag = false;
    bool scan_flag = false;
    bool Landsat_OLI_image_flag = false;
    bool Landsat_OLI_mask_flag = false;
    bool Landsat_OLI_subset_image_flag = false;
#ifdef MODIS
    bool MODIS_subset_image_flag = false;
    bool simulated_MODIS_image_flag = false;
#else
    bool VIIRS_subset_image_flag = false;
    bool simulated_VIIRS_image_flag = false;
#endif
    int sub_pos;
    string line, sub_string;
    while (!param_fs.eof())
    {
      getline(param_fs,line);
      sub_pos = line.find("-");
      while ((!param_fs.eof()) && (sub_pos != 0))
      {
        getline(param_fs,line);
        sub_pos = line.find("-");
      }
#ifdef MODIS
      if (line.find("-MODIS_reflectance_image") != string::npos)
      {
        MODIS_reflectance_image_file = process_line(line,false);
        MODIS_reflectance_image_flag = true;
      }
#else
      if (line.find("-VIIRS_radiance_image") != string::npos)
      {
        VIIRS_radiance_image_file = process_line(line,false);
        VIIRS_radiance_image_flag = true;
      }
#endif
      if (line.find("-latitude_image") != string::npos)
      {
        latitude_image_file = process_line(line,false);
        latitude_image_flag = true;
      }
      if (line.find("-longitude_image") != string::npos)
      {
        longitude_image_file = process_line(line,false);
        longitude_image_flag = true;
      }
#ifdef MODIS
      if (SWATH_SIZE != 10)
      {
        if (line.find("-scan_offset_image") != string::npos)
        {
          scan_offset_image_file = process_line(line,false);
          scan_offset_image_flag = true;
        }
        if (line.find("-track_offset_image") != string::npos)
        {
          track_offset_image_file = process_line(line,false);
          track_offset_image_flag = true;
        }
      }
#endif
      if (line.find("-water_mask") != string::npos)
      {
        water_mask_file = process_line(line,false);
        water_mask_flag = true;
      }
      if (line.find("-cloud_mask") != string::npos)
      {
        cloud_mask_file = process_line(line,false);
        cloud_mask_flag = true;
      }
      if (line.find("-scan") != string::npos)
      {
        sub_string = process_line(line,false);
        scan = atoi(sub_string.c_str());
        scan_flag = true;
      }
#ifndef MODIS
      if (line.find("-aggregation_zone") != string::npos)
      {
        sub_string = process_line(line,false);
        aggregation_zone = atoi(sub_string.c_str());
        aggregation_zone_flag = true;
      }
#ifdef DNB
      if (line.find("-start_scan_flag") != string::npos)
      {
        sub_string = process_line(line,false);
        sub_pos = atoi(sub_string.c_str());
        if (sub_pos == 1)
          start_scan_flag = true;
        else
          start_scan_flag = false;
      }
#endif
#endif
      if (line.find("-column_offset") != string::npos)
      {
        sub_string = process_line(line,false);
        column_offset = atoi(sub_string.c_str());
        column_offset_flag = true;
      }
      if (line.find("-min_column_offset") != string::npos)
      {
        sub_string = process_line(line,false);
        min_column_offset = atoi(sub_string.c_str());
        min_column_offset_flag = true;
      }
      if (line.find("-max_column_offset") != string::npos)
      {
        sub_string = process_line(line,false);
        max_column_offset = atoi(sub_string.c_str());
        max_column_offset_flag = true;
      }
      if (line.find("-water_threshold") != string::npos)
      {
        sub_string = process_line(line,false);
        water_threshold = atof(sub_string.c_str());
      }
      if (line.find("-cloud_threshold") != string::npos)
      {
        sub_string = process_line(line,false);
        cloud_threshold = atof(sub_string.c_str());
      }
      if (line.find("-Landsat_OLI_image") != string::npos)
      {
        Landsat_OLI_image_file = process_line(line,false);
        Landsat_OLI_image_flag = true;
      }
      if (line.find("-Landsat_OLI_mask") != string::npos)
      {
        Landsat_OLI_mask_file = process_line(line,false);
        Landsat_OLI_mask_flag = true;
      }
      if (line.find("-OLI_column_shift") != string::npos)
      {
        sub_string = process_line(line,false);
        OLI_column_shift = atoi(sub_string.c_str());
      }
      if (line.find("-OLI_row_shift") != string::npos)
      {
        sub_string = process_line(line,false);
        OLI_row_shift = atoi(sub_string.c_str());
      }
      if (line.find("-number_OLI_shifts") != string::npos)
      {
        sub_string = process_line(line,false);
        number_OLI_shifts = atoi(sub_string.c_str());
      }
      if (line.find("-corr_type") != string::npos)
      {
        sub_string = process_line(line,false);
        corr_type = atoi(sub_string.c_str());
      }
      if (line.find("-min_corr_peak") != string::npos)
      {
        sub_string = process_line(line,false);
        min_corr_peak = atof(sub_string.c_str());
      }
      if (line.find("-Landsat_OLI_subset_image") != string::npos)
      {
        Landsat_OLI_subset_image_file = process_line(line,false);
        Landsat_OLI_subset_image_flag = true;
      }
#ifdef MODIS
      if (line.find("-MODIS_subset_image") != string::npos)
      {
        MODIS_subset_image_file = process_line(line,false);
        MODIS_subset_image_flag = true;
      }
      if (line.find("-simulated_MODIS_image") != string::npos)
      {
        simulated_MODIS_image_file = process_line(line,false);
        simulated_MODIS_image_flag = true;
      }
#else
      if (line.find("-VIIRS_subset_image") != string::npos)
      {
        VIIRS_subset_image_file = process_line(line,false);
        VIIRS_subset_image_flag = true;
      }
      if (line.find("-simulated_VIIRS_image") != string::npos)
      {
        simulated_VIIRS_image_file = process_line(line,false);
        simulated_VIIRS_image_flag = true;
      }
#endif
    }
    param_fs.close();

  // Exit with false status if a required parameter is not set, or an improper parameter
  // setting is detected.
#ifdef MODIS
    if (MODIS_reflectance_image_flag == false)
    {
      cout << "ERROR: -MODIS_reflectance_image (Input MODIS reflectance image file name) is required" << endl;
      return false;
    }
#else
    if (VIIRS_radiance_image_flag == false)
    {
      cout << "ERROR: -VIIRS_radiance_image (Input VIIRS radiance image file name) is required" << endl;
      return false;
    }
#endif
    if (latitude_image_flag == false)
    {
      cout << "ERROR: -latitude_image (Input latitude image file name) is required" << endl;
      return false;
    }
    if (longitude_image_flag == false)
    {
      cout << "ERROR: -longitude_image (Input longitude image file name) is required" << endl;
      return false;
    }
#ifdef MODIS
    if (SWATH_SIZE != 10)
    {
      if (scan_offset_image_flag == false)
      {
        cout << "ERROR: -scan_offset_image (Input scan offset image file name) is required" << endl;
        return false;
      }
      if (track_offset_image_flag == false)
      {
        cout << "ERROR: -track_offset_image (Input track offset image file name) is required" << endl;
        return false;
      }
    }
#endif
    if (scan_flag)
    {
      row_offset = SWATH_SIZE*scan;
    }
    else
    {
#ifdef MODIS
      cout << "ERROR: -scan (Scan number for MODIS image subset simulated) is required" << endl;
#else
      cout << "ERROR: -scan (Scan number for VIIRS image subset simulated) is required" << endl;
#endif
      return false;
    }
#ifdef MODIS
    ncols = COLUMN_FACTOR*SWATH_SIZE;
#else
#ifdef DNB
    if (aggregation_zone_flag)
    {
      // Determine the column_offset and ncols for requested aggregation zone
      find_column_offset();
      column_offset_flag = true;
    }
#else // Need to determine aggregation zone for selected column_offset and ncols
    if (column_offset_flag)
    {
      find_aggregation_zone();
      if (!aggregation_zone_flag)
      {
        cout << "ERROR: Aggregation Zone could not be determined from provided column_offset (= " << column_offset << ")" << endl;
        cout << "The subset most likely straddles two aggregation zones." << endl;
        return false;
      }
    }
#endif
#endif // !MODIS
#ifdef MODIS
    if (column_offset_flag)
    {
      if (SWATH_SIZE == 40)
      {
        if (column_offset != (4*(column_offset/4)))
        {
          cout << "ERROR: -column_offset must be a multiple of 4." << endl;
          return false;
        }
      }
      else if (SWATH_SIZE == 20)
      {
        if (column_offset != (2*(column_offset/2)))
        {
          cout << "ERROR: -column_offset must be a multiple of 2." << endl;
          return false;
        }
      }
    }
#endif
    if (water_mask_flag == false)
    {
      cout << "ERROR: -water_mask (Input water mask file name) is required" << endl;
      return false;
    }
/*
    if (cloud_mask_flag == false)
    {
      cout << "ERROR: -cloud_mask (Input cloud mask file name) is required" << endl;
      return false;
    }
*/
    if (Landsat_OLI_image_flag == false)
    {
      cout << "ERROR: -Landsat_OLI_image (Input Landsat OLI image file name) is required" << endl;
      return false;
    }
    if (Landsat_OLI_mask_flag == false)
    {
      cout << "ERROR: -Landsat_OLI_mask (Input Landsat OLI image mask file name) is required" << endl;
      return false;
    }
    if ((corr_type < 1) || (corr_type > 2))
    {
      cout << "ERROR: -corr_type (Correlation type). Invalid value (" << corr_type << ")specified" << endl;
      return false; 
    }
    if (Landsat_OLI_subset_image_flag == false)
    {
      cout << "ERROR: -Landsat_OLI_subset_image (Output Landsat OLI image subset file name) is required" << endl;
      return false;
    }
#ifdef MODIS
    if (MODIS_subset_image_flag == false)
    {
      cout << "ERROR: -MODIS_subset_image (Output MODIS image subset file name) is required" << endl;
      return false;
    }
    if (simulated_MODIS_image_flag == false)
    {
      cout << "ERROR: -simulated_MODIS_image (Output simulated MODIS image file name) is required" << endl;
      return false;
    }
#else
    if (VIIRS_subset_image_flag == false)
    {
      cout << "ERROR: -VIIRS_subset_image (Output VIIRS image subset file name) is required" << endl;
      return false;
    }
    if (simulated_VIIRS_image_flag == false)
    {
      cout << "ERROR: -simulated_VIIRS_image (Output simulated VIIRS image file name) is required" << endl;
      return false;
    }
    if (aggregation_zone_flag)
    {
#ifdef DNB
#ifdef J1
      if (start_scan_flag)
      {
        if ((aggregation_zone < 0) || (aggregation_zone > 27))
        {
          cout << "ERROR:  Invalid aggregation zone: " << aggregation_zone << ". Aggregation zone must be in range 0 through 27" << endl;
          cout << "if start_scan_flag = true(1)." << endl;
          return false;
        }
      }
      else
      {
        if ((aggregation_zone < 0) || (aggregation_zone > 31))
        {
          cout << "ERROR:  Invalid aggregation zone: " << aggregation_zone << ". Aggregation zone must be in range 0 through 31" << endl;
          cout << "if start_scan_flag = false(0)." << endl;
          return false;
        }
      }
#else
      if ((aggregation_zone < 0) || (aggregation_zone > 32))
      {
        cout << "ERROR:  Invalid aggregation zone: " << aggregation_zone << ". Aggregation zone must be in range 0 through 32." << endl;
        return false;
      }
#endif // !J1
#else
      if ((aggregation_zone < 1) || (aggregation_zone > 3))
      {
        cout << "ERROR:  Invalid aggregation zone: " << aggregation_zone << ". Aggregation zone must be 1, 2 or 3." << endl;
        return false;
      }
  // Adjust for aggregation zone
      switch (aggregation_zone)
      {
#ifdef Mbands
        case 1:  nrows = nrows - 4;
                 row_offset = row_offset + 2;
                 break;
        case 2:  nrows = nrows - 2;
                 row_offset = row_offset + 1;
                 break;
#else
        case 1:  nrows = nrows - 8;
                 row_offset = row_offset + 4;
                 break;
        case 2:  nrows = nrows - 4;
                 row_offset = row_offset + 2;
                 break;
#endif
        case 3:  // No change
                 break;
        default: return false;
      }
#endif // !DNB
    }
#endif // !MODIS

    return true;
  }

#ifndef MODIS
#ifdef DNB
 // Determine column_offset and ncols from aggregation zone
  void Params::find_column_offset()
  {
    int index;
    column_offset = 0;
    if (start_scan_flag)
    {
#ifdef J1
      column_offset += 8;
      for (index = 27; index > aggregation_zone; index--)
        column_offset += DNB_Zones[index];
#else
      for (index = 32; index > aggregation_zone; index--)
        column_offset += DNB_Zones[index];
#endif
      ncols = DNB_Zones[aggregation_zone];
    }
    else
    {
#ifdef J1
      column_offset += 8;
      for (index = 0; index <= 27; index++)
        column_offset += DNB_Zones[index];
      for (index = 0; index < aggregation_zone; index++)
        column_offset += DNB_Zones[index];
#else
      for (index = 0; index <= 32; index++)
        column_offset += DNB_Zones[index];
      for (index = 0; index < aggregation_zone; index++)
        column_offset += DNB_Zones[index];
#endif
      ncols = DNB_Zones[aggregation_zone];
    }
/*
if (start_scan_flag)
  cout << "In find_column_offset(), start_scan_flag == true, ";
else
  cout << "In find_column_offset(), start_scan_flag == false, ";
cout << "aggregation_zone = " << aggregation_zone << ", column_offset = " << column_offset << " and ncols = " << ncols << endl;
*/
    return;
  }
#else
 // Determine aggregation zone from column_offset and ncols
  void Params::find_aggregation_zone()
  {
    ncols = COLUMN_FACTOR*SWATH_SIZE;
    aggregation_zone_flag = true;
    int swath_factor = SWATH_SIZE/16;
    int zone_column_limit = Agg_Zones[0]*swath_factor;
    if (column_offset < zone_column_limit)
    {
      aggregation_zone = 1;
    }
    else
    {
      zone_column_limit += Agg_Zones[1]*swath_factor;
      if (column_offset < zone_column_limit)
      {
        aggregation_zone = 2;
      }
      else
      {
        zone_column_limit += Agg_Zones[2]*swath_factor;
        if (column_offset < zone_column_limit)
        {
          aggregation_zone = 3;
        }
        else
        {
          zone_column_limit += Agg_Zones[3]*swath_factor;
          if (column_offset < zone_column_limit)
          {
            aggregation_zone = 2;
          }
          else
          {
            zone_column_limit += Agg_Zones[4]*swath_factor;
            if (column_offset < zone_column_limit)
            {
              aggregation_zone = 1;
            }
            else
            {
              aggregation_zone_flag = false;
            }
          }
        }
      }
    }
   // Make sure last column of subset is in the same aggregation zone as the first column
    int last_column = column_offset + ncols - 1;
    zone_column_limit = Agg_Zones[0]*swath_factor;
    if (last_column < zone_column_limit)
    {
      if (aggregation_zone != 1)
        aggregation_zone_flag = false;
    }
    else
    {
      zone_column_limit += Agg_Zones[1]*swath_factor;
      if (last_column < zone_column_limit)
      {
        if (aggregation_zone != 2)
          aggregation_zone_flag = false;
      }
      else
      {
        zone_column_limit += Agg_Zones[2]*swath_factor;
        if (last_column < zone_column_limit)
        {
          if (aggregation_zone != 3)
            aggregation_zone_flag = false;
        }
        else
        {
          zone_column_limit += Agg_Zones[3]*swath_factor;
          if (last_column < zone_column_limit)
          {
            if (aggregation_zone != 2)
              aggregation_zone_flag = false;
          }
          else
          {
            zone_column_limit += Agg_Zones[4]*swath_factor;
            if (last_column < zone_column_limit)
            {
              if (aggregation_zone != 1)
                aggregation_zone_flag = false;
            }
            else
            {
              aggregation_zone_flag = false;
            }
          }
        }
      }
    }

    return;
  }
#endif
#endif

 // Print parameters
  void Params::print()
  {
   // Print version
    cout << "This is " << version << endl << endl;

   // Print input parameters
#ifdef MODIS
    cout << "Input MODIS reflectance image file = " << MODIS_reflectance_image_file << endl;
#else
    cout << "Input VIIRS radiance image file = " << VIIRS_radiance_image_file << endl;
#endif
    cout << "Input latitude image file = " << latitude_image_file << endl;
    cout << "Input longitude image file = " << longitude_image_file << endl;
#ifdef MODIS
    if (SWATH_SIZE != 10)
    {
      cout << "Input scan offset image file = " << scan_offset_image_file << endl;
      cout << "Input track offset image file = " << track_offset_image_file << endl;
    }
    cout << "Scan number for MODIS image subset simulated = " << scan << endl;
    cout << "Number of rows in MODIS image subset simulated = " << nrows << endl;
    if (column_offset_flag)
    {
      cout << "Column offset for MODIS image subset simulated = " << column_offset << endl;
      cout << "Number of columns in MODIS image subset simulated = " << ncols << endl;
    }
    if (min_column_offset_flag)
      cout << "Minimum column offset for MODIS image subset simulated = " << min_column_offset << endl;
    if (max_column_offset_flag)
      cout << "Maximum column offset for MODIS image subset simulated = " << max_column_offset << endl;
#else
    cout << "Scan number for VIIRS image subset simulated = " << scan << endl;
    cout << "Number of rows in VIIRS image subset simulated = " << nrows << endl;
    if (column_offset_flag)
    {
      cout << "Column offset for VIIRS image subset simulated = " << column_offset << endl;
      cout << "Number of columns in VIIRS image subset simulated = " << ncols << endl;
    }
    if (min_column_offset_flag)
      cout << "Minimum column offset for VIIRS image subset simulated = " << min_column_offset << endl;
    if (max_column_offset_flag)
      cout << "Maximum column offset for VIIRS image subset simulated = " << max_column_offset << endl;
    if (aggregation_zone_flag)
      cout << "Aggregation zone of selected VIIRS image subset = " << aggregation_zone << endl;
#endif
    cout << "Input water mask file = " << water_mask_file << endl;
    if (cloud_mask_flag)
      cout << "Input cloud mask file = " << cloud_mask_file << endl;
    cout << "Water threshold = " << water_threshold << endl;
    cout << "Cloud threshold = " << cloud_threshold << endl;
    cout << "Input Landsat OLI image file = " << Landsat_OLI_image_file << endl;
    cout << "Input Landsat OLI image mask file = " << Landsat_OLI_mask_file << endl;
    if (number_OLI_shifts > 1)
    {
      cout << "Initial Landsat OLI column shift (in OLI pixels) = " << OLI_column_shift << endl;
      cout << "Initial Landsat OLI row shift (in OLI pixels) = " << OLI_row_shift << endl;
      cout << "Number of OLI shifts (in OLI pixels) in each direction = " << number_OLI_shifts << endl;
    }
    else
    {
      cout << "Landsat OLI column shift (in OLI pixels) = " << OLI_column_shift << endl;
      cout << "Landsat OLI row shift (in OLI pixels) = " << OLI_row_shift << endl;
    }
    cout << "Correlation type :";
    if (corr_type == 1)
      cout << " Spatial Cross Correlation" << endl;
    else
      cout << " Normalized Mutual Information" << endl;
    cout << "Minimum correlation value for best correlation = " << min_corr_peak << endl;
    cout << "Output Landsat OLI subset image file = " << Landsat_OLI_subset_image_file << endl;
#ifdef MODIS
    cout << "Output MODIS subset image file = " << MODIS_subset_image_file << endl;
    cout << "Output simulated MODIS image file = " << simulated_MODIS_image_file << endl;
#else
    cout << "Output VIIRS subset image file = " << VIIRS_subset_image_file << endl;
    cout << "Output simulated VIIRS image file = " << simulated_VIIRS_image_file << endl;
#endif

    return;
  }

  string process_line(const string& line, const bool& list_flag)
  {
    int sub_pos, sub_pos_space, sub_pos_tab;
    string sub_string;

    sub_pos_space = line.find_first_of(" ");
    sub_pos_tab = line.find_first_of("\t");
    sub_pos = sub_pos_space;
    if (sub_pos ==  (int) string::npos)
      sub_pos = sub_pos_tab;
    if (sub_pos ==  (int) string::npos)
      return " ";

    sub_string = line.substr(sub_pos);
    while ((sub_string.substr(0,1) == "\t") || (sub_string.substr(0,1) == " "))
      sub_string = line.substr(++sub_pos);
#ifndef WINDOWS
    if (list_flag)
      return sub_string;

    sub_pos = sub_string.find_first_of(" ");
    if (sub_pos !=  (int) string::npos)
      sub_string = sub_string.substr(0,sub_pos);
    sub_pos = sub_string.find_first_of("\t");
    if (sub_pos !=  (int) string::npos)
      sub_string = sub_string.substr(0,sub_pos);
    sub_pos = sub_string.find_first_of("\r");
    if (sub_pos !=  (int) string::npos)
      sub_string = sub_string.substr(0,sub_pos);
#endif
    return sub_string;
  }

} // namespace NPP_VIIRS
