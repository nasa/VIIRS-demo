/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<<
   >>>>
   >>>> 	Main program for program to simulate MODIS or NPP VIIRS data from Landsat OLI data
   >>>>
   >>>>  Private:
   >>>> 	main(int argc, char **argv)
   >>>> 	usage()
   >>>> 	help()
   >>>>
   >>>>   Static:
   >>>>   Public:
   >>>>
   >>>>       Written: October 21, 2016 (based on lsf.cc)
   >>>> Modifications: November 3, 2016 - Added cross correlation option
   >>>>                May 15, 2017 - Added MODIS capability (for 1km resolution)
   >>>>                May 25, 2017 - Upgraded MODIS capability to handle all resolutions
   >>>>                July 17, 2017 - Added NPP VIIRS DNB processing capability
   >>>>                August 30, 2017 - Added OLI_column_shift and OLI_row_shift parameters
   >>>>                September 21, 2017 - Corrected DNB Aggregation Zone 0 width
   >>>>                October 5, 2017 - Revised to automatically detect the location of the Landsat OLI image
   >>>>                October 16, 2017 - Added bypass of subsets of VIIRS data straddling two aggregation zones
   >>>>                November 16, 2017 - Added min_corr_peak parameter and associated code
   >>>>		       November 28, 2017 - Added capability to search for optimal OLI_column_shift and OLI_row_shift values
   >>>>                December 14, 2017 - Added min_column_offset and max_column_offset parameters and associated logic
   >>>>                January 19, 2018 - Added table for J1 VIIRS and associated logic
   >>>>                January 20, 2018 - Corrected a programming error that affected the VIIRS I- and M-bands results in
   >>>>                                   in the 1x1 and 2x1 aggregation zones (does not affect the 3x1 aggregation zone)
   >>>>                October 5, 2018 - For VIIRS DNB, split the first aggregation zone into two equal sections.
   >>>>                October 12, 2018 - Corrected bug for VIIRS DNB (related to splitting the first aggregation zone).
   >>>>                November 6, 2018 - Corrected another bug for VIIRS DNB.
   >>>>                March 27, 2019 - Added masking with water mask and cloud mask.
   >>>>                April 5, 2019 - Upgraded to also work with MODIS data (no cloud mask with MODIS)
   >>>>
   >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<< */

#include "params/params.h"
#include "simulate.h"
#include <iostream>

using namespace std;
using namespace NPP_VIIRS;

//Globals
Params params("Version 1.51, April 5, 2019");

// Forward function declarations
void usage();
void help();

int main(int argc, char *argv[])
{
  bool status = true;

  GDALAllRegister();

  if (argc == 1)
  {
    usage();
    cout << "ERROR: Need parameter file as argument." << endl;
    status = false;
  }
  else if ((strncmp(argv[1],"-v",2) == 0) || (strncmp(argv[1],"-version",8) == 0))
  {
    params.print_version();
    cout << "For help information: simulate -h or simulate -help" << endl << endl;
    status = false;
  }
  else if ((strncmp(argv[1],"-h",2) == 0) || (strncmp(argv[1],"-help",5) == 0))
  {
    help();
    status = false;
  }
  else if (strncmp(argv[1],"-",1) == 0)
  {
    usage();
    cout << "The parameter file name cannot start with an \"-\"" << endl;
    status = false;
  }
  else
  {
    if (argc != 2)
    {
      usage();
      cout << "ERROR: Incorrect number of parameters on command line" << endl;
      status = false;
    }
    else
    {
      status = false;
      status = params.read(argv[1]);
      if (!status)
      {
        usage();
        cout << "ERROR: Error reading parameter file (read)" << endl;
        return EXIT_FAILURE;
      }
    }
  }

  if (status)
  {
    params.print();

    int nbands = 1;
    GDALDataset *landsatOLIds;
    GDALRasterBand *rb;
    landsatOLIds = (GDALDataset *)GDALOpen(params.Landsat_OLI_image_file.c_str(), GA_ReadOnly);
    if (!landsatOLIds)
    {
      cout << "ERROR: Could not open Landsat OLI file name = " << params.Landsat_OLI_image_file << endl;
      return EXIT_FAILURE;
    }
    params.OLI_ncols = landsatOLIds->GetRasterXSize();
    params.OLI_nrows = landsatOLIds->GetRasterYSize();
    if (nbands != landsatOLIds->GetRasterCount())
      cout << "WARNING: Multiband Landsat OLI image detected. Will use first band only." << endl;
    params.OLI_data_type = landsatOLIds->GetRasterBand(1)->GetRasterDataType();
    float *OLI_image;
    OLI_image = new float[params.OLI_ncols*params.OLI_nrows];
    rb = landsatOLIds->GetRasterBand(1);
    if (rb->RasterIO(GF_Read, 0, 0, params.OLI_ncols, params.OLI_nrows, &OLI_image[0], params.OLI_ncols, params.OLI_nrows, GDT_Float32, 0, 0)
        == CE_Failure)
    {
      cout << "ERROR: Could not read data from Landsat OLI image." << endl;
      return EXIT_FAILURE;
    }
    params.OLI_driver = landsatOLIds->GetDriver();
    string projection_type = landsatOLIds->GetProjectionRef();
    double imageGeoTransform[6];
    if ( landsatOLIds->GetGeoTransform( imageGeoTransform ) == CE_None )
    {
      params.OLI_X_offset = imageGeoTransform[0];
      params.OLI_Y_offset = imageGeoTransform[3];
      params.OLI_X_gsd = imageGeoTransform[1];
      params.OLI_Y_gsd = imageGeoTransform[5];
      if (params.OLI_X_gsd > 0.0)
      {
        params.min_OLI_X = params.OLI_X_offset;
        params.max_OLI_X = params.OLI_X_offset + params.OLI_X_gsd*params.OLI_ncols;
      }
      else
      {
        params.max_OLI_X = params.OLI_X_offset;
        params.min_OLI_X = params.OLI_X_offset + params.OLI_X_gsd*params.OLI_ncols;
      }
      if (params.OLI_Y_gsd > 0.0)
      {
        params.min_OLI_Y = params.OLI_Y_offset;
        params.max_OLI_Y = params.OLI_Y_offset + params.OLI_Y_gsd*params.OLI_nrows;
      }
      else
      {
        params.max_OLI_Y = params.OLI_Y_offset;
        params.min_OLI_Y = params.OLI_Y_offset + params.OLI_Y_gsd*params.OLI_nrows;
      }
      cout << "min OLI_UTM_X = " << params.min_OLI_X << " and max OLI_UTM_X = " << params.max_OLI_X << endl;
      cout << "min OLI_UTM_Y = " << params.min_OLI_Y << " and max OLI_UTM_Y = " << params.max_OLI_Y << endl;
    }
    else
    {
      cout << "ERROR: Could not obtain GeoTransform information from Landsat OLI image." << endl;
      return EXIT_FAILURE;
    }
    GDALClose( (GDALDatasetH) landsatOLIds);

    OGRSpatialReference landsatOLISpatialReference(projection_type.c_str());
    int north_flag;
    int UTM_zone = landsatOLISpatialReference.GetUTMZone(&north_flag);

    projPJ pj_utm, pj_latlong;
    string pj_utm_string, pj_latlong_string;
    if (north_flag)
      pj_utm_string = "+proj=utm +ellps=WGS84 +zone=" + stringify_int(UTM_zone);
    else
      pj_utm_string = "+proj=utm +ellps=WGS84 +south +zone=" + stringify_int(UTM_zone);
    pj_latlong_string = "+proj=latlong +ellps=WGS84";

    if (!(pj_utm = pj_init_plus(pj_utm_string.c_str())) )
      return EXIT_FAILURE;
    if (!(pj_latlong = pj_init_plus(pj_latlong_string.c_str())) )
      return EXIT_FAILURE;

    landsatOLIds = (GDALDataset *)GDALOpen(params.Landsat_OLI_mask_file.c_str(), GA_ReadOnly);
    if (!landsatOLIds)
    {
      cout << "ERROR: Could not open Landsat OLI mask file name = " << params.Landsat_OLI_mask_file << endl;
      return EXIT_FAILURE;
    }
    if ((params.OLI_ncols != landsatOLIds->GetRasterXSize()) || (params.OLI_nrows != landsatOLIds->GetRasterYSize()))
    {
      cout << "ERROR: Image size mismatch between Landsat OLI image and Landsat OLI mask." << endl;
      return EXIT_FAILURE;
    }
    unsigned char      *OLI_mask;
    OLI_mask = new unsigned char[params.OLI_ncols*params.OLI_nrows];
    rb = landsatOLIds->GetRasterBand(1);
    if (rb->RasterIO(GF_Read, 0, 0, params.OLI_ncols, params.OLI_nrows, &OLI_mask[0], params.OLI_ncols, params.OLI_nrows, GDT_Byte, 0, 0)
        == CE_Failure)
    {
      cout << "ERROR: Could not read data from Landsat OLI image mask." << endl;
      return EXIT_FAILURE;
    }
    GDALClose( (GDALDatasetH) landsatOLIds);

    int input_ncols, input_nrows;
    GDALDataset *inputds, *latitudeds, *longitudeds;
#ifdef MODIS
    GDALDataset *scands, *trackds;
#else
    GDALDataset *cloud_maskds;
#endif
    GDALDataset *water_maskds;

  // Check input VIIRS or MODIS images
#ifdef MODIS
    inputds = (GDALDataset *)GDALOpen(params.MODIS_reflectance_image_file.c_str(), GA_ReadOnly);
#else
    inputds = (GDALDataset *)GDALOpen(params.VIIRS_radiance_image_file.c_str(), GA_ReadOnly);
#endif
    if (!inputds)
    {
#ifdef MODIS
      cout << "ERROR: Could not open MODIS reflectance file name = " << params.MODIS_reflectance_image_file << endl;
#else
      cout << "ERROR: Could not open VIIRS radiance file name = " << params.VIIRS_radiance_image_file << endl;
#endif
      return false;
    }
    input_ncols = inputds->GetRasterXSize();
    input_nrows = inputds->GetRasterYSize();
    if (nbands != inputds->GetRasterCount())
#ifdef MODIS
      cout << "WARNING: Multiband MODIS reflectance image detected. Will use first band only." << endl;
#else
      cout << "WARNING: Multiband VIIRS radiance image detected. Will use first band only." << endl;
#endif

    latitudeds = (GDALDataset *)GDALOpen(params.latitude_image_file.c_str(), GA_ReadOnly);
    if (!latitudeds)
    {
      cout << "ERROR: Could not open latitude file name = " << params.latitude_image_file << endl;
      return false;
    }
#ifdef MODIS
    if (SWATH_SIZE == 40)
    {
      if (((input_ncols/4) != latitudeds->GetRasterXSize()) || ((input_nrows/4) != latitudeds->GetRasterYSize()))
      {
        cout << "ERROR: Image size mismatch between MODIS reflectance and latitude image files." << endl;
        return false;
      }
    }
    else if (SWATH_SIZE == 20)
    {
      if (((input_ncols/2) != latitudeds->GetRasterXSize()) || ((input_nrows/2) != latitudeds->GetRasterYSize()))
      {
        cout << "ERROR: Image size mismatch between MODIS reflectance and latitude image files." << endl;
        return false;
      }
    }
    else
    {
      if ((input_ncols != latitudeds->GetRasterXSize()) || (input_nrows != latitudeds->GetRasterYSize()))
      {
        cout << "ERROR: Image size mismatch between MODIS reflectance and latitude image files." << endl;
        return false;
      }
    }
#else
    if ((input_ncols != latitudeds->GetRasterXSize()) || (input_nrows != latitudeds->GetRasterYSize()))
    {
      cout << "ERROR: Image size mismatch between VIIRS radiance and latitude image files." << endl;
      return false;
    }
#endif
    longitudeds = (GDALDataset *)GDALOpen(params.longitude_image_file.c_str(), GA_ReadOnly);
    if (!longitudeds)
    {
      cout << "ERROR: Could not open longitude file name = " << params.longitude_image_file << endl;
      return false;
    }
#ifdef MODIS
    if (SWATH_SIZE == 40)
    {
      if (((input_ncols/4) != longitudeds->GetRasterXSize()) || ((input_nrows/4) != longitudeds->GetRasterYSize()))
      {
        cout << "ERROR: Image size mismatch between MODIS reflectance and longitude image files." << endl;
        return false;
      }
    }
    else if (SWATH_SIZE == 20)
    {
      if (((input_ncols/2) != longitudeds->GetRasterXSize()) || ((input_nrows/2) != longitudeds->GetRasterYSize()))
      {
        cout << "ERROR: Image size mismatch between MODIS reflectance and longitude image files." << endl;
        return false;
      }
    }
    else
    {
      if ((input_ncols != longitudeds->GetRasterXSize()) || (input_nrows != longitudeds->GetRasterYSize()))
      {
        cout << "ERROR: Image size mismatch between MODIS reflectance and longitude image files." << endl;
        return false;
      }
    }
#else
    if ((input_ncols != longitudeds->GetRasterXSize()) || (input_nrows != longitudeds->GetRasterYSize()))
    {
      cout << "ERROR: Image size mismatch between VIIRS radiance and longitude image files." << endl;
      return false;
    }
#endif
#ifdef MODIS
    if (SWATH_SIZE == 10)
    {
      scands = NULL;
      trackds = NULL;
    }
    else
    {
      scands = (GDALDataset *)GDALOpen(params.scan_offset_image_file.c_str(), GA_ReadOnly);
      trackds = (GDALDataset *)GDALOpen(params.track_offset_image_file.c_str(), GA_ReadOnly);
      if (SWATH_SIZE == 40)
      {
        if (((input_ncols/2) != scands->GetRasterXSize()) || ((input_nrows/2) != scands->GetRasterYSize()))
        {
          cout << "ERROR: Image size mismatch between MODIS reflectance and scan offset image files." << endl;
          return false;
        }
        if (((input_ncols/2) != trackds->GetRasterXSize()) || ((input_nrows/2) != trackds->GetRasterYSize()))
        {
          cout << "ERROR: Image size mismatch between MODIS reflectance and track offset image files." << endl;
          return false;
        }
      }
      else if (SWATH_SIZE == 20)
      {
        if ((input_ncols != scands->GetRasterXSize()) || (input_nrows != scands->GetRasterYSize()))
        {
          cout << "ERROR: Image size mismatch between MODIS reflectance and scan offset image files." << endl;
          return false;
        }
        if ((input_ncols != trackds->GetRasterXSize()) || (input_nrows != trackds->GetRasterYSize()))
        {
          cout << "ERROR: Image size mismatch between MODIS reflectance and track offset image files." << endl;
          return false;
        }
      }
    }
#endif

    water_maskds = (GDALDataset *)GDALOpen(params.water_mask_file.c_str(), GA_ReadOnly);
    if (!water_maskds)
    {
      cout << "ERROR: Could not open water mask file name = " << params.water_mask_file << endl;
      return false;
    }
#ifdef MODIS
    if (SWATH_SIZE == 40)
    {
      if (((input_ncols/4) != water_maskds->GetRasterXSize()) || ((input_nrows/4) != water_maskds->GetRasterYSize()))
      {
        cout << "ERROR: Image size mismatch between MODIS reflectance and water mask image files." << endl;
        return false;
      }
    }
    else if (SWATH_SIZE == 20)
    {
      if (((input_ncols/2) != water_maskds->GetRasterXSize()) || ((input_nrows/2) != water_maskds->GetRasterYSize()))
      {
        cout << "ERROR: Image size mismatch between MODIS reflectance and water mask image files." << endl;
        return false;
      }
    }
    else
    {
      if ((input_ncols != water_maskds->GetRasterXSize()) || (input_nrows != water_maskds->GetRasterYSize()))
      {
        cout << "ERROR: Image size mismatch between MODIS reflectance and water mask image files." << endl;
        return false;
      }
    }
#else
    if ((input_ncols != water_maskds->GetRasterXSize()) || (input_nrows != water_maskds->GetRasterYSize()))
    {
      cout << "ERROR: Image size mismatch between radiance and water mask image files." << endl;
      return false;
    }
#endif
#ifndef MODIS
    if (params.cloud_mask_flag)
    {
      cloud_maskds = (GDALDataset *)GDALOpen(params.cloud_mask_file.c_str(), GA_ReadOnly);
      if (!cloud_maskds)
      {
        cout << "ERROR: Could not open cloud mask file name = " << params.cloud_mask_file << endl;
        return false;
      }
      if ((input_ncols != cloud_maskds->GetRasterXSize()) || (input_nrows != cloud_maskds->GetRasterYSize()))
      {
        cout << "ERROR: Image size mismatch between radiance and cloud mask image files." << endl;
        return false;
      }
    }
    else
      cloud_maskds = NULL;
#endif

    params.best_correlation = 0.0;
    params.best_column_offset = 0;
#ifndef MODIS
    params.best_aggregation_zone = 1;
#ifdef DNB
    params.best_start_scan_flag = true;
#else
    int orig_nrows = params.nrows;
    int orig_row_offset = params.row_offset;
#endif
#endif
    bool found_peak_flag = true;
    if (params.column_offset_flag)
    {
      status = simulate(inputds, latitudeds, longitudeds,
#ifdef MODIS
                        scands, trackds,
                        pj_latlong, pj_utm, water_maskds, OLI_image, OLI_mask);
#else
                        pj_latlong, pj_utm, water_maskds, cloud_maskds, OLI_image, OLI_mask);
#endif
      params.OLI_column_shift = params.best_col_offset;
      params.OLI_row_shift = params.best_row_offset;
    }
    else
    {
     int orig_number_shifts = params.number_OLI_shifts;
     bool redo_flag = true;
     while (redo_flag)
     {
      params.number_OLI_shifts = 1;
#ifdef MODIS
      params.column_offset = 0;
      if (params.min_column_offset_flag)
      {
        while (params.column_offset < params.min_column_offset)
          params.column_offset += 8;
      }
#else
#ifdef DNB
      params.start_scan_flag = true;
#ifdef J1
      params.aggregation_zone = 27;
#else
      params.aggregation_zone = 32;
#endif
      params.find_column_offset();
      if (params.min_column_offset_flag)
      {
        while (params.column_offset < params.min_column_offset)
        {
          if (params.start_scan_flag)
            params.aggregation_zone -= 1;
          else
            params.aggregation_zone += 1;
          if (params.aggregation_zone == -1)
          {
            params.start_scan_flag = false;
            params.aggregation_zone = 0;
          }
#ifdef J1
          if (params.aggregation_zone < 32)
#else
          if (params.aggregation_zone < 33)
#endif
          {
            params.find_column_offset();
          }
          else
            params.column_offset = input_ncols;
        }
      }
#else
      params.column_offset = 0;
      if (params.min_column_offset_flag)
      {
         while (params.column_offset < params.min_column_offset)
           params.column_offset += 8;
      }
      params.find_aggregation_zone();
#endif
#endif
      bool continue_flag = true;
      found_peak_flag = false;
      while ((params.column_offset + params.ncols) < input_ncols)
      {
#ifndef MODIS
#ifndef DNB
        if (params.aggregation_zone_flag)
        {
      // Adjust for aggregation zone
          switch (params.aggregation_zone)
          {
#ifdef Mbands
            case 1:  params.nrows = orig_nrows - 4;
                     params.row_offset = orig_row_offset + 2;
                     break;
            case 2:  params.nrows = orig_nrows - 2;
                     params.row_offset = orig_row_offset + 1;
                     break;
#else
            case 1:  params.nrows = orig_nrows - 8;
                     params.row_offset = orig_row_offset + 4;
                     break;
            case 2:  params.nrows = orig_nrows - 4;
                     params.row_offset = orig_row_offset + 2;
                     break;
#endif
            case 3:  params.nrows = orig_nrows;
                     params.row_offset = orig_row_offset;
                     break;
            default: return false;
          }
#endif
#endif
          status = simulate(inputds, latitudeds, longitudeds,
#ifdef MODIS
                            scands, trackds,
                            pj_latlong, pj_utm, water_maskds, OLI_image, OLI_mask);
#else
                            pj_latlong, pj_utm, water_maskds, cloud_maskds, OLI_image, OLI_mask);
#endif
          if (status)
            found_peak_flag = true;
          if (found_peak_flag && !status)
            continue_flag = false;
#ifndef MODIS
#ifndef DNB
        }
#endif
#endif
        if (continue_flag)
        {
#ifdef MODIS
          params.column_offset += 8;
#else
#ifdef DNB
          if (params.start_scan_flag)
            params.aggregation_zone -= 1;
          else
            params.aggregation_zone += 1;
          if (params.aggregation_zone == -1)
          {
            params.start_scan_flag = false;
            params.aggregation_zone = 0;
          }
#ifdef J1
          if (params.aggregation_zone < 32)
#else
          if (params.aggregation_zone < 33)
#endif
          {
            params.find_column_offset();
          }
          else
            params.column_offset = input_ncols;
#else
          params.column_offset += 8;
          params.find_aggregation_zone();
#endif
#endif
        }
        else
          params.column_offset = input_ncols;
        if ((params.max_column_offset_flag) && (params.column_offset > params.max_column_offset))
          params.column_offset = input_ncols;
      } //  while ((params.column_offset + params.ncols) <= input_ncols)

      redo_flag = false;
      if ((found_peak_flag) && (params.best_correlation > (params.min_corr_peak/2.0)) && (orig_number_shifts > 1))
      {
       // Search for optimal OLI_column_shift and OLI_row_shift and found best column_offset
        params.number_OLI_shifts = orig_number_shifts;
#ifdef MODIS
        params.column_offset = params.best_column_offset;
#else
#ifdef DNB
        params.aggregation_zone = params.best_aggregation_zone;
        params.start_scan_flag = params.best_start_scan_flag;
        params.find_column_offset();
#else
        params.column_offset = params.best_column_offset;
        params.find_aggregation_zone();
#endif
#endif
#ifndef MODIS
#ifndef DNB
      // Adjust for aggregation zone
        switch (params.aggregation_zone)
        {
#ifdef Mbands
          case 1:  params.nrows = orig_nrows - 4;
                   params.row_offset = orig_row_offset + 2;
                   break;
          case 2:  params.nrows = orig_nrows - 2;
                   params.row_offset = orig_row_offset + 1;
                   break;
#else
          case 1:  params.nrows = orig_nrows - 8;
                   params.row_offset = orig_row_offset + 4;
                   break;
          case 2:  params.nrows = orig_nrows - 4;
                   params.row_offset = orig_row_offset + 2;
                   break;
#endif
          case 3:  params.nrows = orig_nrows;
                   params.row_offset = orig_row_offset;
                   break;
          default: return false;
        }
#endif
#endif
          status = simulate(inputds, latitudeds, longitudeds,
#ifdef MODIS
                            scands, trackds,
                            pj_latlong, pj_utm, water_maskds, OLI_image, OLI_mask);
#else
                            pj_latlong, pj_utm, water_maskds, cloud_maskds, OLI_image, OLI_mask);
#endif
        if (params.OLI_column_shift != params.best_col_offset)
          redo_flag = true;
        if (params.OLI_row_shift != params.best_row_offset)
          redo_flag = true;
        params.OLI_column_shift = params.best_col_offset;
        params.OLI_row_shift = params.best_row_offset;
      } // if ((found_peak_flag) && (orig_number_shifts > 1))
     } // while (redo_flag)
    } // else if (!params.column_offset_flag)

    if ((found_peak_flag) && (params.best_correlation > params.min_corr_peak))
    {
      if (params.corr_type == 1)
        cout << endl << "For scan = " << params.scan << ", best cross correlation = " << params.best_correlation;
      else
        cout << endl << "For scan = " << params.scan << ", best NMI = " << params.best_correlation;
      cout << " for OLI_column_shift = " << params.OLI_column_shift << " and OLI_row_shift = " << params.OLI_row_shift << endl;
      cout << "at column_offset = ";
#ifdef MODIS
      cout << params.best_column_offset << endl;
#else
#ifdef DNB
// NOTE: aggregation zone 1 is split into two equal sections ("0" and "1").
      if (params.best_aggregation_zone == 0)
        cout << params.best_column_offset << " in aggregation zone 1";
      else
        cout << params.best_column_offset << " in aggregation zone " << params.best_aggregation_zone;
      if (params.best_start_scan_flag)
        cout << " with start_scan_flag = true" << endl;
      else
        cout << " with start_scan_flag = false" << endl;
#else
      cout << params.best_column_offset << " in aggregation zone " << params.best_aggregation_zone;
#endif // !DNB
#endif // !MODIS
      cout << endl;
#ifdef MODIS
      cout << "-column_offset " << params.best_column_offset << endl;
#else
#ifdef DNB
// NOTE: aggregation zone "1" can be either "0" or "1" here to account for the splitting of this zone into two sections.
      cout << "-aggregation_zone " << params.best_aggregation_zone << endl;
      if (params.best_start_scan_flag)
        cout << "-start_scan_flag 1" << endl;
      else
        cout << "-start_scan_flag 0" << endl;
#else
      cout << "-column_offset " << params.best_column_offset << endl;
#endif
#endif
      cout << "-OLI_column_shift " << params.OLI_column_shift << endl;
      cout << "-OLI_row_shift " << params.OLI_row_shift << endl;
    }
    else if (found_peak_flag)
      cout << endl << "No results were produced due to low correlation values" << endl;
    else
      cout << endl << "No results were produced" << endl;

    GDALClose( (GDALDatasetH) inputds);
#ifdef MODIS
    if (SWATH_SIZE != 10)
    {
      GDALClose( (GDALDatasetH) scands);
      GDALClose( (GDALDatasetH) trackds);
    }
#endif
    GDALClose( (GDALDatasetH) latitudeds);
    GDALClose( (GDALDatasetH) longitudeds);
  } // if (status)

  if (status)
    return EXIT_SUCCESS;
  else
    return EXIT_FAILURE;
}

void usage() // Informs user of proper usage of program when mis-used.
{
    cout << endl << "Usage: " << endl << endl;
    cout << "simulate parameter_file_name" << endl << endl;
    cout << "For help information: simulate -h or simulate -help" << endl;
    cout << "For version information: simulate -v or simulate -version" << endl;

    return ;
}

void help()
{
    cout << endl << "The simulate progam is called as follows:" << endl;
    cout << endl << "simulate parameter_file_name" << endl;
    cout << endl << "where \"parameter_file_name\" is the name of the input parameter" << endl;
    cout << "file. For contents see below." << endl;
    cout << endl << "For this help: simulate -h or simulate -help" << endl;
    cout << endl << "For version information: simulate -v or simulate -version" << endl;
    cout << endl << "The parameter file consists of entries of the form:" << endl << endl;
    cout << "-parameter_name parameter_value(s)" << endl;

    fprintf(stdout,"\nThe following parameters may be specified in the input parameter file:\n\n");
#ifdef MODIS
    fprintf(stdout,"-MODIS_reflectance_image (string)	Input MODIS reflectance image\n"
#else
    fprintf(stdout,"-VIIRS_radiance_image 	(string)	Input VIIRS radiance image\n"
#endif
"					(single band - required)\n"
"-latitude_image		(string)	Input latitude data image (required)\n"
"-longitude_image	(string)	Input longitude data image (required)\n"
#ifdef MODIS
"-water_mask		(string)	Input water mask image (required)\n");
#else
"-water_mask		(string)	Input water mask image (required)\n"
"-cloud_mask		(string)	Input cloud mask image (optional)\n");
#endif
#ifdef MODIS
    if (SWATH_SIZE != 10)
    {
      fprintf(stdout,"-scan_offset_image	(string)	Input Scan Offset image (required)\n"
"-track_offset_image	(string)	Input Track Offset image (required)\n"
"-scan		(int)		Scan number for MODIS image subset\n"
"					simulated (required)\n");
    }
    else
    {
      fprintf(stdout,"-scan		(int)		Scan number for MODIS image subset\n"
"					simulated (required)\n");
    }
    fprintf(stdout,"-column_offset		(int)		Column offset for MODIS image subset\n"
"					simulated (optional)\n"
"-min_column_offset	(int)		Minimum column offset for MODIS image subset\n"
"					simulated (optional, ignored if column_offset\n"
"					 provided)\n"
"-max_column_offset	(int)		Maximum column offset for MODIS image subset\n"
"					simulated (optional, ignored if column_offset\n"
"					 provided)\n");
#else // !MODIS
    fprintf(stdout,"-scan			(int)		Scan number for VIIRS image subset\n"
"					simulated (required)\n");
#ifdef DNB
      fprintf(stdout,"-aggregation_zone	(int)		VIIRS DNB aggregation zone\n"
"					(valid values 0 through 32, optional)\n"
"-start_scan_flag	(boolean)	Start Scan flag. True (1) for start scan\n"
"					aggregation zones and false (0) for end scan\n"
"					aggregation zones (default = true (1))\n"
"-min_column_offset	(int)		Minimum column offset for VIIRS image subset\n"
"					simulated (optional, ignored if aggregation_zone\n"
"					 provided)\n"
"-max_column_offset	(int)		Maximum column offset for VIIRS image subset\n"
"					simulated (optional, ignored if aggregation_zone\n"
"					 provided)\n");
#else // !DNB
      fprintf(stdout,"-column_offset		(int)		Column offset for VIIRS image subset\n"
"					simulated (optional)\n"
"-min_column_offset	(int)		Minimum column offset for VIIRS image subset\n"
"					simulated (optional, ignored if column_offset\n"
"					 provided)\n"
"-max_column_offset	(int)		Maximum column offset for VIIRS image subset\n"
"					simulated (optional, ignored if column_offset\n"
"					 provided)\n");
#endif // !DNB
#endif // !MODIS
    fprintf(stdout,"-water_threshold	(float)		Water pixels threshold\n"
"					(optional, default = 0.2)\n"
#ifndef MODIS
"-cloud_threshold	(float)		Cloud pixels threshold\n"
"					(optional, default = 0.1)\n"
#endif
"-Landsat_OLI_image	(string)	Input Landsat OLI image\n"
"					(single band - required)\n"
"-Landsat_OLI_mask	(string)	Input Landsat OLI image mask\n"
"					(single band - required)\n"
"-OLI_column_shift	(int)		OLI image column shift (pixels)\n"
"					(optional, default = 0)\n"
"-OLI_row_shift		(int)		OLI image row shift (pixels)\n"
"					(optional, default = 0)\n"
"-number_OLI_shifts	(int)		Number of OLI shifts in\n"
"					each direction (optional,\n"
"					 default = 1, i.e. no shift search)\n"
"-corr_type		(int)		Correlation type\n"
"					  1.\"Spatial Cross Correlation\",\n"
"					  2.\"Normalized Mutual Information\"\n"
"					(default: 1.\"Spatial Cross Correlation\")\n"
"-min_corr_peak		(float)		Minimum correlation peak for \"best\"\n"
"					correlation (default: 0.5)\n"
"-Landsat_OLI_subset_image (string)	Output Landsat OLI subset image\n"
"					(required)\n"
#ifdef MODIS
"-MODIS_subset_image	(string)	Output MODIS subset image (required)\n"
"-simulated_MODIS_image	(string)	Output simulated MODIS image (required)\n");
#else
"-VIIRS_subset_image	(string)	Output VIIRS subset image (required)\n"
"-simulated_VIIRS_image	(string)	Output simulated VIIRS image (required)\n");
#endif
#ifdef MODIS
    if (SWATH_SIZE == 40)
    {
      cout << "NOTE: Compiled for MODIS 250m resolution reflectance subimages:" << endl;
    }
    else if (SWATH_SIZE == 20)
    {
      cout << "NOTE: Compiled for MODIS 500m resolution reflectance subimages:" << endl;
    }
    else
    {
      cout << "NOTE: Compiled for MODIS 1km resolution reflectance subimages:" << endl;
    }
#else
    if (SWATH_SIZE == 16)
    {
#ifdef DNB
#ifdef J1
      cout << "NOTE: Compiled for J1 VIIRS DNB radiance subimages:" << endl;
#else
      cout << "NOTE: Compiled for NPP VIIRS DNB radiance subimages:" << endl;
#endif
#else
      cout << "NOTE: Compiled for VIIRS M-band radiance subimages:" << endl;
#endif
    }
    else
    {
      cout << "NOTE: Compiled for VIIRS I-band radiance subimages:" << endl;
    }
#endif
    cout << "NOTE: If a multiband input image is provided, the first band will be used." << endl;

    return ;
}
