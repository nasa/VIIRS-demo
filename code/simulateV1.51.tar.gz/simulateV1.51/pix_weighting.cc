/*******************************************************************************************************/
/*   Name: pix_weighting by zones:                                                                     */
/*               get_I_type_weights, get_II_type_weights, get_III_type_weights                         */
/*******************************************************************************************************/
/*   Purpose:  Depending on zone No. calculate weights (left and right-hand) by the following modules:

            get_I_type_weights:  Assume no pixel aggregation in Zone I and calculate weights
            get_II_type_weights:  Assume 2 pixel aggregation in Zone II and calculate weights
            get_III_type_weights:  Assume 3 pixel aggregation in Zone III and calculate weights



     Input:   n: Pixel No. to be evaluated
              r: Fractional distance

     Output:  itype: 2, 1, 0 depending on where the pixel is located.



     Reference:

     Notes:  Minor modification of pix_weighting.c

                                                                                                       */
/*-----------------------------------------------------------------------------------------------------*/
/*   Date               Author                    Version               Comments                       */
/*  -------- ----------------------------       ----------- ------------------------------------------ */
/* 10/28/08  Mash Nishihama/RIS(Raytheon Information Solutions)      initial coding                    */
/* 10/25/16  James C. Tilton/NASA GSFC Code 606.3                    minor modifications               */
/*-----------------------------------------------------------------------------------------------------*/
/*******************************************************************************************************/

#include "simulate.h"

using namespace std;
using namespace NPP_VIIRS;

#define	X_LENGTH2	21

namespace NPP_VIIRS
{
  /**********************************************************************************
   get_I_type_weights: for Zone I  (no aggregation)
  ***********************************************************************************/
  void get_I_type_weights(const int& n, const double& r, int& itype, double& wgt1, double& wgt2)
  {
    int n1 = X_LENGTH2;

    wgt1 = 0.;
    wgt2 = 0.;

    if (n == -1)
    {
        itype = 2;
        wgt2 = r;
    }
    if ((n>=0)&&(n<= (n1-2)))
    {
        itype = 1;
        wgt1 = 1. - r;
        wgt2 = r;
    }
    if (n == (n1-1))
    {
        itype = 0;
        wgt1  = 1. - r;
    }
  }
  /**********************************************************************************
   get_II_type_weights: for Zone II (2 pixel aggregation)
  ***********************************************************************************/
  void get_II_type_weights(const int& n, const double& r, int& itype, double& wgt1, double& wgt2)
  {
    int n1 = X_LENGTH2;
    double v4 = 0.25;


    wgt1 = 0.;
    wgt2 = 0.;

    if (n == -1)
    {
        itype = 2;
        if (r <= v4 )
        {
            wgt2 = 0.;
        }

        if ((r>= v4)&&(r<= 3.0*v4))
            wgt2 = 2.0*(r - v4);

        if ((r>= 3.0*v4)&&(r< 1.0))
            wgt2 = 1.0;
    }
    if ((n>=0)&&(n<= (n1-2)))
    {
        itype = 1;
        if (r <= v4)
        {
            wgt1 = 1.;
            wgt2 = 0.;
        }
        if ((r>= v4)&&(r<= 3.0*v4))
        {
            wgt1 = 2.0*(3.0*v4 - r);
            wgt2 = 2.0*(r - v4);
        }
        if ((r>= 3.0*v4)&&(r< 1.0))
        {
            wgt1 = 0.;
            wgt2 = 1.0;
        }
    }
    if (n == (n1-1))
    {
        itype = 0;
        if (r <= v4)
        {
            wgt1 = 1.;
        }
        if ((r>= v4)&&(r<= 3.0*v4))
        {
            wgt1 = 2.0*(3.0*v4 - r);
        }
        if ((r>= 3.0*v4)&&(r< 1.0))
        {
            wgt1 = 0.;
        }

    }
  }
  /**********************************************************************************
   get_III_type_weights: for Zone III (3 pixel aggregation)
  ***********************************************************************************/
  void get_III_type_weights(const int& n, const double& r, int& itype, double& wgt1, double& wgt2)
  {
    int n1 = X_LENGTH2;
    double v3;

    wgt1 = 0.;
    wgt2 = 0.;

    v3 = 1.0/3.;
    if (n == -1)
    {
        itype = 2;
        if (r <= v3)
        {
            wgt2 = 0.;
        }
        if ((r>=v3)&&(r<= 2.0*v3))
            wgt2 = 3.0*(r - v3);

        if ((r>=2.0*v3)&&(r< 1.0))
            wgt2 = 1.0;
    }
    if ((n>=0)&&(n<= (n1-2)))
    {
        itype = 1;
        if (r <= v3)
        {
            wgt1 = 1.;
            wgt2 = 0.;
        }
        if ((r>=v3)&&(r<= 2.0*v3))
        {
            wgt1 = 3.0*(2.0*v3 - r);
            wgt2 = 3.0*(r - v3);
        }
        if ((r>=2.0*v3)&&(r< 1.0))
        {
            wgt1 = 0.;
            wgt2 = 1.0;
        }
    }
    if (n == (n1-1))
    {
        itype = 0;
        if (r <= v3)
        {
            wgt1 = 1.;
        }
        if ((r>=v3)&&(r<= 2.0*v3))
        {
            wgt1 = 3.0*(2.0*v3- r);
        }
        if ((r>=2.0*v3)&&(r< 1.0))
        {
            wgt1 = 0.;
        }

    }
  }

} // NPP_VIIRS
