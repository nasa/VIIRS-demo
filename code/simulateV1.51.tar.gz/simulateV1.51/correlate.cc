// correlate.cc

#include "simulate.h"
#include "params/params.h"
#include <float.h>
#include <iostream>

using namespace NPP_VIIRS;

// Externals
extern Params params;

namespace NPP_VIIRS
{
// Normalize image_data to have zero mean and unity variance.
  void normalize_image(float *image_data)
  {
    int row, col, index;
    double value, min_stat, sum_stat, sumsq_stat, npix_stat;
    double mean_stat, stddev_stat;
    double scale, offset;

    min_stat = FLT_MAX;
    sum_stat = 0.0;
    sumsq_stat = 0.0;
    npix_stat = 0.0;

    for (row = 0; row < params.nrows; row++)
      for (col = 0; col < params.ncols; col++)
      {
        index = col + row*params.ncols;
//#ifdef MODIS
        if (image_data[index] < 65500.0)
/*
#else
        if (image_data[index] > -999.0)
#endif
*/
        {
          npix_stat++;
          value = image_data[index];
          if (min_stat > value)
            min_stat = value;
          sum_stat += value;
          sumsq_stat += value*value;
        }
      }

    if (npix_stat > 1)
    {
      mean_stat = sum_stat/npix_stat;
      stddev_stat = (sum_stat*sum_stat)/npix_stat;
      stddev_stat = sumsq_stat - stddev_stat;
      stddev_stat = stddev_stat/(npix_stat - 1.0);
      stddev_stat = sqrt(stddev_stat);

      scale = 1.0/stddev_stat;
      offset = mean_stat;
    }
    else
    {
      scale = 1.0;
      offset = 0.0;
    }

    for (row = 0; row < params.nrows; row++)
      for (col = 0; col < params.ncols; col++)
      {
        index = col + row*params.ncols;
//#ifdef MODIS
        if (image_data[index] < 65500.0)
/*
#else
        if (image_data[index] > -999.0)
#endif
*/
        {
          value = image_data[index];
          image_data[index] = scale*(value - offset);
        }
        else
          image_data[index] = -999.0;
      }

    return;
  }

// Quantize the image_data into NBINS bins.
// Scale such that -3*std_dev is at 1 and +3*std_dev is at (NBINS-1), clipping as necessary,
// or min is at 1 and max is at (NBINS-1), if that provides a greater dynamic range.
// Reserves value 0 as a no data mask.
// NOTE: quantize_image does not actually quantize the image data. It just scales the data
// in such a way that it can be easily quantized in the process of performing normalized
// mutual information correlation.
  void quantize_image(float *image_data)
  {
    int row, col, index;
    float min_value, max_value, scale, value;

// Prenormalize to have zero mean and unity variance.
    normalize_image(image_data);

    min_value = max_value = 0.0;
    for (row = 0; row < params.nrows; row++)
      for (col = 0; col < params.ncols; col++)
      {
        index = col + row*params.ncols;
        if (image_data[index] > -999.0)
        {
          value = image_data[index];
          if (value < min_value)
            min_value = value;
          if (value > max_value)
            max_value = value;
        }
      } 
    min_value = -min_value;
    if (min_value > max_value)
      max_value = min_value;
    if (max_value > 3.0)
      max_value = 3.0; // Limit to 3 std. dev.

    scale = (((float) (NBINS-2))/(2.0*max_value));

    for (row = 0; row < params.nrows; row++)
      for (col = 0; col < params.ncols; col++)
      {
        index = col + row*params.ncols;
        if (image_data[index] > -999.0)
        {
          value = image_data[index];
          value = scale*(value + max_value) + 1.0;
          if (value < 1.0)
            value = 1.0;
          if (value > (NBINS-1))
            value = NBINS-1;
          image_data[index] = (int) value;
        }
        else
        {
          image_data[index] = 0;
        }
      }

    return;
  }

  float calc_correlation(float *fixed_data, float *shift_data)
  {
    float correlation;

    if (params.corr_type == 1)
      correlation = calc_cross_corr(fixed_data,shift_data);
    else
      correlation = calc_nmi(fixed_data,shift_data);

    return correlation;
  }

  float calc_cross_corr(float *fixed_data, float *shift_data)
  {
    int fixed_row, fixed_col, fixed_index;
    int shift_row, shift_col, shift_index;
    double sum_fixed, sum_shift, valid_npix, sum_cross;
    double mean_fixed, mean_shift;
    float cross_corr;

  // Calculate mean at this particular offset
    sum_fixed = sum_shift = valid_npix = 0.0;
    for (fixed_row = 0; fixed_row < params.nrows; fixed_row++)
    {
      shift_row = fixed_row;
      for (fixed_col = 0; fixed_col < params.ncols; fixed_col++)
      {
        shift_col = fixed_col;
        fixed_index = fixed_col + fixed_row*params.ncols;
        shift_index = shift_col + shift_row*params.ncols;
        if ((fixed_data[fixed_index] > 0) && (shift_data[shift_index] > 0))
        {
          valid_npix++;
          sum_fixed += fixed_data[fixed_index];
          sum_shift += shift_data[shift_index];
        } // if ((fixed_data[fixed_index] > 0) && (shift_data[shift_index] > 0))
      } // for (fixed_col = 0; fixed_col < params.ncols; fixed_col++)
    } // for (fixed_row = 0; fixed_row < params.nrows; fixed_row++)

    if (valid_npix > ((params.ncols*params.nrows*SUBSET_PCT)/100))
    {
      mean_fixed = sum_fixed/valid_npix;
      mean_shift = sum_shift/valid_npix;
//     cout << "mean_fixed = " << mean_fixed << " and mean_shift = " << mean_shift << endl;

   // Calculate correlation terms at this particular offset
      sum_fixed = sum_shift = 0.0;
      sum_cross = 0.0;
      for (fixed_row = 0; fixed_row < params.nrows; fixed_row++)
      {
        shift_row = fixed_row;
        for (fixed_col = 0; fixed_col < params.ncols; fixed_col++)
        {
          shift_col = fixed_col;
          fixed_index = fixed_col + fixed_row*params.ncols;
          shift_index = shift_col + shift_row*params.ncols;
          if ((fixed_data[fixed_index] > 0) && (shift_data[shift_index] > 0))
          {
            sum_fixed += (fixed_data[fixed_index] - mean_fixed)*(fixed_data[fixed_index] - mean_fixed);
            sum_shift += (shift_data[shift_index] - mean_shift)*(shift_data[shift_index] - mean_shift);
            sum_cross += (fixed_data[fixed_index] - mean_fixed)*(shift_data[shift_index] - mean_shift);
          } // if ((fixed_data[fixed_index] > 0) && (shift_data[shift_index] > 0))
        } // for (fixed_col = 0; fixed_col < params.ncols; fixed_col++)
      } // for (fixed_row = 0; fixed_row < params.nrows; fixed_row++)
     
    // Calculate correlation coefficient
      cross_corr = sum_cross/(sqrt(sum_fixed*sum_shift));
    }
    else
      cross_corr = 0.0;

    return cross_corr;
  }

  float calc_nmi(float *fixed_data, float *shift_data)
  {
    int fixed_row, fixed_col, fixed_index;
    int shift_row, shift_col, shift_index;
    int index, valid_npix;
    float nmi;

    int *hFS;
    hFS = new int[NBINS_SQRD];
    double *pFS, *pF, *pS;
    pFS = new double[NBINS_SQRD];
    pF = new double[NBINS];
    pS = new double[NBINS];
    double entFS, entF, entS; 

    valid_npix = 0;
    for (index = 0; index < NBINS_SQRD; index++)
      hFS[index] = 0;

  // Calculate joint histogram at this particular offset
    for (fixed_row = 0; fixed_row < params.nrows; fixed_row++)
    {
      shift_row = fixed_row;
      for (fixed_col = 0; fixed_col < params.ncols; fixed_col++)
      {
        shift_col = fixed_col;
        fixed_index = fixed_col + fixed_row*params.ncols;
        shift_index = shift_col + shift_row*params.ncols;
        if ((fixed_data[fixed_index] > 0) && (shift_data[shift_index] > 0))
        {
          index = fixed_data[fixed_index] + NBINS*shift_data[shift_index];
if (index >= NBINS_SQRD)
  cout << "WARNING: Found index = " << index << " >= " << NBINS_SQRD << endl;
          hFS[index] += 1;
          valid_npix++;
        } // if ((fixed_data[fixed_index] > 0) && (shift_data[shift_index] > 0))
      } // for (fixed_col = 0; fixed_col < params.ncols; fixed_col++)
    } // for (fixed_row = 0; fixed_row < params.nrows; fixed_row++)

    if (valid_npix > ((params.ncols*params.nrows*SUBSET_PCT)/100))
    {
     // Normalize the histogram to get the joint probability density function
     // Also compute the entropy sum
      entFS = 0.0;
      for (fixed_index = 1; fixed_index < NBINS; fixed_index++)
        for (shift_index = 1; shift_index < NBINS; shift_index++)
        {
          index = fixed_index + NBINS*shift_index;
          pFS[index] = ((double) hFS[index])/((double) valid_npix);
          if (pFS[index] > 0.0)
            entFS -= pFS[index]*log(pFS[index]);
        }
    // Sum pFS over the appropriate dimension to obtain pF and pS (the marginal probability density functions)
    // Also compute the entropy sums
      entF = 0.0;
      for (fixed_index = 1; fixed_index < NBINS; fixed_index++)
      {
        pF[fixed_index] = 0.0;
        for (shift_index = 1; shift_index < NBINS; shift_index++)
        {         
          index = fixed_index + NBINS*shift_index;
          pF[fixed_index] += pFS[index];
        }
        if (pF[fixed_index] > 0.0)
          entF -= pF[fixed_index]*log(pF[fixed_index]);
      }
      entS = 0.0;
      for (shift_index = 1; shift_index < NBINS; shift_index++)
      {
        pS[shift_index] = 0.0;
        for (fixed_index = 1; fixed_index < NBINS; fixed_index++)
        {         
          index = fixed_index + NBINS*shift_index;
          pS[shift_index] += pFS[index];
        }
        if (pS[shift_index] > 0.0)
          entS -= pS[shift_index]*log(pS[shift_index]);
      }
      nmi = ((entF + entS)/entFS) - 1.0;
    }
    else
      nmi = 0.0;

    return nmi;
  }
} // namespace NPP_VIIRS
